/****************************************************************************
** Copyright (c) 2019.
** All rights reserved.
**
** File name:ifm_ablt.h
** Description:header file of ifm_ablt.c
**
** Current Version: 1.0
** Author: zhangjian (zhangjian@sylincom.com)
** Date: 20190613
****************************************************************************/

#ifndef __IFM_ABLT_H__
#define __IFM_ABLT_H__

#ifdef __cplusplus
extern "C"
 {
#endif


/******************************   Begin of File Body  ********************/

/*ability*/
#define IFM_BE_ROUTE_AWARE       (0)/*(0x00000000)*/	/*路由关心*/
#define IFM_CAN_JOIN_VLAN        (1)/*(0x00000001)*/	/*能加入vlan*/
#define IFM_CAN_SET_IP           (2)/*(0x00000004)*/	/*能配置IP*/
#define IFM_CAN_BIND_VPN         (3)/*(0x00000008)*/	/*能绑定VPN*/
#define IFM_NEED_KEEPALIVE       (4)/*(0x00000020)*/	/*需要保活*/
#define IFM_CAN_SET_MULTI_IP     (5)/*(0x00000040)*/	/*能设置多个IP*/
#define IFM_DOWN_BEFORE_SET_IP   (6)/*(0x00000080)*/	/*设置IP前接口要DOWN*/
#define IFM_SYN_AFTER_SET_MIP    (7)/*(0x00000200)*/	/*多播IP改变后下发*/
#define IFM_NEED_EXT_ACT_FOR_MIP (8)/*(0x00000400)*/	/*设置多播IP需要特殊处理*/
#define IFM_CAN_SET_MIP          (9)/*(0x00000800)*/	/*能设置多播IP*/
#define IFM_CAN_LEAVE_VLAN       (10)/*(0x00001000)*/	/*能离开vlan*/
#define IFM_CAN_CHANGE_IP        (11)/*(0x00002000)*/	/*能改变IP*/
#define IFM_CAN_JOIN_TRUNK       (12)/*(0x00004000)*/	/*能加入trunk*/
#define IFM_CAN_LEAVE_TRUNK      (13)/*(0x00008000)*/	/*能离开trunk*/
#define IFM_CAN_BE_DESTROIED     (14)/*(0x00010000)*/	/*能删除该接口*/
#define IFM_CAN_SET_L2_ENABLE    (15)/*(0x00020000)*/	/*能二层使能*/
#define IFM_CAN_SET_L2_DISABLE   (16)/*(0x00040000)*/	/*能二层禁止*/
#define IFM_CAN_CHANGE_MTU       (17)/*(0x00080000)*/	/*能改变MTU*/
#define IFM_CAN_ADMINSTATUS_CHANGE 	(18)/*(0x00100000)*/	/*能shut down/undo shutdonw*/
#define IFM_CAN_SET_32BIT_IP       	(19)/*(0x00200000)*/	/*能配置32位IP*/
#define IFM_CAN_SET_ACCESSLIMIT    	(20)/*(0x00400000)*/	/*能设置安全端口*/
#define IFM_CAN_SET_IPV6			(21)					/*能配置IPV6*/
#define IFM_CAN_OFFER_STATISTICS     (22)/*(0x00800000)*/	/*能提供统计*/
#define IFM_CAN_SET_UNNUMBER_IP      (23) /*(0x01000000)*/	/**/
#define IFM_CAN_SUPPORT_IPADDR       (24) /*(0x00000004)*/	/**/

#define IFM_ABILITY_COUNT      (32)

#define IFM_ABILITY_CAN        (0x1)		/*支持能力*/
#define IFM_ABILITY_CANOT      (0x0)		/*不支持能力*/

typedef struct tagIFM_Ability
{
    ULONG alWhyNoAbility[IFM_ABILITY_COUNT];
}IFM_IF_ABILITY_S;

extern IFM_IF_ABILITY_S g_stIFMAbilityAll;
VOID IFM_AbilityCopy( IFM_IF_ABILITY_S * pstAbilityDest, IFM_IF_ABILITY_S * pstAbilitySource );
LONG IFM_AbilitySet( IFM_IF_ABILITY_S * pstAbility, ULONG ulAbilityCode, ULONG ulCanOrCant, LONG lReason );
LONG IFM_AbilityCheck( IFM_IF_ABILITY_S * pstAbility, ULONG ulAbilityCode, ULONG * pulCanOrCant, LONG * plReason );
LONG IFM_InterfaceAbilityCheck( ULONG ulIfindex, ULONG ulAbilityCode, ULONG * pulCanOrCant, LONG * plReason );
LONG IFM_InterfaceTypeAbilityCheck( ULONG ulType, ULONG ulAbilityCode, ULONG * pulCanOrCant );
LONG IFM_InterfaceAbilityBatchSet( ULONG ulInterface, IFM_IF_ABILITY_S * pstAbility );
LONG IFM_InterfaceAbilityForbid( ULONG ulIfindex, ULONG ulAbilityCode, LONG lReason );
LONG IFM_InterfaceAbilityPermit( ULONG ulIfindex, ULONG ulAbilityCode );
LONG IFM_InterfaceAbilityReset( ULONG ulIfindex );

/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_ABLT_H__ */

