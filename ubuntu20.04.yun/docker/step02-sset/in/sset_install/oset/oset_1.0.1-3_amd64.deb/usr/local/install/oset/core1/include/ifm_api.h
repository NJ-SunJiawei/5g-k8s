/**
 * @file ifm_api.h
 * @brief ifm_api 头文件
 * @details 提供接口管理API接口
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2019.06.13
 * @copyright 
 *    Copyright (c) 2019 Sylincom.
 *    All rights reserved.
*/

#ifndef __IFM_API_H__
#define __IFM_API_H__

#ifdef __cplusplus
extern "C"
 {
#endif


/******************************   Begin of File Body  ********************/
#include "ifm_pub.h"
#include "ifm_def.h"
#include "ifm_ablt.h"
#include "ifm_netd.h"
#include "ifm_ntfy.h"

extern ULONG g_ulMAXPortNum;

#define MOD_IFM_NAME		"IFM_MODULE"

/** 最大槽位号 */
#define MAXSlotNum 						PRODUCT_MAX_TOTAL_SLOTNUM

/** 每个slot上的最大端口个数 */
#define MAXPortOnSlotNum				32

#define MAXIntConPortOnSlotNum		    16

/** 接口管理任务消息码 */
enum enAWMsgCode_IFM
{
    AWMC_IFM_MSG_MIN = 0,
	AWMC_IFM_PRIVATE_LOOPTIMER,	///< timer msg

/*Begin: asyn msg*/
	AWMC_IFM_PUBLIC_NOTIFY,		///< NOTIFY msg
	AWMC_IFM_CONFIG_MSG,		///< config msg
/*end*/

/*Brgin: syn msg*/
	AWMC_IFM_GET_INFO_MSG,		///< get info msg
/*End*/
	
    AWMC_IFM_MSG_MAX
};

/** 接口管理配置/获取信息时需要的参数*/
typedef struct _IFM_Operate_Info_s
{
    ULONG               ulIfindex;     ///< 接口索引 
    ULONG               ulCode;        ///< 消息码 
    VOID                *pData;        ///< 数据信息
}IFM_Operate_Info_t;

/** 
 * 通过slot、port获取以太网接口索引
 * @param[in ]   ulUserSlot   	槽位号
 * @param[in ]   ulUserPort   	端口号
 * @return   成功返回ulIfindex，失败0xffffffff   
 */
ULONG IFM_userSlot_userPort_2_ethIfindex( ULONG ulUserSlot, ULONG ulUserPort );

/** 
 * 判断接口索引是否是local
 * @param[in ]   ulIfIndex   	接口索引
 * @return       VOS_YES/VOS_NO
 */
LONG  IFM_IfIndex_IS_Local ( ULONG ulIfIndex );

/** 
 * 判断slot是否是local
 * @param[in ]   ulSlot   	槽位号
 * @return       VOS_YES/VOS_NO
 */
LONG IFM_Slot_IS_Local(ULONG ulSlot);

/** 
 * 判断配置类型的slot是否是local
 * @param[in ]   ulSlot   	槽位号
 * @return       VOS_YES/VOS_NO
 */
LONG IFM_Config_Slot_IS_Local(ULONG ulSlot);

/** 
 * 获取VLAN ID
 * @param[in ]   ulIfIdx   	接口索引
 * @return       VLAN ID
 */
USHORT IFM_VlanGetVIDApi( ULONG ulIfIdx);

/** 
 * 注册(创建)接口
 * @param[in ]  ULONG ulType   			接口类型
 * @param[in ]  VOID *pData    			接口信息
 * @param[out ] ULONG *pulIfindex    	接口索引
 * @param[out ] CHAR **szErrInfo    	出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_register_api( ULONG ulType, ULONG *pulIfindex, VOID *pData, CHAR **szErrInfo );

/** 
 * 删除接口
 * @param[in ]  ULONG ulIfindex    		接口索引
 * @param[in ]  VOID *pData    			接口信息
 * @param[out ] CHAR **szErrInfo    	出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_unregister_api( ULONG ulIfindex, VOID *pData, CHAR **szErrInfo );



/** 
 * 显示接口的基本信息
 * @param[in ]  ULONG ulIfindex   		接口索引	
 * @param[in ]  ULONG ulCode    		接口配置or接口统计
 * @param[out ] CHAR** ppOutBuf    		存储接口信息的BUF
 * @param[out ] CHAR **szErrInfo    	出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_show_api( ULONG ulIfindex, ULONG ulCode, CHAR** ppOutBuf, CHAR ** szErrInfo );

/** 
 * 配置接口的某一项信息
 * @param[in ]  ULONG ulIfindex   		接口索引	
 * @param[in ]  ULONG ulCode    		接口的某一项
 * @param[in ] VOID * pData    			配置信息
 * @param[out ] CHAR **szErrInfo    	出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_config_api( ULONG ulIfindex, ULONG ulCode, VOID * pData, CHAR ** szErrInfo );

/** 
 * 配置调试开关
 * @param[in ]  ULONG enable   	使能/关闭	
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_debug_config_api(ULONG enable);

/** 
 * 配置接口的某一项信息,提供MIB使用
 * @param[in ]  ULONG slot   			槽位号
 * @param[in ]	ULONG port,				端口号
 * @param[in ]  ULONG ulCode    		接口的某一项
 * @param[out ] VOID * pData    		配置信息
 * @return      VOS_OK/VOS_ERROR
 */
LONG IFM_config_info_snmp_api( ULONG slot, ULONG port, ULONG ulCode, VOID *pData);

/** 
 * 获取接口的某一项信息
 * @param[in ]  ULONG ulIfindex   		接口索引	
 * @param[in ]  ULONG ulCode    		接口的某一项
 * @param[out ] VOID * pData    		获取的信息
 * @param[out ] CHAR **szErrInfo    	出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_get_info_api( ULONG ulIfindex, ULONG ulCode, VOID * pData, CHAR ** szErrInfo );

/** 
 * 获取接口的某一项信息,提供MIB使用
 * @param[in ]  ULONG slot   			槽位号
 * @param[in ]	ULONG port,				端口号
 * @param[in ]  ULONG ulCode    		接口的某一项
 * @param[out ] VOID * pData    		获取的信息
 * @return      VOS_OK/VOS_ERROR
 */
LONG IFM_get_info_snmp_api( ULONG slot, ULONG port, ULONG ulCode, VOID *pData);

/** 
 * 查找接口netdev,对接口操作前需判断是否存在netdev
 * @param[in ]  ULONG ulIfindex   					接口索引	
 * @param[out ] IFM_NET_DEVICE_S ** ppNetd    		获取的netdev信息
 * @param[out ] CHAR **szErrInfo    				出错信息，目前传NULL
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_find_netdev_api( ULONG ulIfindex, IFM_NET_DEVICE_S ** ppNetd, CHAR ** szErrInfo );

/** 
 * 获取某种类型接口的第一个接口索引
 * @param[in ]  ULONG ulType   					接口类型
 * @return      成功返回第一个接口索引ulIfIndex，失败返回0
 */
ULONG IFM_GET_FIRST_INTERFACE_API( ULONG ulType );

/** 
 * 获取当前接口索引的下一个接口索引
 * @param[in ]  ULONG ulIfindex   				当前接口索引
 * @return      成功返回下一个接口索引ulIfIndex，失败返回0
 */
ULONG IFM_GET_NEXT_INTERFACE_API( ULONG ulIfindex );

/** 
 * 创建系统默认接口索引，目前只有默认vlan 1
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_CreateDefaultIfAPI();

/** 
 * 通过接口索引解析槽位号和端口号
 * @param[in ]  ULONG ulIfindex   		接口索引	
 * @param[out ] ULONG * slot    		槽位号
 * @param[out ] ULONG *port    			端口号
 * @param[out ] ULONG *sub_port    		子端口号，用于三层接口（目前未用）
 * @return      成功返回VOS_OK，失败返回VOS_ERROR
 */
LONG IFM_GET_SlotPort_By_IFIndex_Api( ULONG ifindex, ULONG *slot, ULONG *port, ULONG *sub_port );


/** 
 * 显示接口名称和索引对应表信息
 * @param[out ] CHAR ** szString    	name Table 信息
 * @return       字符串信息长度
 */
LONG IFM_GNameTableShowApi( CHAR ** szString );

/** 
 * 创建系统接口，循环遍历所有板卡创建所有类型的接口
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_interface_create( VOID );

/** 
 * 根据槽位号创建eth接口
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_interface_create_by_slot( ULONG ulSlot );


/** 
 * 根据槽位号删除eth接口
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_interface_delete_by_slot( ULONG ulSlot );


/**
 *底层驱动接口状态改变回调函数
 *@param[in ]：ULONG devIndex				设备索引
 *@param[in ]：ULONG ulSlot					槽位号
 *@param[in ]：ULONG ulPort					端口号
 *@param[in ]：VOID *pCurVal					接口相关信息
 *@return：VOS_OK/VOS_ERROR
*/
LONG BMS_PORT_LinkChangeDrvCallbk( ULONG devIndex, ULONG ulSlot, ULONG ulPort,  VOID *pCurVal);

/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_API_H__ */

