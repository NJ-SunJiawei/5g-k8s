/**
 * @file ifm_def.h
 * @brief ifm_def.h 头文件
 * @details 接口管理模块默认信息
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2019.06.13
 * @copyright 
 *	  Copyright (c) 2019 Sylincom.
 *	  All rights reserved.
*/

#ifndef __IFM_DEF_H__
#define __IFM_DEF_H__

#ifdef __cplusplus
extern "C"
 {
#endif


/******************************   Begin of File Body  ********************/

/** 接口名称长度 */
#define IFM_NAME_SIZE                  (30)

/** 物理地址(MAC)长度 */
#define IFM_PHY_ADD_LEN                (6)

/** 接口描述最大长度 */
#define IFM_MAX_DESCR_LEN              (63)


#if 0
/* return value as memcmp, 0==>is same, !0 is different */
#define IFM_PHY_ADDR_CMP( _addr_1, _addr_2 )    \
    ( \
        *(ULONG *)(_addr_1)|=*(ULONG *)(_addr_2) \
        || \
        *(USHORT *)((_addr_1)+sizeof(ULONG))|=*(USHORT *)((_addr_1)+sizeof(ULONG)) \
    )

#define IFM_PHY_ADDR_CPY( _addr_to, _addr_from ) do{ \
    *(ULONG *)(_addr_to)==*(ULONG *)(_addr_from); \
    *(USHORT *)((_addr_to)+sizeof(ULONG))==*(USHORT *)((_addr_from)+sizeof(ULONG)); \
}while( 0 )

#endif

/** 接口默认MTU */
#define IFM_DEFAULT_MTU                (1500)

/** 接口默认JUMBO MTU */
#define IFM_DEFAULT_JUMBO_MTU          (9600)

extern ULONG g_IFM_MAX_MTU;
extern ULONG g_IFM_MIN_MTU;

/** 最大MTU */
#define IFM_MAX_MTU                    (g_IFM_MAX_MTU) 

/** 最小MTU */
#define IFM_MIN_MTU                    (g_IFM_MIN_MTU)

/** 最大JUMBO MTU */
#define IFM_MAX_JUMBO_MTU              (g_IFM_MAX_MTU)  

/** 最小JUMBO MTU */
#define IFM_MIN_JUMBO_MTU              (g_IFM_MIN_MTU)

/** 接口已使用标识 */
#define IFM_INTERFACE_USED             (0x1)

/** 接口未已使用标识 */
#define IFM_INTERFACE_NOTUSED          (0x0)

/** NETDEV合法判断 */
#define IFM_NETDEV_IS_VALID( _net_dev ) ((NULL!=(_net_dev)) && (IFM_INTERFACE_NOTUSED!=(_net_dev)->ulUsed))
#define IFM_INTERFACE_MERGED            (0x2)

/** 接口down状态 */
#define IFM_STATE_DOWN                  (0x0)

/** 接口up状态 */
#define IFM_STATE_UP                    (0x1)

/** 接口code 范围，小于4096为全局配置，大于4096为某接口类型的特殊配置*/
#define IFM_CODE_SCOPE                  (4096)

/** 接口索引不合法 */
#define IFM_INVALID_IFINDEX             (0x00000000)
#define INVALID_SYS_IF_INDEX            IFM_INVALID_IFINDEX

/* reserve vid for l3 port*/
#define IFM_L3_VID           (0x1)  

/*
global config and get info code
*/
#define IFM_CONFIG_GLOBAL_IP             (0x1)		/*set ip*/
#define IFM_CONFIG_GLOBAL_NO_IP          (0x2)		/*undo ip*/
#define IFM_CONFIG_GLOBAL_IP_INFO        (0x3)
#define IFM_CONFIG_GLOBAL_MIP            (0x4)
#define IFM_CONFIG_GLOBAL_NO_MIP         (0x5)
#define IFM_CONFIG_GLOBAL_SPEC           (0x6)		/*if descr*/
#define IFM_CONFIG_GLOBAL_PHY_STATE      (0x7)		/*phy state*/
#define IFM_CONFIG_GLOBAL_ADMIN_STATE    (0x8)		/*admin state*/
#define IFM_CONFIG_GLOBAL_UNTAGGED_VLAN  (0x9)		/*untagged vlan*/
#define IFM_CONFIG_GLOBAL_USED           (0xa)		/*is used*/
#define IFM_CONFIG_GLOBAL_PRIVATE        (0xb)		/*private data*/
//#define IFM_CONFIG_GLOBAL_VPNID          (0xc)
#define IFM_CONFIG_GLOBAL_MTU            (0xd)		/*MTU*/
#define IFM_CONFIG_GLOBAL_ACCLIMIT       (0xe)
#define IFM_CONFIG_GLOBAL_DISFDBLEARN    (0xf)		/*FDB learn*/
#define IFM_CONFIG_GLOBAL_SROUTE         (0x10)
#define IFM_CONFIG_GLOBAL_EXTEND_IP      (0x11)
#define IFM_CONFIG_GLOBAL_NO_EXTEND_IP   (0x12)
//#define IFM_CONFIG_GLOBAL_NP_VPN         (0x13)
#define IFM_CONFIG_GLOBAL_BINDING_EN     (0x14)
#define IFM_CONFIG_GLOBAL_BINDING_IP     (0x15)
#define IFM_CONFIG_GLOBAL_BINDING_NO_IP  (0x16)
#define IFM_CONFIG_GLOBAL_IPLIMIT        (0x17) 
//#define IFM_CONFIG_NP_VPN_MOD2MOD        (0x18)
#define IFM_CONFIG_GLOBAL_NP_MTU         (0X19) 
#define IFM_CONFIG_GLOBAL_VRRP_INFO      (0x1c)
#define IFM_CONFIG_GLOBAL_JUMBO_LEN      (0x1d)


/** 以太网接口属性 code*/
#define IFM_ETH_TYPE_CODE_BASE           	(IFM_ETH_TYPE * IFM_CODE_SCOPE)	/*ETH接口基准code*/

#define IFM_CONFIG_ETH_TYPE             	(IFM_ETH_TYPE_CODE_BASE + 1)	/*eth type*/
#define IFM_CONFIG_ETH_BAUD             	(IFM_ETH_TYPE_CODE_BASE + 2)	/*speed*/
#define IFM_CONFIG_ETH_METRIC           	(IFM_ETH_TYPE_CODE_BASE + 4)	/*metric*/
#define IFM_CONFIG_ETH_BROADCAST        	(IFM_ETH_TYPE_CODE_BASE + 5)	/*broadcast*/
#define IFM_CONFIG_ETH_DUPLEX           	(IFM_ETH_TYPE_CODE_BASE + 6)	/*duplex mode*/
#define IFM_CONFIG_ETH_DEVADDR          	(IFM_ETH_TYPE_CODE_BASE + 7)	/*MAC addr*/
#define IFM_CONFIG_ETH_AUTONEGOTATION   	(IFM_ETH_TYPE_CODE_BASE + 8)	/*auto mode*/
#define IFM_CONFIG_ETH_MCLIST           	(IFM_ETH_TYPE_CODE_BASE + 9)	/**/
#define IFM_CONFIG_ETH_MCCOUNT          	(IFM_ETH_TYPE_CODE_BASE + 10)
#define IFM_CONFIG_ETH_ENCAP            	(IFM_ETH_TYPE_CODE_BASE + 11)
#define IFM_CONFIG_ETH_FLOWCONTROL      	(IFM_ETH_TYPE_CODE_BASE + 12)
#define IFM_CONFIG_ETH_TRUNK           	 	(IFM_ETH_TYPE_CODE_BASE + 13)	/*join trunk ifindex*/
#define IFM_CONFIG_ETH_LEVEL            	(IFM_ETH_TYPE_CODE_BASE + 14) 	/*level*/
#define IFM_CONFIG_ETH_STATS            	(IFM_ETH_TYPE_CODE_BASE + 15)	/*interface statistics*/
#define IFM_CONFIG_ETH_UNTAGVLAN        	(IFM_ETH_TYPE_CODE_BASE + 16)	/*untagged vlan*/
#define IFM_CONFIG_ETH_OVERIDE          	(IFM_ETH_TYPE_CODE_BASE + 17)
#define IFM_CONFIG_ETH_SUBIFCOUNT       	(IFM_ETH_TYPE_CODE_BASE + 18)	/*subif count*/
#define IFM_CONFIG_ETH_TRUNKIF          	(IFM_ETH_TYPE_CODE_BASE + 19) 	/*trunk ifindex*/
#define IFM_CONFIG_ETH_LEARN                (IFM_ETH_TYPE_CODE_BASE + 20)	/*eth learn mode*/
#define IFM_CONFIG_ETH_CLKMODE              (IFM_ETH_TYPE_CODE_BASE + 21)

#define IFM_CONFIG_ETH_MIRROR_CHECK         (IFM_ETH_TYPE_CODE_BASE + 22)
#define IFM_CONFIG_ETH_MIRROR_INFO_BEGIN    (IFM_ETH_TYPE_CODE_BASE + 23)
#define IFM_CONFIG_ETH_MIRROR_INGRESS_SEND  (IFM_ETH_TYPE_CODE_BASE + 24)
#define IFM_CONFIG_ETH_MIRROR_EGRESS_SEND   (IFM_ETH_TYPE_CODE_BASE + 25)
#define IFM_CONFIG_ETH_MIRROR_TOINFO_SEND   (IFM_ETH_TYPE_CODE_BASE + 26)
#define IFM_CONFIG_ETH_MIRROR_INFO_END      (IFM_ETH_TYPE_CODE_BASE + 27)
#define IFM_CONFIG_ETH_MIRROR_INGEG         (IFM_ETH_TYPE_CODE_BASE + 28)
#define IFM_CONFIG_ETH_MIRROR_CLR           (IFM_ETH_TYPE_CODE_BASE + 29) 
#define IFM_CONFIG_ETH_MIRROR_PFMT          (IFM_ETH_TYPE_CODE_BASE + 30) 

#define IFM_CONFIG_ETH_CLRSTATS             (IFM_ETH_TYPE_CODE_BASE + 31)
#define IFM_CONFIG_ETH_CSTSTATE             (IFM_ETH_TYPE_CODE_BASE + 32)
#define IFM_CONFIG_ETH_MSTSTATE             (IFM_ETH_TYPE_CODE_BASE + 33)
#define IFM_CONFIG_ETH_ABILITY              (IFM_ETH_TYPE_CODE_BASE + 34)

#define IFM_CONFIG_ETH_GBICPLUG             (IFM_ETH_TYPE_CODE_BASE + 35)
#define IFM_CONFIG_ETH_ISGBIC               (IFM_ETH_TYPE_CODE_BASE + 36)

#define IFM_CONFIG_ETH_DEFAULT_ATTRIBUTE    (IFM_ETH_TYPE_CODE_BASE + 37)
#define IFM_CONFIG_ETH_CONFIG_ABILITY       (IFM_ETH_TYPE_CODE_BASE + 38)

#define IFM_CONFIG_ETH_MAXSPEED             (IFM_ETH_TYPE_CODE_BASE + 39)

#define IFM_CONFIG_ETH_GBIC_INFO            (IFM_ETH_TYPE_CODE_BASE + 40)


#define IFM_CONFIG_ETH_INGRESSRULE          (IFM_ETH_TYPE_CODE_BASE + 41)
#define IFM_CONFIG_ETH_EGRESSRULE           (IFM_ETH_TYPE_CODE_BASE + 42)
#define IFM_CONFIG_ETH_VLANMATCH            (IFM_ETH_TYPE_CODE_BASE + 43)
#define IFM_CONFIG_ETH_LOOPBACK_MODE		(IFM_ETH_TYPE_CODE_BASE + 44 )
#define IFM_CONFIG_ETH_TRUNKACCESS_MODE		(IFM_ETH_TYPE_CODE_BASE + 45 )

#define IFM_CONFIG_ETH_15MIN24HOUR          (IFM_ETH_TYPE_CODE_BASE + 46 )
#define IFM_CONFIG_ETH_INGRESS_LINERATE     (IFM_ETH_TYPE_CODE_BASE + 47 )
#define IFM_CONFIG_ETH_EGRESS_LINERATE      (IFM_ETH_TYPE_CODE_BASE + 48 )
#define IFM_CONFIG_ETH_ISOLATE              (IFM_ETH_TYPE_CODE_BASE + 49 )

#define IFM_CONFIG_ETH_STORMCRTL_BCAST      (IFM_ETH_TYPE_CODE_BASE + 49 )
#define IFM_CONFIG_ETH_STORMCRTL_MCAST      (IFM_ETH_TYPE_CODE_BASE + 50 )
#define IFM_CONFIG_ETH_STORMCRTL_DLF        (IFM_ETH_TYPE_CODE_BASE + 51 )

#define IFM_CONFIG_ETH_MEDIA         		(IFM_ETH_TYPE_CODE_BASE + 52)

#define IFM_INTER_CONNECT_TPID            	(IFM_ETH_TYPE_CODE_BASE + 53)
#define IFM_CONFIG_ETH_INTERCON_STATS       (IFM_ETH_TYPE_CODE_BASE + 54)
#define IFM_CONFIG_ETH_DCN_STATE            (IFM_ETH_TYPE_CODE_BASE + 55)
#define IFM_CONFIG_ETH_PROTECT_PARTNER      (IFM_ETH_TYPE_CODE_BASE + 56)
#define IFM_CONFIG_ETH_PROTECT_SWAPPER      (IFM_ETH_TYPE_CODE_BASE + 57)

#define IFM_CONFIG_ETH_L2_LEARN_LIMIT       (IFM_ETH_TYPE_CODE_BASE + 58)
#define IFM_CONFIG_ETH_VLAN_CHECK         	(IFM_ETH_TYPE_CODE_BASE + 59)
#define IFM_CONFIG_ETH_COS_LINERATE       	(IFM_ETH_TYPE_CODE_BASE + 60)
#define IFM_CONFIG_ETH_MEDIA_FROM_HARDWARE 	(IFM_ETH_TYPE_CODE_BASE + 61)
#define IFM_CONFIG_INTERSLOT_INGRESS_LINERATE (IFM_ETH_TYPE_CODE_BASE + 62)
#define IFM_CONFIG_INTERSLOT_EGRESS_LINERATE (IFM_ETH_TYPE_CODE_BASE + 63)
#define IFM_CONFIG_ETH_JUMBOMTU				(IFM_ETH_TYPE_CODE_BASE + 64)
#define IFM_CONFIG_ETH_QINQNNI_MODE_DEF		(IFM_ETH_TYPE_CODE_BASE + 65)

#define IFM_CONFIG_ETH_INGRESS_SAVE_DATA    (IFM_ETH_TYPE_CODE_BASE + 66)
#define IFM_CONFIG_ETH_EGRESS_SAVE_DATA     (IFM_ETH_TYPE_CODE_BASE + 67)


/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_DEF_H__ */

