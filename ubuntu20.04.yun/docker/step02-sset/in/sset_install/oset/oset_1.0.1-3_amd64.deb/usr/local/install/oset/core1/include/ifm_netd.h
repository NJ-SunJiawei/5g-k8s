/****************************************************************************
** Copyright (c) 2019.
** All rights reserved.
**
** File name:ifm_netd.h
** Description:header file of ifm_netd.c
**
** Current Version: 1.0
** Author: zhangjian (zhangjian@sylincom.com)
** Date: 20190613
****************************************************************************/

#ifndef __IFM_NETD_H__
#define __IFM_NETD_H__

#ifdef __cplusplus
extern "C"
 {
#endif


/******************************   Begin of File Body  ********************/

/* Standard interface flags. */
#define	IFF_UP_FLAG				0x1			/** interface is up */
#define	IFF_BROADCAST_FLAG		0x2			/** broadcast address valid */
#define	IFF_DEBUG_FLAG			0x4			/** turn on debugging */
#define	IFF_LOOPBACK_FLAG		0x8			/** is a loopback net */
#define	IFF_POINTOPOINT_FLAG	0x10		/** interface is point-to-point link */
#define	IFF_NOTRAILERS_FLAG		0x20		/** avoid use of trailers */
#define	IFF_RUNNING_FLAG		0x40		/** resources allocated */
#define	IFF_NOARP_FLAG			0x80		/** no address resolution protocol */
#define	IFF_PROMISC_FLAG		0x100		/** receive all packets */
#define	IFF_ALLMULTI_FLAG		0x200		/** receive all multicast packets */
#define	IFF_OACTIVE_FLAG		0x400		/** transmission in progress */
#define	IFF_SIMPLEX_FLAG		0x800		/** can't hear own transmissions */
#define	IFF_LINK0_FLAG			0x1000		/** per link layer defined bit */
#define	IFF_LINK1_FLAG			0x2000		/** per link layer defined bit */
#define IFF_NULL_FLAG     		0x4000    	/** null interface, take the place of  LINK2 */
#define	IFF_MULTICAST_FLAG		0x8000		/** supports multicast */

/*extend interface flags.*/
#define IFF_VOLATILE_FLAG				(IFF_LOOPBACK_FLAG|IFF_POINTOPOINT_FLAG|IFF_BROADCAST_FLAG)
#define IFF_NOVLAN_FLAG					0x10000		/**  */
#define IFF_NOIP_FLAG					0x20000		/**  */
#define IFF_LINK_FLAG					0x40000		/**  */
#define IFF_ADMINSHUTDOWN_FLAG 			0x80000		/** user set shutdown 0:shutdown*/
#define IFF_MIRROR_FLAG					0x100000	/**	user set mirror enable */
#define IFF_QUEMODEWRR_FLAG				0x200000	/**	user set QUE MODE ,IF SET THIS FLAG,THEN THE MODE IS WRR MODE */
#define IFF_REMARKING_FLAG				0x400000	/**	user set REMARKING enable */
#define IFF_L2VPNEN_FLAG				0x800000	/**  */
#define IFF_ACCESSLIMITED_FLAG			0x01000000	/**  */
#define IFF_DISFDBLEARN_FLAG			0x02000000	/**  */
#define IFF_SUBVLAN_FLAG				0x04000000	/**  */
#define IFF_SUPERVLAN_FLAG				0x08000000	/**  */
#define IFF_DYNAMIC_FLAG				0x10000000	/** dialup device with changing addresses*/
#define IFF_TRUNKMASTER_FLAG			0X20000000	/**  */
#define IFF_SETSTATIC_ROUTE_FLAG        0X40000000
#define IFF_EXT_FLAG					0X80000000	/**  */


typedef struct tagExtend_IP
{
    ULONG ulIP;
    ULONG ulMask;
    UCHAR aucDevAddr[ IFM_PHY_ADD_LEN ];
    UCHAR ucActive;
    UCHAR ucExtendIpFlag;
    ULONG ulRange;
    struct tagExtend_IP * pNext;
}IFM_EXTEND_IP_S;

typedef struct tag_IFM_BINDING_IP
{
    ULONG ulIP;
    struct tag_IFM_BINDING_IP *pNext;
}IFM_BINDING_IP_S;

#define IFM_IPINFO_FLAG_BINDING  (1U << 0)
#define IFM_IPINFO_BINDING_IP_NUM		96

typedef struct tagIP_Info
{
    IFM_EXTEND_IP_S     stExtendIP;
    VOID                *pIpInfo;
    //ULONG               ulVpnInfo;
    ULONG               ulFlag;
    IFM_BINDING_IP_S    stBindingIP;
    ULONG   ulBindingIpCount;
}IFM_IP_INFO_S;

typedef struct net_device
{
#if 1 
	ULONG ulReserve1;
	ULONG ulReserve2;
	ULONG ulReserve3;
	ULONG ulReserve4;
#endif
    ULONG               ulIfIndex;						/*接口索引*/
    ULONG               ulUsed;							/*是否已使用*/
    ULONG               flags;							/*接口访问受限、*/
    ULONG               ulMTU;							/*最大传输单元*/
    ULONG               ulJumboMTU;						/**/
    VOID                *pPrivateData;					/*接口的私有数据，对应具体接口类型*/
    IFM_IP_INFO_S       stIpInfo;						/*IP地址信息*/
    ULONG		    	ulIpv6Enable;					/**/
    //struct inet6_dev    *ip6_ptr;   /* IPv6 specific data */
    IFM_IF_ABILITY_S    stAbility;						/*接口能力列表*/
    UCHAR               ucPhyState;						/*接口物理状态*/
    UCHAR               ucDefaultAdminState;			/*接口的默认管理状态*/
    UCHAR               ucAdminState;					/*接口的管理状态*/
    CHAR                szName[ IFM_NAME_SIZE + 1 ];    /*eg.eth2/1 */
    CHAR                szIfDescr[ IFM_MAX_DESCR_LEN + 1 ]; 	/*接口描述*/
    BOOL                bUnnumberedIpBind;							/**/
    CHAR                szUnnumberedIfName[ IFM_NAME_SIZE + 1 ];	/**/
}IFM_NET_DEVICE_S;

CHAR *dev_show_common( IFM_NET_DEVICE_S *pstNetDev );


/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_NETD_H__ */

