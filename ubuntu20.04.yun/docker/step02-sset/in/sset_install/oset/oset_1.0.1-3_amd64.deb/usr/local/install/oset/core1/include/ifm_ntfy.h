/**
 * @file ifm_ntfy.h
 * @brief ifm_ntfy.h 头文件
 * @details 接口管理通知链相关信息
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2019.06.20
 * @copyright 
 *	  Copyright (c) 2019 Sylincom.
 *	  All rights reserved.
*/

#ifndef __IFM_NTFY_H__
#define __IFM_NTFY_H__

#ifdef __cplusplus
extern "C"
 {
#endif


/******************************   Begin of File Body  ********************/
/** 接口管理相关事件通知定义*/
/** 接口up */
#define NETDEV_UP                (0x0001)

/** 接口down */
#define NETDEV_DOWN              (0x0002)

/** 接口注册 */
#define NETDEV_REGISTER          (0x0003)

/** 接口注销 */
#define NETDEV_UNREGISTER        (0x0004)

/** 接口即将down */
#define NETDEV_GOING_DOWN        (0x0005)

/** 接口名称改变 */
#define NETDEV_CHANGENAME        (0x0006)

/** 接口MTU改变 */
#define NETDEV_MTUCHG            (0x0007)

/**  */
#define NETDEV_METRICCHG         (0x0008)
/**  */
#define NETDEV_RDBINDCHG         (0x0009)

/** 接口速率改变 */
#define NETDEV_BWCHG             (0x000A)

/** 接口强制up */
#define NETDEV_NOSHUTDOWN        (0x000B)

/** 接口强制down */
#define NETDEV_SHUTDOWN          (0x000C)

/** vlan中加入接口 */
#define NETDEV_VLANADDIF         (0x000D)

/** vlan中删除接口 */
#define NETDEV_VLANDELIF         (0x000E)

#define NETDEV_FATHERADDVLAN     (0x000F)
#define NETDEV_FATHERDELVLAN     (0x0010)

/** 接口上配MAC */
#define NETDEV_PHYADDCHG         (0x0011)

/** 二层转发使能 */
#define NETDEV_L2FORWARDON       (0x0012)

/** 二层转发关闭 */
#define NETDEV_L2FORWARDOFF      (0x0013)

/** 接口上MAC改变 */
#define NETDEV_CHANGEADDR		 (0x0014)

/** 接口上光纤接入 */
#define NETDEV_PLUGIN            (0x0015) 

/** 接口上光纤拔出 */
#define NETDEV_PLUGOUT           (0x0016)

/** 从vlan中删除接口 */
#define NETDEV_DELETFROMVLAN     (0X0017)

/** IPV6使能 */
#define NETDEV_IPV6_ENABLE		 (0x0018)

/** IPV6禁止 */
#define NETDEV_IPV6_DISABLE		 (0x0019)

#define NETDEV_SF                (0x001A)
#define NETDEV_SF_CLEAR          (0x001B)

/** TRUNK 主接口改变 */
#define	NETDEV_TRUNKMSATERPORT_CHG 	(0x001C)	
#define NETDEV_TRUNK_CHG       		(0x001D)

#define NOTIFY_DONE          0x0000/* Don't care */
#define NOTIFY_OK            0x0001/* Suits me */
#define NOTIFY_STOP_MASK     0x8000/* Don't call further */
#define NOTIFY_BAD           (NOTIFY_STOP_MASK|0x0002)/* Bad/Veto action	*/

/** 接口管理通知链        NETDEV类型 */
#define IFM_NOTIFY_CHAIN_NETDEV       (1)

/** 接口管理通知链        ADDR类型 */	/*目前未使用*/
#define IFM_NOTIFY_CHAIN_INETADDR     (2)	


/** 接口管理通知链通知事件信息结构 */
typedef union IFM_EventInfo_U
{
    /**/
    struct
    {
        ULONG unPhyIfIndex;			/**/
        ULONG ulTrunkMaster;
        ULONG ulType;
        ULONG ulForwardType;
        ULONG ulVlanPortRelation;/*IFM_VLAN_PORT_DYNAMIC etc*/
    }stAddPort;
	
    struct
    {
        ULONG unPhyIfIndex;			/**/
        ULONG ulTrunkMaster;
        ULONG ulType;
        ULONG ulForwardType;
        ULONG ulVlanPortRelation;/*IFM_VLAN_PORT_DYNAMIC etc*/
    }stDelPort;

    struct
    {
        ULONG ulVlanIndex;
    }stAddDelVlan;
	
    struct
    {
        ULONG ulMasterIfindex;
		ULONG ulUpdateIfindex;
		ULONG ulUpFlag;
    }stTrunk;
	
    struct
    {
        ULONG ulType;
        ULONG ulForwardType;
    }stVlan;
	
    struct
    {
        ULONG   ulSubIfIndex;
        USHORT  usVid; /* maybe-zero */
        USHORT  usReserve;
    } stSubIf;

} IFM_EVENTINFO_U;

/** 接口管理通知链NETDEV 通知信息结构 */
typedef struct IFM_DevNotifyMsg_S
{
    ULONG   ulIfIndex;                      ///< 接口索引
    //ULONG   ulVrfId;
    ULONG   flags;							///< 标识
    ULONG   ulMTU;							///< MTU
    ULONG   ulJumboMTU;						///< Jumbo MTU
    ULONG   ulL3Care;                       ///< 三层是否关心
	ULONG 	ulLocal;						///< 是否local
    UCHAR   ucPhyState;                     ///< 接口物理状态
    UCHAR   ucAdminState;                   ///< 接口管理状态
    UCHAR   aucPad[2];
    CHAR    szName[IFM_NAME_SIZE + 1];      ///< 接口名称
    IFM_EVENTINFO_U pEventInfo;				///< 事件对应的信息				
}IFM_DEVNOTIFYMSG;

/** 接口管理通知链ADDR 通知信息结构 */
typedef struct IFM_AddrNotifyMsg_S
{
    ULONG   ulIfIndex;				        /**/
    ULONG   ulVrfId;
    ULONG   flags;
    ULONG   ulMTU;
    ULONG   ulL3Care;
    UCHAR   ucPhyState;                     /**/
    UCHAR   ucAdminState;                   /**/
    UCHAR   aucPad[2];
    ULONG   ulIpAddr;					    /**/
    ULONG   ulMask;					        /**/
    ULONG   ulIpBdcast;			            /**/
    ULONG   ulFlags;					    /**/
    CHAR    szName[IFM_NAME_SIZE + 1];      /**/
    IFM_EVENTINFO_U pEventInfo;
}IFM_ADDRNOTIFYMSG;

/** 
 * 发送接口管理通知链事件消息
 * @param[in ]  ULONG ulType   					通知链类型（NETDEV/ADDR）
 * @param[in ]  ULONG ulEvent    				事件类型
 * @param[in ] 	VOID * di    					通知链信息结构
 * @param[in ] 	IFM_EVENTINFO_U *pEventInfo    	事件信息结构，选填
 * @param[in ] 	ULONG ulEventInfoLen    		事件信息结构的长度，有pEventInfo需填长度
 * @return      成功返回VOS_OK，失败返回其他
 */
LONG IFM_NotifyCallChainApi( ULONG ulType, ULONG ulEvent, VOID * di, IFM_EVENTINFO_U *pEventInfo, ULONG ulEventInfoLen );


/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_NTFY_H__ */

