/**
 * @file ifm_pub.h
 * @brief ifm_pub.h 头文件
 * @details 接口管理模块公共信息
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2019.06.13
 * @copyright 
 *    Copyright (c) 2019 Sylincom.
 *    All rights reserved.
*/

#ifndef __IFM_PUB_H__
#define __IFM_PUB_H__

#ifdef __cplusplus
extern "C"
 {
#endif

/******************************   Begin of File Body  ********************/
extern USHORT IFM_VlanGetVIDApi( ULONG ulIfIdx);
extern ULONG IFM_TRUNK_GET_TRUNKID( ULONG ulIfIndex );
extern ULONG IFM_ETH_GET_SLOT( ULONG ulIfIndex );
extern ULONG IFM_ETH_GET_PORT( ULONG ulIfIndex );
extern ULONG IFM_ETH_CREATE_INDEX( ULONG ulSlot, ULONG ulPort );
extern ULONG IFM_VLAN_CREATE_INDEX( ULONG ulVLANId );
extern ULONG IFM_TRUNK_CREATE_INDEX( ULONG ulTrunkID );

#if 1
#define IFM_F_PRIMARY       0X00	/**/
#define IFA_F_SECONDARY     0x01    /* secondary addr */
#define IFA_F_UNNUMBER      0x02	/* secondary addr */
#endif 

/** 接口类型 */
typedef enum _IFM_INTERFACE_TYPE
{
	IFM_INTERFACE_TYPE_MIN = 0,
	IFM_ETH_TYPE,					///< 以太网类型接口
	IFM_VLAN_TYPE,					///< vlan类型接口
	IFM_SVLAN_TYPE,					///< 超级vlan类型接口
	IFM_TRUNK_TYPE,					///< trunk类型接口
	IFM_MAX_TYPE  					///< 接口最大类型
}IFM_INTERFACE_TYPE_E;

/** 
 * 通过接口索引解析接口类型
 * @param[in ]   ulIfindex   	接口索引
 * @return       接口类型
 */
ULONG IFM_IFINDEX_GET_TYPE( ULONG ulIfindex );


#define IFM_IS_ETH_IF(ulIfIndex)		    (IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_ETH_TYPE)
#define IFM_IS_VLAN_IF(ulIfIndex)			(IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_VLAN_TYPE ||IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_SVLAN_TYPE)
#define IFM_IS_TRUNK_IF(ulIfIndex)			(IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_TRUNK_TYPE)

/** 判断接口是否是以太网类型 */
#define SYS_IS_ETH_IF(ulIfIndex)		    (IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_ETH_TYPE)

/** 判断接口是否是vlan类型 */
#define SYS_IS_VLAN_IF(ulIfIndex)			(IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_VLAN_TYPE ||IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_SVLAN_TYPE)

/** 判断接口是否是超级vlan类型 */
#define SYS_IS_SVLAN_IF(ulIfIndex)			 (IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_SVLAN_TYPE)

/** 判断接口是否是trunk类型 */
#define SYS_IS_TRUNK_IF(ulIfIndex)			(IFM_IFINDEX_GET_TYPE(ulIfIndex) == IFM_TRUNK_TYPE)

/** 通过接口索引解析vlan ID */
#define SYS_IF_VLAN_ID(unIfIndex)			(IFM_VlanGetVIDApi(unIfIndex))

/** 通过接口索引解析trunk ID */
#define SYS_IF_TRUNK_ID(unIfIndex)          (IFM_TRUNK_GET_TRUNKID(unIfIndex))

/** 通过接口索引解析slot */
#define SYS_IF_SLOT_ID(unIfIndex)			(IFM_ETH_GET_SLOT(unIfIndex))

/** 通过接口索引解析port */
#define SYS_IF_PORT_ID(unIfIndex)			(IFM_ETH_GET_PORT(unIfIndex))

/** 以ulSlot和ulPort创建物理接口unIfIndex */
#define SYS_CREATE_PHY_IF(unIfIndex, ulSlot, ulPort)  {unIfIndex = IFM_ETH_CREATE_INDEX(ulSlot,ulPort);}

/** 以usVlanID创建vlan接口unIfIndex */
#define SYS_CREATE_VLAN_IF(unIfIndex,usVlanID)  {unIfIndex = IFM_VLAN_CREATE_INDEX(usVlanID);} 

/** 以usTrunkID创建trunk接口unIfIndex */
#define SYS_CREATE_TRUNK_IF(unIfIndex,usTrunkID)  { unIfIndex = IFM_TRUNK_CREATE_INDEX(usTrunkID);}

/*******************************  End of File Body ***********************/

#ifdef	__cplusplus
}
#endif/* __cplusplus */

#endif/* __IFM_PUB_H__ */

