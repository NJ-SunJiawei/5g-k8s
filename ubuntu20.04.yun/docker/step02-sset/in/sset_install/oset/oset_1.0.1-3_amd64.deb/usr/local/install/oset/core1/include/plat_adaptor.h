/******************************************************************
** Copyright (c) .
** All rights reserved.
**
** File name:plat_adaptor.h
** Description:header file of platform adaptor.
**
** Current Version: 1.0
** Author: zhangjian (zhangjian@sylincom.com)
** Date: 20190213
******************************************************************/

#ifndef _CDSMS_PLATFORM_ADAPTOR_H_
#define _CDSMS_PLATFORM_ADAPTOR_H_


#ifdef __cplusplus
extern "C"
{
#endif

/******************************   Begin of File Body  ********************/

#define MAX_MASTER_SLOTNUM 		2 		/*最多主控个数*/

#define SERIALNO_LEN			32				/*序列号长度*/
#define MANUFACTURE_DATE_LEN	12				/*生产日期长度*/
//#define FIRST_BOOTROM_LEN 16
#define VERSION_LEN				64				/*版本长度*/
#define PRODUCT_NAME_LEN 		32				/*产品名称长度*/
#define BOARD_NAME_LEN			32				/*板卡名称长度*/


/*****************************************************************/
/*****************         resource_info       ***************************/
/*****************************************************************/
typedef struct _resource_info_s
{
	UCHAR serialno[SERIALNO_LEN];					/*sn号*/
	UCHAR manufacture_date[MANUFACTURE_DATE_LEN];	/*生产日期*/
	UCHAR hardware_version[VERSION_LEN];			/*硬件版本*/
}resource_info_t;

typedef struct _chassis_resource_info_s
{
	UCHAR powersupply_type;				/*电源类型*/			/*保留*/
	resource_info_t production_info;	/*生产信息*/
}chassis_resource_info_t;


/*****************************************************************/
/*****************         product_info        ***************************/
/*****************************************************************/
typedef struct _cdsms_product_register_func_s
{
	LONG (*sys_reset) (VOID);										/*系统复位*/
	LONG (*get_product_type) (ULONG *productType);					/*获取产品类型*/
	LONG (*get_product_name) (UCHAR *product_name, ULONG max_len);	/*获取产品名称*/
	LONG (*get_product_devIndex) (ULONG *devIndex);					/*获取产品设备索引*/
	LONG (*get_mib_product_type) (ULONG sys_productType);			/*获取mib使用的产品类型*/
	
#if 0
	LONG (*get_vos_memory_len)(ULONG *vos_memory_len);		/*获取slab模块申请的用户内存大小 Mb*/	
	LONG (*get_alarm_max_num) (ULONG *alarm_max_num);		/*获取告警最大可记录数目*/
	LONG (*get_alarm_path) (UCHAR *path, ULONG max_len);	/*获取告警文件位置*/
	LONG (*get_syslog_max_num) (ULONG *syslog_max_num);		/*获取syslog最大可记录数目*/
	LONG (*get_syslog_path) (UCHAR *path, ULONG max_len);	/*获取syslog文件位置*/
	LONG (*alarm_file_write)(void *buff, INT32 size);		/*写告警文件操作*/
	LONG (*alarm_file_read)(void *buff, INT32 size);		/*读告警文件操作*/
	LONG (*syslog_file_write)(void *buff, INT32 size);		/*写syslog文件操作*/
	LONG (*syslog_file_read)(void *buff, INT32 size);		/*读syslog文件操作*/
#endif
}cdsms_product_register_func_t;

typedef struct _cdsms_product_info_s
{
	ULONG product_type;							/*产品类型*/
	UCHAR product_name[PRODUCT_NAME_LEN];		/*产品名称*/
	ULONG netid;								/*保留*/
	cdsms_product_register_func_t family_func;/*产品相关注册函数*/
}cdsms_product_info_t;


/*****************************************************************/
/*****************         chassis_info       ****************************/
/*****************************************************************/
typedef struct _chassis_type_info_s
{
  ULONG slotnum;											/*产品最大槽位号*/
  ULONG master_slotnum;									/*主控槽位个数*/
  ULONG masterslotno[ MAX_MASTER_SLOTNUM + 1 ];			/*记录主控槽位号*/
}chassis_type_info_t;

typedef struct _cdsms_chassis_register_func_s
{
	LONG (*get_chassis_max_slotnum)(ULONG *slotnum);		/*获取最大槽位号*/
	LONG (*get_chassis_master_slotinfo)(ULONG *master_slotnum, ULONG *master_slotno);/*获取主控个数和主控槽位号*/
}cdsms_chassis_register_func_t;

typedef struct _cdsms_chassis_info_s
{
	chassis_type_info_t fixed_info;					/*产品机框固定信息*/
	cdsms_chassis_register_func_t family_func;		/*机框相关注册函数*/
} cdsms_chassis_info_t;


/*****************************************************************/
/*****************           module_info       ***************************/
/*****************************************************************/
typedef struct _cdsms_module_pub_info_s
{
	ULONG module_type;							/*板卡类型*/
	ULONG have_cpu;								/*是否有CPU，VOS_YES/VOS_NO*/
	ULONG have_pp;								/*是否有交换芯片，VOS_YES/VOS_NO*/
	ULONG have_fpgaPP;							/*FGPA芯片处理能力，VOS_YES/VOS_NO*/
	UCHAR module_name[BOARD_NAME_LEN];			/*板卡名称*/
	UCHAR sw_ver[VERSION_LEN];					/*软件版本*/
	resource_info_t production_info;			/*资产信息*/
}cdsms_module_pub_info_t;

typedef struct _cdsms_sub_slot_register_func_s
{
	LONG (*sub_slot_inserted)(ULONG slotno);	/*子板在位检测*/	/*保留*/
}cdsms_sub_slot_register_func_t;

typedef struct _cdsms_slot_register_func_s
{
	LONG (*slot_inserted)(ULONG slotno);					/*单板在位检测*/	
	LONG (*slot_type)(ULONG slotno);						/*单板类型获取*/	
	LONG (*slot_reset)(ULONG slotno, ULONG module_type);	/*单板复位*/
	LONG (*slot_open)(ULONG slotno, ULONG module_type);		/*板卡安装*/
	LONG (*slot_close)(ULONG slotno, ULONG module_type);	/*板卡卸载*/
	LONG (*slot_compare_version)(ULONG slotno, ULONG module_type);	/*版本比较*/
	LONG (*slot_update_version)(ULONG slotno, ULONG module_type);	/*版本升级*/
	LONG (*get_slot_update_results)(ULONG slotno, ULONG module_type);/*获取版本升级结果*/
	LONG (*get_module_sw_version)( ULONG slotno, ULONG module_type, UCHAR *sw_version, ULONG max_len);			/*获取板卡软件版本信息*/
	LONG (*get_module_serialno)(ULONG slotno, ULONG module_type, UCHAR *serialno, ULONG max_len);					/*获取序列号*/
	LONG (*get_module_manufacture_date)(ULONG slotno, ULONG module_type, UCHAR *manufacture_date, ULONG max_len);	/*获取生产日期*/
	LONG (*get_module_hardware_version)(ULONG slotno, ULONG module_type, UCHAR *hardware_version, ULONG max_len);	/*获取硬件版本号*/
	LONG (*get_module_name)( ULONG slotno, ULONG module_type, UCHAR *moduleName, ULONG max_len);					/*获取板卡名称*/
	LONG (*get_module_have_cpu)(ULONG slotno, ULONG module_type);		/*获取板卡有无CPU*/
	LONG (*get_module_have_pp)(ULONG module_type);						/*获取板卡有无PP*/
	LONG (*get_module_have_fpgaPP)(ULONG module_type);					/*获取板卡有无fpgapp*/
	LONG (*get_module_port_type_num)(ULONG slotno, ULONG port_type);	/*获取板卡有几个port_type类型的接口*/
	LONG (*get_module_port_mac)(ULONG slotno, ULONG port, UCHAR *mac, ULONG max_len);	/*获取板卡port上的MAC*/
	LONG (*hot_insert_notify_listener)(ULONG slotno, ULONG module_type);	/*板卡热插入通知产品模块处理接口*/
	LONG (*hot_pull_notify_listener)(ULONG slotno, ULONG module_type);		/*板卡热拔出通知产品模块处理接口*/
	
	LONG (*get_local_module_slotno)(ULONG *slotno);					/*获取本板槽位号*/
	LONG (*get_local_module_type)(ULONG slotno, ULONG *module_type);/*获取本板类型*/
	LONG (*get_local_module_workmode)(ULONG slotno, ULONG module_type, ULONG *workmode);	/*获取本板工作模式*/
}cdsms_slot_register_func_t;

typedef struct _cdsms_module_info_s
{
	ULONG slotno;							/*本板槽位号*/
    ULONG sub_slotnum; 					/*保留*/
	cdsms_module_pub_info_t *pub_info;		/*板卡公共信息*/
	cdsms_slot_register_func_t slot_family;	/*槽位板卡相关注册函数*/
	cdsms_sub_slot_register_func_t sub_slot_family;	/*子槽位板卡相关注册函数*/  				/*保留*/
}cdsms_module_info_t;

/*产品、机框、板卡相关信息及注册函数*/
typedef struct _cdsms_hardware_info_s
{
	cdsms_product_info_t product;			/*产品相关信息*/
	cdsms_chassis_info_t chassis;			/*机框相关信息*/
	cdsms_module_info_t module;				/*板卡相关信息*/
}cdsms_hardware_info_t;

/*设备管理状态机各状态执行函数*/
typedef struct _cdsms_runningstate_register_func_s
{
	VOID (*module_before_inserted_proc)(VOID);		/*板卡在位前的处理函数*/
	VOID (*module_inserted_proc) (VOID);			/*板卡插入状态执行函数*/
	VOID (*module_initializing_proc) (VOID);		/*板卡初始化状态执行函数*/
	VOID (*module_registering_proc) (VOID);			/*板卡注册状态执行函数*/
	VOID (*module_registered_proc) (VOID);			/*板卡注册完成状态执行函数*/
	VOID (*module_sys_discovering_proc) (VOID);		/*系统单板发现状态执行函数*/
	VOID (*module_ready_proc) (VOID);				/*板卡ready状态执行函数*/
	VOID (*module_sys_ready_proc) (VOID);			/*系统ready状态执行函数*/
	VOID (*module_enabling_proc) (VOID);			/*板卡使能状态执行函数*/
	VOID (*module_running_proc) (VOID);				/*running状态执行函数*/
}cdsms_runningstate_register_func_t;


/*平台适配层结构*/
typedef struct _cdsms_platform_adaptor_info_s
{
	cdsms_hardware_info_t hardware_env;				/*产品、机框、板卡相关信息及注册函数*/
	cdsms_runningstate_register_func_t runningstate_func;	/*设备管理状态机各状态执行函数*/
}cdsms_platform_adaptor_info_t;

extern cdsms_platform_adaptor_info_t cdsms_platform_adaptor;	/*平台适配层结构*/

#define CDSMS_PRODUCT_SYS_RESET_FUN (cdsms_platform_adaptor.hardware_env.product.family_func.sys_reset)
#define CDSMS_PRODUCT_SYS_RESET() ((*cdsms_platform_adaptor.hardware_env.product.family_func.sys_reset)())

#define CDSMS_PRODUCT_TYPE_FUN (cdsms_platform_adaptor.hardware_env.product.family_func.get_product_type)
#define CDSMS_PRODUCT_TYPE(productType) ((cdsms_platform_adaptor.hardware_env.product.family_func.get_product_type)(productType))

#define CDSMS_PRODUCT_NAME_FUN (cdsms_platform_adaptor.hardware_env.product.family_func.get_product_name)
#define CDSMS_PRODUCT_NAME(product_name, max_len) ((cdsms_platform_adaptor.hardware_env.product.family_func.get_product_name)(product_name, max_len))

#define CDSMS_PRODUCT_DEV_INDEX_FUN (cdsms_platform_adaptor.hardware_env.product.family_func.get_product_devIndex)
#define CDSMS_PRODUCT_DEV_INDEX(dev_index) ((cdsms_platform_adaptor.hardware_env.product.family_func.get_product_devIndex)(dev_index))

#define CDSMS_MIB_PRODUCT_TYPE_FUN (cdsms_platform_adaptor.hardware_env.product.family_func.get_mib_product_type)
#define CDSMS_MIB_PRODUCT_TYPE(sys_productType) ((cdsms_platform_adaptor.hardware_env.product.family_func.get_mib_product_type)(sys_productType))

#define CDSMS_CHASSIS_MAX_SLOTNUM_FUN (cdsms_platform_adaptor.hardware_env.chassis.family_func.get_chassis_max_slotnum)
#define CDSMS_CHASSIS_MAX_SLOTNUM(slotnum) ((*cdsms_platform_adaptor.hardware_env.chassis.family_func.get_chassis_max_slotnum)(slotnum))

#define CDSMS_CHASSIS_MASTER_SLOTINFO_FUN (cdsms_platform_adaptor.hardware_env.chassis.family_func.get_chassis_master_slotinfo)
#define CDSMS_CHASSIS_MASTER_SLOTINFO(master_slotnum, master_slotno) ((*cdsms_platform_adaptor.hardware_env.chassis.family_func.get_chassis_master_slotinfo)(master_slotnum, master_slotno))

#define CDSMS_MODULE_SUBLOT_INSERTED_FUN (cdsms_platform_adaptor.hardware_env.module.sub_slot_family.sub_slot_inserted)
#define CDSMS_MODULE_SUBSLOT_INSERTED(subslotno) ((*cdsms_platform_adaptor.hardware_env.module.sub_slot_family.sub_slot_inserted)(subslotno))

#define CDSMS_CHASSIS_SLOT_INSERTED_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_inserted)
#define CDSMS_CHASSIS_SLOT_INSERTED(slotno) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_inserted)(slotno))
#define CDSMS_CHASSIS_SLOT_INSERTED_STR(slotno)  ((VOS_YES == (CDSMS_CHASSIS_SLOT_INSERTED(slotno))) ?"Inserted":"Empty")

#define CDSMS_MODULE_SLOT_MODULE_TYPE_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_type)
#define CDSMS_MODULE_SLOT_MODULE_TYPE(slotno) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_type)(slotno))

#define CDSMS_MODULE_SLOT_RESET_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_reset)
#define CDSMS_MODULE_SLOT_RESET(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_reset)(slotno, module_type))

#define CDSMS_MODULE_SLOT_OPEN_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_open)
#define CDSMS_MODULE_SLOT_OPEN(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_open)(slotno, module_type))

#define CDSMS_MODULE_SLOT_CLOSE_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_close)
#define CDSMS_MODULE_SLOT_CLOSE(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_close)(slotno, module_type))

#define CDSMS_MODULE_COMPARE_VERSION_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_compare_version)
#define CDSMS_MODULE_COMPARE_VERSION(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_compare_version)(slotno, module_type))

#define CDSMS_MODULE_UPDATE_VERSION_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.slot_update_version)
#define CDSMS_MODULE_UPDATE_VERSION(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.slot_update_version)(slotno, module_type))

#define CDSMS_MODULE_UPDATE_RESULTS_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_slot_update_results)
#define CDSMS_MODULE_UPDATE_RESULTS(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_slot_update_results)(slotno, module_type))

#define CDSMS_MODULE_SW_VERSION_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_sw_version)
#define CDSMS_MODULE_SW_VERSION(slotno, module_type, sw_version, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_sw_version)(slotno, module_type, sw_version, max_len))

#define CDSMS_MODULE_SERIALNO_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_serialno)
#define CDSMS_MODULE_SERIALNO(slotno, module_type, serialno, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_serialno)(slotno, module_type, serialno, max_len))

#define CDSMS_MODULE_MANUFACTURE_DATE_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_manufacture_date)
#define CDSMS_MODULE_MANUFACTURE_DATE(slotno, module_type, manufacture_date, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_manufacture_date)(slotno, module_type, manufacture_date, max_len))

#define CDSMS_MODULE_HARDWARE_VERSION_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_hardware_version)
#define CDSMS_MODULE_HARDWARE_VERSION(slotno, module_type, hardware_version, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_hardware_version)(slotno, module_type, hardware_version, max_len))

#define CDSMS_MODULE_NAME_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_name)
#define CDSMS_MODULE_NAME(slotno, module_type, moduleName, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_name)(slotno, module_type, moduleName, max_len))

#define CDSMS_MODULE_HAVE_CPU_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_cpu)
#define CDSMS_MODULE_HAVE_CPU(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_cpu)(slotno, module_type))

#define CDSMS_MODULE_HAVE_PP_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_pp)
#define CDSMS_MODULE_HAVE_PP(module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_pp)(module_type))

#define CDSMS_MODULE_HAVE_FPGAPP_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_fpgaPP)
#define CDSMS_MODULE_HAVE_FPGAPP(module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_have_fpgaPP)(module_type))

#define CDSMS_MODULE_PORT_TYPE_NUM_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_port_type_num)
#define CDSMS_MODULE_PORT_TYPE_NUM(slotno, port_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_port_type_num)(slotno, port_type))

#define CDSMS_MODULE_PORT_MAC_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_port_mac)
#define CDSMS_MODULE_PORT_MAC(slotno, port, mac, max_len) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_module_port_mac)(slotno, port, mac, max_len))

#define CDSMS_MODULE_HOT_INSERT_NOTIFY_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.hot_insert_notify_listener)
#define CDSMS_MODULE_HOT_INSERT_NOTIFY(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.hot_insert_notify_listener)(slotno, module_type))

#define CDSMS_MODULE_HOT_PULL_NOTIFY_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.hot_pull_notify_listener)
#define CDSMS_MODULE_HOT_PULL_NOTIFY(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.hot_pull_notify_listener)(slotno, module_type))

#define CDSMS_LOCAL_MODULE_SLOTNO_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_slotno)
#define CDSMS_LOCAL_MODULE_SLOTNO(slotno) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_slotno)(slotno))

#define CDSMS_LOCAL_MODULE_TYPE_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_type)
#define CDSMS_LOCAL_MODULE_TYPE(slotno, module_type) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_type)(slotno, module_type))

#define CDSMS_LOCAL_MODULE_WORKMODE_FUN (cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_workmode)
#define CDSMS_LOCAL_MODULE_WORKMODE(slotno, module_type, workmode) ((*cdsms_platform_adaptor.hardware_env.module.slot_family.get_local_module_workmode)(slotno, module_type, workmode))

#define CDSMS_BEFORE_MODULE_INSERTED_PROC_FUN	(cdsms_platform_adaptor.runningstate_func.module_before_inserted_proc)
#define CDSMS_BEFORE_MODULE_INSERTED_PROC()		((*cdsms_platform_adaptor.runningstate_func.module_before_inserted_proc)())

#define CDSMS_MODULE_REGISTERED_PROC_FUN (cdsms_platform_adaptor.runningstate_func.module_registered_proc)
#define CDSMS_MODULE_REGISTERED_PROC() ((*cdsms_platform_adaptor.runningstate_func.module_registered_proc)())

#define CDSMS_MODULE_READY_PROC_FUN (cdsms_platform_adaptor.runningstate_func.module_ready_proc)
#define CDSMS_MODULE_READY_PROC() ((*cdsms_platform_adaptor.runningstate_func.module_ready_proc)())

#define CDSMS_MODULE_RUNNING_PROC_FUN (cdsms_platform_adaptor.runningstate_func.module_running_proc)
#define CDSMS_MODULE_RUNNING_PROC() ((*cdsms_platform_adaptor.runningstate_func.module_running_proc)())


/*平台适配层模块初始化函数*/
LONG platform_adaptor_init(VOID);


/*******************************  End of File Body ********************/


#ifdef __cplusplus
}
#endif

#endif  /* end of _CDSMS_PLATFORM_ADAPTOR_H_*/


