/**
 * @file plat_cpe.h
 * @brief 平台CPE模块初始化
 * @details 
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2020.06.19
 * @copyright 
 *    Copyright (c) 2019 Sylincom.
 *    All rights reserved.
*/

#ifndef __PLAT_CPE_H__
#define __PLAT_CPE_H__


#ifdef __cplusplus
extern "C"
{
#endif

/******************************   Begin of File Body  **********************/

#define CPE_ALARM_NAME    "CPE_ALARM_MODULE"       

VOID plat_cpe_init();


/*******************************  End of File Body ***********************/

#ifdef __cplusplus
}
#endif

#endif

