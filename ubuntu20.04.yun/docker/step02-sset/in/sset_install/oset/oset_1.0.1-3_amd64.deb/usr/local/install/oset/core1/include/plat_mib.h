/****************************************************************************
** Copyright (c) .
** All rights reserved.
**
** File name:plat_mib.h
** Description:header file of plat_mib.h
**
** Current Version: 1.0
** Author: zhangjian (zhangjian@sylincom.com)
** Date: 20190527
****************************************************************************/

#ifndef __PLAT_MIB_H__
#define __PLAT_MIB_H__

#ifdef __cplusplus
extern "C"
  {
#endif

/******************************   Begin of File Body  ********************/

VOID plat_module_mib_init(VOID);


/*******************************  End of File Body ***********************/

#ifdef __cplusplus
}
#endif

#endif  /* end of __PLAT_MIB_H__ */

