/****************************************************************************
** Copyright (c) .
** All rights reserved.
**
** File name:sys_oid.h
** Description:header file 定义OID长度、定义解析vos.conf文件中OID的关键字
**
** Current Version: 1.0
** Author: zhangjian (zhangjian@sylincom.com)
** Date: 20191204
****************************************************************************/

#ifndef __SYS_OID_H__
#define __SYS_OID_H__

#ifdef __cplusplus
extern "C"
  {
#endif


/******************************   Begin of File Body  ********************/

#define 	SYSTEM_OBJECT_OID_LEN			9
#define 	ALARM_GROUP_OID_LEN				9
#define 	ETH_PORT_OID_LEN				11
#define 	BOARD_INFO_TABLE_OID_LEN		11
#define 	BOARD_HEAL_TABLE_OID_LEN		11
#define 	CHIP_HEAL_TABLE_OID_LEN			11
#define 	FGPA_CHIP_ASSET_TABLE_OID_LEN	11
#define 	CLOCK_SYNC_TABLE_OID_LEN		11
#define 	MAIN_CTRL_MODULE_OID_LEN		9

#define 	OID_KEY						"OID"
#define 	SYSTEM_OBJECT_GROUP_KEY		"OIDConfig.systemObject"
#define 	ALARM_GROUP_KEY				"OIDConfig.alarmModule"
#define 	ETH_PORT_GROUP_KEY			"OIDConfig.ethPortModule"
#define 	BOARD_INFO_TABLE_KEY		"OIDConfig.boardModule.boardInfoTable"
#define 	BOARD_HEAL_TABLE_KEY		"OIDConfig.boardModule.boardHeal"
#define 	CHIP_HEAL_TABLE_KEY			"OIDConfig.boardModule.chipHeal"
#define 	FGPA_CHIP_ASSET_TABLE_KEY	"OIDConfig.boardModule.fpgaChipAsset"
#define 	CLOCK_SYNC_TABLE_KEY		"OIDConfig.boardModule.clockSync"
#define 	MAIN_CTRL_GROUP_KEY			"OIDConfig.mainCtrlModule"
#define 	CUCP_MGMT_GROUP_KEY			"OIDConfig.cucpMgmtModule"
#define 	CUUP_MGMT_GROUP_KEY			"OIDConfig.cuupMgmtModule"
#define     RRU_MGMT_GROUP_KEY          "OIDConfig.rruMgmtModule"


/*******************************  End of File Body ***********************/

#ifdef __cplusplus
}
#endif

#endif  /* end of __SYS_OID_H__ */

