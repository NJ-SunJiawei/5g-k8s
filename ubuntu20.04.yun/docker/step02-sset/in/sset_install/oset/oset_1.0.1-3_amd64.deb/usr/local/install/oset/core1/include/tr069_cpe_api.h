/**********************************************************************************************************************
** 
** Copyright (c) 2008-2019 ICT/CAS.
** All rights reserved.
**
** File name: cpe_api.h
** Description: 
**
** Current Version: 
** $Revision$
** Author: rongtao
** Date: 2020.04
**
***********************************************************************************************************************/
/* Dependencies ------------------------------------------------------------------------------------------------------*/

#ifndef __CPE_OID_REG_H
#define __CPE_OID_REG_H 1


#include "vos_common.h"

#include "tr069_cwmp_api.h"



/* Constants ---------------------------------------------------------------------------------------------------------*/

#define TR069_OID_ITEM_SIZE 64  /* 参数路径单项的最大长度 Device.DeviceInfo.XXXX 中 DeviceInfo的最大长度 */
#define TR069_OID_SIZE      256 /* 参数路径的最大长度  ，Device.DeviceInfo.XXXX 的最大长度             */

#define OID_Writeable   1
#define OID_Unwriteable 0

#define OID_Notification1   1
#define OID_Notification2   2
#define OID_Notification3   3
#define OID_Notification4   4
#define OID_Notification5   5


/* 参数节点类型 Device.DeviceInfo.1.A  A为叶子，其余为枝干          */
enum TR069_OID_ITEM_TYPE {
    TR069_OID_ITEM_TYPE_BRANCH, //枝干
    TR069_OID_ITEM_TYPE_LEAF    //叶子
};

/* 参数节点Object类型 Device.DeviceInfo.1.A 
                                        ^   Table 矢量，其余为Scalar 标量*/
enum TR069_OID_TYPE {
    TR069_OID_TYPE_TABLE,   //表
    TR069_OID_TYPE_SCALAR,  //标量
};

/**
 *  TR069 参数设置类型
 */
typedef enum {
    TR069_SET_VALUE,
    TR069_SET_ATTRIBUTE,
}TR069_SET_TYPE;


/* Types -------------------------------------------------------------------------------------------------------------*/

struct tr069_oid;
struct tr069_oid_leaf;
struct tr069_oid_obj_opt;

/**
 *  参数设置回调函数
 *  说明：
 *      当接口 "tr069_oid_set_parameter_values" 被调用时，该回调函数将被调用。
 *      该回调函数在参数注册时被参数树保存。使用 "tr069_oid_register" 注册。
 *  参数说明：
 *      node        被设置的节点，禁止直接修改该数据结构，会影响参数树的结构。
 *      set_type    参数设置类型， 
 *                      当参数设置类型为 TR069_SET_VALUE， ParamValue 为网管下发的数值
 *                      当参数设置类型为 TR069_SET_ATTRIBUTE ParamValue 为网管下发的 Notification 字符串，如 “1”
 *      isObj       参数路径中是否存在可创建/可删除节点，当存在时，其值为真值，否则为假。
 *                  如: 设置 Device.IP.Interface.1.IPv4Address.2.IPAddress，该值为真。
 *      nObj        参数路径中出现的实例号个数。当 isObj 为真时，该参数可用。
 *                  当参数为 Device.IP.Interface.1.IPv4Address.2.IPAddress 时，nObj==2.
 *      ObjInsNums  参数路径中出现的实例号数组。当 isObj 为真时，该参数可用。
 *                  当参数为 Device.IP.Interface.1.IPv4Address.2.IPAddress 时，ObjInsNums[0]==1, ObjInsNums[1] = 2.
 *      ParamValue  参数字符串，或 Notification 字符串， 类型自己转换
 *      argc        用户注册参数个数，该参数为 "tr069_oid_register" 注册时填写 的 "set_argc"。
 *      argv        用户注册参数，该参数为 "tr069_oid_register" 注册时填写 的 "set_argv"。
 */
typedef void (*tr069_oid_set_fn_t)(struct tr069_oid *node,TR069_SET_TYPE set_type, bool isObj, int nObj, int ObjInsNums[], const char *ParamValue, int argc, void *argv[]);

/**
 *  目标创建回调函数
 *  说明：
 *      当接口 "tr069_oid_add_object" 被调用时，该回调函数将被调用。
 *      该回调函数在参数注册时被参数树保存。使用 "tr069_oid_register" 注册。
 *  参数说明：
 *      node        被添加的节点，禁止直接修改该数据结构，会影响参数树的结构。
 *                  当 注册 "Device.IP.Interface.{i}.IPv4Address.{i}.IPAddress" ,可使用 "tr069_oid_add_object" 接口添加实例
 *                  当 tr069_oid_add_object(参数树, Device.IP.Interface.)被调用时，注册的该回调函数将被调用。
 *      currObjIdx  当前添加的实例参数路径中的实例号位置，起始值为 1。
 *                  若支持添加object的参数路径为 Device.A.{i}.{i}.{i}.{i}.{i}.{i}.{i}.{i}.name
 *                  添加一个实例 Device.A. 时， currObjIdx==1
 *                  添加一个实例 Device.A.1. 时， currObjIdx==2
 *                  添加一个实例 Device.A.1.1. 时， currObjIdx==3
 *                  ...
 *                  添加一个实例 Device.A.1.1.1.1.1.1.1. 时， currObjIdx==8
 *
 *      nPrevObj        创建的当前参数路径之前中出现的实例号个数。
 *      prevObjInsNums  创建的当前参数路径之前中出现的实例号。
 *
 *      参数 nPrevObj 和 prevObjInsNums 的例子：
 *                  AddObject: Device.A.        nPrevObj==0,    prevObjInsNums=NULL
 *                  AddObject: Device.A.1.      nPrevObj==1,    prevObjInsNums={1,}
 *                  AddObject: Device.A.1.1.    nPrevObj==2,    prevObjInsNums={1,1,}
 *                      ...
 *                  AddObject: Device.A.1.1.1.2.3.1.1. nPrevObj==8, prevObjInsNums={1,1,1,2,3,1,1,}
 *
 *      argc        用户注册参数个数，该参数为 "tr069_oid_register" 注册时填写 的 "add_argc"。
 *      argv        用户注册参数，该参数为 "tr069_oid_register" 注册时填写 的 "add_argv"。
 *      ObjInsNum   生成的实例号。 1,2,3,4,5...
 *      aliasName   别名：TR069协议规定。
 *
 *  返回值：    
 *      AddObject成功，生成实例号填入 ObjInsNum , 并返回真值。否则返回假。
 */
typedef bool (*tr069_oid_addobj_fn_t)(struct tr069_oid *node, int currObjIdx, int nPrevObj, int prevObjInsNums[], int argc, void *argv[], int *ObjInsNum, char aliasName[TR069_OID_ITEM_SIZE]);

/**
 *  目标删除回调函数
 *  说明：
 *      当接口 "tr069_oid_delete_object" 被调用时，该回调函数将被调用。
 *      该回调函数在参数注册时被参数树保存。使用 "tr069_oid_register" 注册。
 *  参数说明：（见AddObject接口回调   tr069_oid_addobj_fn_t        ）
 *      node        被删除的节点，禁止直接修改该数据结构，会影响参数树的结构。
 *      nObj        参数路径中出现的实例号个数。当 isObj 为真时，该参数可用。
 *                  当参数为 Device.IP.Interface.1.IPv4Address.2.IPAddress 时，nObj==2.
 *      ObjInsNums  参数路径中出现的实例号数组。当 isObj 为真时，该参数可用。
 *                  当参数为 Device.IP.Interface.1.IPv4Address.2.IPAddress 时，ObjInsNums[0]==1, ObjInsNums[1] = 2.
 *      argc        用户注册参数个数，该参数为 "tr069_oid_register" 注册时填写 的 "set_argc"。
 *      argv        用户注册参数，该参数为 "tr069_oid_register" 注册时填写 的 "set_argv"。
 */
typedef bool (*tr069_oid_delobj_fn_t)(struct tr069_oid *node, int nObj, int ObjInsNums[], int argc, void *argv[]);

typedef void* tr069_oid_tree_t;

/* TR069 OID树节点结构 */
struct tr069_oid {
    
    char oidNameItem[TR069_OID_ITEM_SIZE];/* 参数路径中的单项名称 */
    char oidAliasNameItem[TR069_OID_ITEM_SIZE];/* 参数单项名称的别名 */
    
    unsigned int oidInstanceNum; /* 实例号 */
    
    enum TR069_OID_ITEM_TYPE node_type; /* 节点单项类型：枝干 或 叶子 */
    enum TR069_OID_TYPE oid_type; /* 目标节点类型：是否可创建，表或标量 */
    
    int writeable; //是否可写
    

    /* 保存下一级 */
    tr069_oid_tree_t child;  //该节点下的下一级节点
                        //A.B1.C.D
                        //A.B2.C.D
                        //A.B3.C.D
                        //A.child => B1, B2, B3
                        
    struct tr069_oid *father;   //所有节点指向该节点的父节点
                                // A.B.C.D => D.father = &C;
                                
    struct tr069_oid_leaf *leaf_value;    //每个a.b.c.d的叶子"d"需要malloc该块内存
    
    struct tr069_oid_obj_opt *obj_operation; //每个A.{i}.B 中的"{i}"需要malloc该块内存
                                                //并将注册时的参数列表填入该块内存
};


/* TR069 OID树叶子节点数据：供用户使用 */
struct tr069_oid_leaf {
    tr069_oid_set_fn_t set_fn;  /* 参数设置回调函数，在注册参数时提供 */
    int set_argc;/* 参数设置用户参数个数 */
    void **set_argv;/* 参数设置用户参数 */
    char value[TR069_OID_SIZE];/* 参数值 */
    int Notification; /* 参数通知级别：参考TR069协议 *///check in ParameterAttributeStruct, "GetParameterAttribute"
};


/* 目标创建删除用户回调函数 */
struct tr069_oid_obj_opt {
    /* 目标创建 */
    tr069_oid_addobj_fn_t add_fn;
    int add_argc;
    void **add_argv;
    /* 目标删除 */
    tr069_oid_delobj_fn_t del_fn;
    int del_argc;
    void **del_argv;
};


/* TR069 OID路径名结构 */
struct tr069_oid_names {
    int count;/* 获取的参数名个数 */
    ParameterInfoStruct *NameList;/* 参数名 */
};


/* TR069 OID 值结构 */
struct tr069_oid_values {
    int count;/* 获取的参数值的个数 */
    ParameterValueStruct *ValueList;/* 参数值 */
};


/* TR069 OID 属性值结构 */
struct tr069_oid_attrs {
    int count;/* 参数属性个数 */
    ParameterAttributeStruct *AttrList;/* 参数属性 */
};



/* Macros ------------------------------------------------------------------------------------------------------------*/

#define TR069_OID_GetParamNamesShow(tree, str, nextlevel, printfn) \
    {\
        printfn("\n--------------GetParamNames %s--------------\n", str); \
        struct tr069_oid_names *__names = tr069_oid_get_parameter_names(tree, str, nextlevel);\
        int __inames;\
        for(__inames=0;__inames<__names->count;__inames++) {\
            printfn(">> %d/%d:{ \"parameter\": \"%s\", \"writable\": \"%d\" }\n", \
                        __inames, __names->count, __names->NameList[__inames].Name, __names->NameList[__inames].Writable);\
        }\
        printfn("------------------------------------------------------\n");\
        tr069_oid_get_parameter_names_free(__names);\
    }


#define TR069_OID_GetParamValuesShow(tree, str, printfn) \
    {\
        printfn("\n-----------GetParamValues %s-----------\n", str); \
        struct tr069_oid_values *__values = tr069_oid_get_parameter_values(tree, str);\
        int __ivalues;\
        for(__ivalues=0;__ivalues<__values->count;__ivalues++) {\
            printfn(">> %d/%d:{ \"parameter\": \"%s\", \"value\": \"%s\" }\n", \
                        __ivalues, __values->count, __values->ValueList[__ivalues].Name, __values->ValueList[__ivalues].Value);\
        }\
        printfn("------------------------------------------------------\n");\
        tr069_oid_get_parameter_values_free(__values);\
    }


#define TR069_OID_GetParamAttributeShow(tree, str, printfn) \
    {\
        printfn("\n------------GetParamAttribute %s------------\n", str); \
        struct tr069_oid_attrs *__attrs = tr069_oid_get_parameter_attributes(tree, str);\
        int __iattrs;\
        for(__iattrs=0;__iattrs<__attrs->count;__iattrs++) {\
            printfn(">> %d/%d:{ \"parameter\": \"%s\", \"notification\": \"%d\" }\n", \
                        __iattrs, __attrs->count, __attrs->AttrList[__iattrs].Name, __attrs->AttrList[__iattrs].Notification);\
        }\
        printfn("------------------------------------------------------\n");\
        tr069_oid_get_parameter_attributes_free(__attrs);\
    }

/* Globals -----------------------------------------------------------------------------------------------------------*/


/* Functions ---------------------------------------------------------------------------------------------------------*/
/**
 *  参数树的创建/初始化 与 摧毁
 */
tr069_oid_tree_t tr069_oid_tree_create();
void tr069_oid_tree_destroy(tr069_oid_tree_t oid_root);

/**
 *  参数注册
 *  函数说明：
 *      当使用 接口 tr069_oid_tree_create 创建参数树后，可以使用该接口注册一个参数。
 *  函数参数列表：
 *      oid_root        参数树
 *      ParameterPath   一个完整的参数路径， 如 "Device.IP.Interface.{i}.IPv4Address.{i}.IPAddress"
 *      writeable       是否可写（0-不可写，1-可写），值得一提的是，该值只决定了 ParameterPath 路径规定的最后一个参数，而其他参数的可写性，
 *                      由接口内部决定，如 参数 "Device.IP.Interface.{i}.IPv4Address.{i}.IPAddress" 的可写性为：
 *                      可写的有：         Interface IPv4Address 
 *                      不可写的有：  Device IP {i} 
 *                      由参数 writeable 决定 IPAddress 是否可写
 *      default_value   一个默认值，字符串形式
 *      Notification    通知级别，参考TR069协议中的 ParameterAttributeStruct 结构，取值 0~6
 *      set_fn          参考 tr069_oid_set_fn_t 
 *      set_argc        set_fn 的入参
 *      set_argv        set_fn 的入参
 *      obj_add_del_ope 实例添加和删除相关回调函数与参数
 *                      add_fn          参考 tr069_oid_addobj_fn_t 
 *                      add_argc        add_fn 的入参
 *                      add_argv        add_fn 的入参
 *                      del_fn          参考 tr069_oid_delobj_fn_t 
 *                      del_argc        del_fn 的入参
 *                      del_argv        del_fn 的入参
 */
int tr069_oid_register(tr069_oid_tree_t oid_root, char ParameterPath[TR069_OID_SIZE], 
                         int writeable, char default_value[TR069_OID_SIZE], int Notification,
                         tr069_oid_set_fn_t set_fn, int set_argc, void *set_argv[],
                         struct tr069_oid_obj_opt obj_add_del_ope[]);

/**
 *  参数轮询
 *  函数说明：
 *      该参数将轮询此树的所有节点， display 将被调用。 遗憾的是， oid 将不被允许修改， 否则会捣乱树结构， oid只读。
 *  函数参数列表：
 *      oid_root    参数树
 *      display     轮询树是被调用的回调函数
 *                  oid 参数节点
 *                  arg 用户数据
 *      arg         用户数据， 将被透传至 display 的参数列表中
 */
void tr069_oid_display(tr069_oid_tree_t oid_root, void (*display)(struct tr069_oid *oid, void *arg), void *arg);

/**
 *  参数名获取
 *  函数说明：
 *      GetParameterNames 
 *  函数参数列表：
 *      oid_root    参数树
 *      pathPrefix  参数路径， 如 "Device."
 *      nextlevel   是否只获取下一级参数节点， 取值0或1，参考标准协议。
 *  返回值   
 *      结构 struct tr069_oid_names 该结构需要使用 tr069_oid_get_parameter_names_free 进行释放
 *      
 */
struct tr069_oid_names *tr069_oid_get_parameter_names(tr069_oid_tree_t oid_root, char pathPrefix[TR069_OID_SIZE], int nextlevel);
void tr069_oid_get_parameter_names_free(struct tr069_oid_names *oid_names);

/**
 *  参数获取
 *  函数说明：
 *      GetParameterValues
 *  函数参数列表：
 *      oid_root    参数树
 *      pathPrefix  参数路径， 如 "Device."
 *  返回值
 *      结构    struct tr069_oid_values   ， 需要使用 tr069_oid_get_parameter_values_free 释放内存
 *      
 *      
 */
struct tr069_oid_values *tr069_oid_get_parameter_values(tr069_oid_tree_t oid_root, char pathPrefix[TR069_OID_SIZE]);
void tr069_oid_get_parameter_values_free(struct tr069_oid_values *oid_values);

/**
 *  参数设置
 *  函数说明：
 *      SetParameterValues
 *  函数参数列表：
 *      oid_root    参数树
 *      paramPath   参数的完整路径， 如 "Device.IPsec.Enable"
 *      paramValue  参数值， 字符串
 *  返回值
 *      结构 struct tr069_oid， 很遗憾， 这个返回值不许修改，否则会损坏树结构。
 */
struct tr069_oid *tr069_oid_set_parameter_values(tr069_oid_tree_t oid_root, char paramPath[TR069_OID_SIZE], char paramValue[TR069_OID_SIZE]);

/**
 *  参数属性获取
 *  函数说明：
 *      GetParamAttributes
 *  函数参数列表：
 *      oid_root    参数树
 *      pathPrefix  参数路径， 如 "Device."
 *  返回值
 *      结构      struct tr069_oid_attrs， 需要使用 tr069_oid_get_parameter_attributes_free 释放内存
 */
struct tr069_oid_attrs *tr069_oid_get_parameter_attributes(tr069_oid_tree_t oid_root, char pathPrefix[TR069_OID_SIZE]);
void tr069_oid_get_parameter_attributes_free(struct tr069_oid_attrs *oid_attrs);

/**
 *  参数属性设置
 *  函数说明：
 *      SetParamAttributes
 *  函数参数列表：
 *      oid_root    参数树
 *      paramPath   参数的完整路径， 如 "Device.IPsec.Enable"
 *      Notification    通知级别，参考TR069协议中的 ParameterAttributeStruct 结构，取值 0~6
 *  返回值
 *      结构 struct tr069_oid， 很遗憾， 这个返回值不许修改，否则会损坏树结构。
 */
struct tr069_oid *tr069_oid_set_parameter_attributes(tr069_oid_tree_t oid_root, char paramPath[TR069_OID_SIZE], int Notification);

/**
 *  目标实例添加和删除
 *  函数说明：
 *      AddObject DeleteObject
 *  函数参数列表：
 *      oid_root        参数树
 *      ParameterPath   参数路径， 如 注册了 Device.IP.Interface.{i}.IPv4Address.{i}.IPAddress
 *                      此时 Device.IP.Interface. 是支持 AddObject 的，当 调用了 tr069_oid_add_object ， 参见注册接口：
 *                      tr069_oid_register 的 add_fn 将被调用， 需要生成   实例号。
 *      pathPrefix      参数路径， 如添加了目标实例 1,-> 可使用 "Device.IP.Interface.1." 对其进行删除， 可调用该接口删除该实例。
 *  返回值
 *      tr069_oid_add_object 成功返回实例号， 失败返回 VOS_ERROR
 *      
 */
int tr069_oid_add_object(tr069_oid_tree_t oid_root, char ParameterPath[TR069_OID_SIZE]);
int tr069_oid_delete_object(tr069_oid_tree_t oid_root, char pathPrefix[TR069_OID_SIZE]);






#endif //__CPE_OID_REG_H



