/**********************************************************************************************************************
** 
** Copyright (c) 2008-2019 ICT/CAS.
** All rights reserved.
**
** File name: cwmp_api.h
** Description: 
**
** Current Version: 
** $Revision$
** Author: rongtao <rongtao@sylincom.com>
** Date: 2020.04 - 2020.05
**
***********************************************************************************************************************/
#ifndef __TR069_easyCWMP_OM_API_H
#define __TR069_easyCWMP_OM_API_H 1

/**
 *  **该接口头文件依照标准TR069协议文件
 *    <<TR-069 CPE WAN Management Protocol>> Issue: 1 Amendment 6, Approval Date: March 2018, CWMP Version: 1.4
 *
 *  修改配置文件 vim /etc/config/easycwmp
 */

/* Dependencies ------------------------------------------------------------------------------------------------------*/
#include <stdbool.h>


#define SIZE_OF_PARAM_KEY   32

#define EASYCWMP_OM 1

/* Types -------------------------------------------------------------------------------------------------------------*/

typedef struct  {
    char Name[256];
    bool Writable;
}ParameterInfoStruct;

typedef struct  {
    char Name[256];
    char Value[256];
}ParameterValueStruct;

/**
 *  Table 39 – DeviceIdStruct definition
 */
typedef struct {
    char Manufacturer[64];//制造商
    char OUI[6]; //组织唯一标识符
    char ProductClass[64]; //产品类别
    char SerialNumber[64];
}DeviceIdStruct;

/**
 *  Table 40 – EventStruct definition
 */
typedef struct {
    char EventCode[64];
    char CommandKey[64];
}EventStruct;


/**
 *  Table 37 – Inform arguments
 */
typedef struct {
    DeviceIdStruct DeviceId;
    EventStruct Event[64];
    unsigned int MaxEnvelopes;
    char CurrentTime[64]; //like "R2/2015-06-04T19:25:16.828696-07:00/P1DT10S"
    unsigned int RetryCount;
    ParameterValueStruct *ParameterList;
}Inform;

/**
 *  Table 38 – InformResponse arguments
 */
typedef struct {
    unsigned int MaxEnvelopes;
}InformResponse;


typedef struct  {
    char Name[256];
    int Notification;
    //Indicates whether (and how) the CPE will notify the ACS when the specified Parameter(s) change in value. 
    //    The following values are defined:
    //0 = Notification off. The CPE need not inform the ACS of a change to the specified Parameter(s).
    //1 = Passive notification. Whenever the specified Parameter value changes, the CPE MUST include 
    //    the new value in the ParameterList in the Non-HEARTBEAT Inform message that is sent the next 
    //    time a Session is established to the ACS.
    //2 = Active notification. Whenever the specified Parameter value changes, the CPE MUST initiate a 
    //    Session to the ACS, and include the new value in the ParameterList in the associated Inform message.
    //3 = Passive lightweight notification. Whenever the specified Parameter value changes, the CPE MUST 
    //    include the new value in the ParameterList in the next Lightweight Notification message that is sent.
    //4 = Passive notification with passive lightweight notification. This combines the requirements of 
    //    the values 1 (Passive notification) and 3 (Passive lightweight notification). 
    //    The two mechanisms operate independently.
    //5 = Active lightweight notification. Whenever the specified parameter value changes, the CPE MUST 
    //    include the new value in the ParameterList in the associated Lightweight Notification message.
    //6 = Passive notification with active lightweight notification. This combines the requirements of 
    //    the values 1 (Passive notification) and 5 (Active lightweight notification). 
    //    The two mechanisms operate independently.
    char *AccessList[64];
    //零个或多个实体的数组，授予其对指定参数的写访问权。如果没有条目，则仅允许从ACS进行写访问。
    //    当前，仅定义了一种可以包含在此列表中的实体类型：
    //“订户”表示通过订户LAN上控制的接口进行的写访问。包括任何和所有此类LAN端机制，
    //    可以包括但不限于TR-064（LAN端DSL CPE配置协议），UPnP，设备的用户界面，客户端telnet和客户端SNMP。
    //该列表可以包括特定于卖方的实体，该实体必须以X_ <VENDOR> _开头，并遵循[16]中定义的参数名称的卖方扩展语法。
    //ACS可以忽略它无法理解的该阵列中的任何单个项目。
    //默认情况下，在ACS对访问列表进行任何更改之前，所有参数的AccessList属性都应包括CPE支持的所有实体，
    //指示已授予所有这些实体的访问权限。
}ParameterAttributeStruct;

typedef struct  {
    char Name[256];
    bool NotificationChange;
    int Notification;  
    bool AccessListChange;
    char *AccessList[64];
}SetParameterAttributesStruct;


/* GetParameterNames and GetParameterNamesResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.3
 *  Table 20 – GetParameterNames arguments
 */
typedef struct  {
    char ParameterPath[256];
    bool NextLevel;  
}GetParameterNames;
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.3
 *  Table 21 – GetParameterNamesResponse arguments
 */
typedef struct  {
    ParameterInfoStruct *ParameterList;
}GetParameterNamesResponse;


/* GetParameterValues and GetParameterValuesResponse 
 *  这里提供给设备的接口改为一对一的 参数-值 的关系
 */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.2
 *  Table 18 – GetParameterValues arguments
 */
typedef struct  {
    char ParameterNames[256];
}GetParameterValues;
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.2
 *  Table 19 – GetParameterValuesResponse arguments
 */
typedef struct  {
    ParameterValueStruct *ParameterList;
}GetParameterValuesResponse;



/* SetParameterValues and SetParameterValuesResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.1
 *  Table 15 – SetParameterValues arguments
 */
typedef struct {
    ParameterValueStruct Parameter;
    char ParameterKey[32];
}SetParameterValues;

/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.1
 *  Table 16 – SetParameterValuesResponse arguments
 */
typedef struct {
    int Status;
//0 = All Parameter changes have been validated and applied.
//1 = All Parameter changes have been validated and committed, 
//    but some or all are not yet applied (for example, 
//    if a reboot is required before the new values are applied).
}SetParameterValuesResponse;




/* SetParameterAttributes and SetParameterAttributesResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.4
 *  Table 23 – SetParameterAttributes arguments
 */
typedef struct {
    SetParameterAttributesStruct Parameter;
}SetParameterAttributes;
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.4
 *  Table 24 – SetParameterAttributesResponse arguments
 */
typedef struct {
    //void -;
}SetParameterAttributesResponse;




/* GetParameterAttributes and GetParameterAttributesResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.5
 *  Table 26 – GetParameterAttributes arguments
 */
typedef struct {
    char ParameterNames[256];
}GetParameterAttributes;
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.5
 *  Table 27 – GetParameterAttributesResponse arguments
 */
typedef struct {
    ParameterAttributeStruct *ParameterAttrList;
}GetParameterAttributesResponse;



/* AddObject and AddObjectResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.6
 *  Table 29 – AddObject arguments
 */
typedef struct {
    char ObjectName[256];
    char ParameterKey[32];
}AddObject;
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.6
 *  Table 30 – AddObjectResponse arguments
 */
typedef struct AddObjectResponse_s {
    unsigned int InstanceNumber;
    int Status;
}AddObjectResponse;



/* DeleteObject and DeleteObjectResponse */
/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.7
 *  Table 31 – DeleteObject arguments
 */
typedef struct {
    char ObjectName[256];
    char ParameterKey[32];
}DeleteObject;

/**
 *  <<TR-069 CPE WAN Management Protocol>> A.3.2.7
 *  Table 32 – DeleteObjectResponse arguments
 */
typedef struct {
    int Status; 
}DeleteObjectResponse;

/**
 *  Table 35 – Reboot arguments
 */
typedef struct {
    char CommandKey[32];
}Reboot;

/**
 *  Table 36 – RebootResponse arguments
 */
typedef struct {
    //void -;
}RebootResponse;

/**
 *  Table 58 – FactoryReset arguments
 */
typedef struct {
    //void-;
}FactoryReset;


/**
 *  Table 59 – FactoryResetResponse arguments
 */
typedef struct {
    //void-;
}FactoryResetResponse;

/**
 *  Download file Type
 *  "1 Firmware Upgrade Image"
 *  "2 Web Content"
 *  "3 Vendor Configuration File"
 *  "4 Tone File" (see [28] Appendix B)
 *  "5 Ringer File" (see [28] Appendix B)
 *  "6 Stored Firmware Image" (see Appendix V)
 */
typedef enum {
    DLOAD_FTYPE_FIRMWARE_UPGRADE_IMG = 1,
    DLOAD_FTYPE_WEB_CTN,
    DLOAD_FTYPE_CFG_FILE,
    DLOAD_FTYPE_TONE_FILE,
    DLOAD_FTYPE_RINGER_FILE,
    DLOAD_FTYPE_STORED_FIRMWARE_IMG
}DownloadFileType;
    
/**
 *  下载文件的订阅，以通知链形式告知， 见 ""
 */
typedef struct {
    DownloadFileType FileType;  //文件类型
    char FileName[256];         //全路径的文件名    
}DownloadSubscribe;



typedef enum {
    ACSCFG_URL          = 0x0001,   //ACS URL
    ACSCFG_USRNAME      = 0x0002,   //ACS Username
    ACSCFG_PASSWD       = 0x0004,   //ACS User's password
    ACSCFG_PERI_ENABLE  = 0x0008,   //ACS Periodic Enable
    ACSCFG_PERI_TIME    = 0x0010,   //ACS Periodic Time
    ACSCFG_PERI_INTV    = 0x0020,   //ACS Periodic Interval
    ACSCFG_PARKEY       = 0x0040,   //ACS Parameter key
    ACSCFG_SSL_CERT     = 0x0080,   //ACS SSL cert file
    ACSCFG_SSL_CACERT   = 0x0100,   //ACS SSL CA cert file
    ACSCFG_SSL_VERIFY   = 0x0200,   //ACS SSL Verify
    ACSCFG_ALL = 0x03ff
}acs_cfg_type;

typedef struct {
    /* CWMP ACS configuration */
    CHAR    Url[256];   //ACS URL
    CHAR    Username[64];   //ACS Username
    CHAR    Password[64];   //ACS User's password
    BOOL    Periodic_Enable;    //ACS Periodic Enable
    time_t  Periodic_Time;  //ACS Periodic Time
    INT32   Periodic_Interval;  //ACS Periodic Interval
    CHAR    ParametterKey[64];   //ACS Parameter key
    CHAR    SSL_CertFile[256];  //ACS SSL cert file
    CHAR    SSL_CACertFile[256]; //ACS SSL CA cert file
    INT32   SSL_Verify; //ACS SSL Verify
}ACSConfigInfo;



/*** TR069 RPC 方法 设备侧回调函数 ************************************************************************************/
/**
 *  RPC: Inform  ParameterList
 *  
 *  参数说明：
 *      Inform:   (<<TR-069 CPE WAN Management Protocol>> Table 37's ParameterList param)
 *                  该结构体中，ParameterList将不会被使用，而使用 "RPC_Inform_ParameterList" 的回调函数返回值作为 Inform消息
 *                  的 "inform->ParameterList" 结构内容
 *
 *      ParameterList: 将被用作 "inform->ParameterList"
 *                  
 *      nParams:    (<<TR-069 CPE WAN Management Protocol>> Table 37's ParameterList param)
 *                  需要设备侧返回response中包含参数个数，最大将访问 inform->ParameterList[(*nParams)-1] 
 *                  
 */
typedef int (*RPC_Inform)(Inform *inform);
typedef int (*RPC_Inform_ParameterList)(ParameterValueStruct **ParameterList, int *nParams);


/**
 *  RPC: GetParameterNames 
 *  
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 20)
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 21)
 *                  response中的指针内容需要在回调函数返回后仍有效，可使用malloc分配内存，在下呗被调用时释放。
 *                  
 *      nParams:    需要设备侧返回response中包含参数个数，最大将访问 response->ParameterList[(*nParams)-1] 
 *                  
 */
typedef int (*RPC_GetParameterNames)(const GetParameterNames *request, GetParameterNamesResponse *response, int *nParams);

/**
 *  RPC: GetParameterValues
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 18)
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 19)
 *                  
 *      gotit:  boolean值，当获取到参数值时，if(*gotit) 需为真值判断，否则为假。
 *
 *      nParams    ：需要设备侧返回response中包含参数个数，最大将访问 [(*nParams)-1]               
 */
typedef int (*RPC_GetParamValue)(const GetParameterValues *request, GetParameterValuesResponse *response, bool *gotit, int *nParams);

/**
 *  RPC: SetParameterValues
 *          设置参数时，EasyCWMP需要先set在apply，以下两个接口即如此。
 *      
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 15)
 *                 
 *      notMineParam:   由于需要进一步调用 apply来对set进行应用生效，此参数标志是否 Apply 回调函数 将被调用
 *                       当 "*notMineParam" 为真值，Apply 将不会被调用，为假则不会被调用。
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 16)
 *                  
 *      ParameterKey:   检测与 "request" 中的 ParameterKey 是否一致或 检测那些参数需要被 "apply"
 *                  
 */
typedef int (*RPC_SetParamValue)(const SetParameterValues *request, bool *notMineParam);
typedef int (*RPC_SetParamValueApply)(SetParameterValuesResponse *response, char ParameterKey[32]);

/**
 *  RPC: GetParameterAttributes
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 26)
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 27)
 *                  
 *      gotit:  boolean值，当获取到参数属性值时，if(*gotit) 需为真值判断，否则为假。
 *
 *      nParams    ：需要设备侧返回response中包含参数个数，最大将访问 [(*nParams)-1]   
 *                  
 */
typedef int (*RPC_GetParamAttribute)(const GetParameterAttributes *request, GetParameterAttributesResponse *response, bool *gotit, int *nParams);

/**
 *  RPC: SetParameterAttributes
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 23)
 *                  
 *      notMineParam:   由于需要进一步调用 apply来对set进行应用生效，此参数标志是否 Apply 回调函数 将被调用
 *                       当 "*notMineParam" 为真值，Apply 将不会被调用，为假则不会被调用。
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 24)
 *                  
 *                  
 */
typedef int (*RPC_SetParamAttribute)(const SetParameterAttributes *request, bool *notMineParam);
typedef int (*RPC_SetParamAttributeApply)(SetParameterAttributesResponse *response);

/**
 *  RPC: AddObject
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 29)
 *                  
 *      notMineParam:   由于需要进一步调用 apply来对set进行应用生效，此参数标志是否 Apply 回调函数 将被调用
 *                       当 "*notMineParam" 为真值，Apply 将不会被调用，为假则不会被调用。
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 30)
 *                  
 *      ParameterKey:   检测与 "request" 中的 ParameterKey 是否一致或 检测那些参数需要被 "apply"
 *                  
 */
typedef int (*RPC_AddObject)(const AddObject *request, bool *notMineParam);
typedef int (*RPC_AddObjectApply)(AddObjectResponse *response, char ParameterKey[32]);

/**
 *  RPC: DeleteObject
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 31)
 *                  
 *      notMineParam:   由于需要进一步调用 apply来对set进行应用生效，此参数标志是否 Apply 回调函数 将被调用
 *                       当 "*notMineParam" 为真值，Apply 将不会被调用，为假则不会被调用。
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 32)
 *                  
 *      ParameterKey:   检测与 "request" 中的 ParameterKey 是否一致或 检测那些参数需要被 "apply"
 *                  
 */
typedef int (*RPC_DeleteObject)(const DeleteObject *request, bool *notMineParam);
typedef int (*RPC_DeleteObjectApply)(DeleteObjectResponse *response, char ParameterKey[32]);

/**
 *  RPC: FactoryReset
 *
 *  参数说明：
 *      request:   (<<TR-069 CPE WAN Management Protocol>> Table 58)
 *                  
 *      response:   (<<TR-069 CPE WAN Management Protocol>> Table 59)
 *                  
 */
typedef int (*RPC_FactoryReset)(FactoryReset *request, FactoryResetResponse *response);

/**
 *  文件下载通知订阅回调函数
 *
 *  参数说明：
 *      file: 将被通知的文件结构
 */
typedef int (*RPC_DownloadSubscribe)(DownloadSubscribe *file);


/**
 *  产品重启回调函数
 *
 *  参数说明：
 *      reboot: 重启请求 - CommandKey值可能为空，尚可不使用忽略该值
 *      rsp: 重启响应 - 目前该结构体为空
 */
typedef void (*RPC_Reboot)(Reboot *reboot, RebootResponse *rsp);





/* Constants ---------------------------------------------------------------------------------------------------------*/
/* Macros ------------------------------------------------------------------------------------------------------------*/
/* Globals -----------------------------------------------------------------------------------------------------------*/
/* Functions ---------------------------------------------------------------------------------------------------------*/

/**
 *  函数名称：注册TR069 协议栈CWMP初始化函数
 */
int tr069_cwmp_agent_start();


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 Inform
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.3.1
 *
 *  函数说明：
 *      tr069_register_RPC_Inform: Inform 主体消息的注册
 *      tr069_register_RPC_Inform_ParameterList: Inform->ParameterList 部分参数的注册
 */
int tr069_register_RPC_Inform(RPC_Inform cb_fn);
int tr069_register_RPC_Inform_ParameterList(RPC_Inform_ParameterList cb_fn);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 GetParameterNames
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.3
 */
int tr069_register_RPC_GetParameterNames(RPC_GetParameterNames cb_fn);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 GetParameterValues
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.2
 */
int tr069_register_RPC_GetParameterValues(RPC_GetParamValue cb_fn);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 SetParameterValues
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.1
 */
int tr069_register_RPC_SetParameterValues(RPC_SetParamValue cb_fn, RPC_SetParamValueApply cb_apply);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 GetParameterAttributes
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.5
 */
int tr069_register_RPC_GetParamAttribute(RPC_GetParamAttribute cb_fn);

/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 SetParameterAttributes
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.4
 */
int tr069_register_RPC_SetParamAttribute(RPC_SetParamAttribute cb_fn, RPC_SetParamAttributeApply cb_apply);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 AddObject
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.6
 */
int tr069_register_RPC_AddObject(RPC_AddObject cb_fn, RPC_AddObjectApply cb_apply);


/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 DeleteObject
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.3.2.7
 */
int tr069_register_RPC_DeleteObject(RPC_DeleteObject cb_fn, RPC_DeleteObjectApply cb_apply);



/**
 *  向TR069协议栈注册RPC回调函数 -> 注册 FactoryReset
 *  设备侧调用该接口, 回调函数参照对应说明
 *  参见：<<TR-069 CPE WAN Management Protocol>> A.4.1.6
 */
int tr069_register_RPC_FactoryReset(RPC_FactoryReset cb_fn);


/**
 *  向TR069协议栈注册 通知链函数
 *  当有文件下载成功后，以通知链的形式通知
 */
int tr069_register_RPC_Download_subscribe(RPC_DownloadSubscribe cb_fn);


/**
 *  向TR069协议栈注册 设备重启函数
 *  当CWMP获取ACS的重启RPC后，注册的回调函数将被调用
 */
int tr069_register_RPC_Reboot(RPC_Reboot cb_fn);



/**
 *  配置ACS信息
 *
 *  参数说明：
 *      cfginfo: 将被设置的信息
 *      type:   将要设置的数据，支持 或 “|” 运算
 *
 *  返回值：
 *      成功：0， 失败：-1
 */
int tr69_config_acs_info(ACSConfigInfo* cfginfo, acs_cfg_type type);



#endif /*<__TR069_easyCWMP_OM_API_H>*/

