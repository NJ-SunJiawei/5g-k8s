/**
 * @file vos_conf.h
 * @brief vos conf 头文件
 * @details 提供VOS 平台配置解析相关函数
 * @version 1.0
 * @author  wujianming  (wujianming@sylincom.com)
 * @date 2019.02.01
 * @copyright 
 *    Copyright (c) 2018 Sylincom.
 *    All rights reserved.
*/

#ifndef __VOS_CONF_H__
#define __VOS_CONF_H__
#include "vos_types.h"

#ifdef    __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** 配置文件路径长度最大值 */
#define CONFIG_PATH_MAX 4096

#define CONFIG_STRING_MAX_LEN 100

/** 配置文件结构体 */
typedef struct vos_config_s
{
    CHAR appPath[CONFIG_PATH_MAX];      ///< 产品APP路径 
    CHAR confPath[CONFIG_PATH_MAX];     ///< 配置文件路径 
    VOID * cfg;                         ///< 配置文件数据 
}VOS_CONFIG_FILE;

typedef void                *VOS_config_setting;

/** 
 * 打开 VOS 平台配置文件，
 * 使用完成后需要调用VOS_config_file_close 关闭，否则其他模块无法打开 
 * @return       成功返回 VOS 平台配置文件 文件指针，失败 返回 NULL
 */
VOS_CONFIG_FILE *VOS_config_vos_file_open(VOID);

/** 
 * 关闭OS 平台配置文件 
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_config_vos_file_close(VOID);


/** 
 * 从配置文件中获取数值型配置 
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   key            配置文件中的关键字
 * @param[out]   val            存储返回值的指针
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_config_get_number(VOS_CONFIG_FILE *vos_config,const CHAR *key,LONG *val);

/** 
 * 从配置文件中获取字符串型配置 
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   key            配置文件中的关键字
 * @param[out]   val            存储返回值的指针
 * @param[in ]   size           输入： val buf大小； 输出： val 有效长度
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_config_get_string(VOS_CONFIG_FILE *vos_config,const CHAR *key,CHAR *val,LONG *size);

/** 
 * 从配置文件中获取函数指针型配置 
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   key            配置文件中的关键字
 * @param[out]   val            存储返回值的指针
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_config_get_func_ptr(VOS_CONFIG_FILE *vos_config,const CHAR *key,VOID **val);


/** 
 * 从配置文件中获LONG 类型数组
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   key            配置文件中的关键字
 * @param[in ]   size           数组大小
 * @param[in ]   array          数组
 * @return       获得数据的个数
 */
LONG VOS_config_get_number_array(VOS_CONFIG_FILE *vos_config,const CHAR *key,LONG size,LONG array[]);


/** 
 * 从配置文件中获字符串数组
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   key            配置文件中的关键字
 * @param[in ]   size           数组大小
 * @param[in ]   array          数组
 * @return       获得数据的个数
 */
LONG VOS_config_get_string_array(VOS_CONFIG_FILE *cfg,const CHAR *key,LONG size,CHAR array[][CONFIG_STRING_MAX_LEN]);


/** 
 * 从配置文件中获取配置path路径配置的指针结构 VOS_config_setting
 * @param[in ]   vos_config     vos config 文件指针
 * @param[in ]   path            配置文件中的关键字或者路径
 * @return       VOS_config_setting * - 成功，NULL - 失败
 */
VOS_config_setting VOS_config_lookup(VOS_CONFIG_FILE *vos_config, const char *path);

/** 
 * 从setting中获取指向成员name的指针结构 VOS_config_setting
 * @param[in ]   setting     	配置组结构
 * @param[in ]   name           成员名称
 * @return       VOS_config_setting * - 成功，NULL - 失败（setting不是group结构或者未找到成员name）
 */
VOS_config_setting VOS_config_setting_get_member(const VOS_config_setting setting, const char *name);

/** 
 * 获取setting长度
 * setting是group结构，返回group中setting结构的个数；
 * setting是list或者array结构，返回元素个数；其他类型返回0
 * @param[in ]   setting     	配置组结构
 * @return       length - 成功，0 - 失败
 */
LONG VOS_config_setting_length(const VOS_config_setting setting);

/** 
 * 获取setting结构中第idx个元素
 * setting不是list或者array结构，或者与请求元素类型不匹配，idx超出范围，返回0或NULL
 * @param[in ]   setting     	配置组结构
 * @return       第idx元素- 成功，0或NULL - 失败
 */
LONG VOS_config_setting_get_elem(const VOS_config_setting setting, int idx);

/** 
 * 以关键字解析数组内容，长度array_len需完全匹配
 * @param[in ]   array_len     	数组长度
 * @param[in ]   array_key     	关键字
 * @param[out ]  array     		数组内容
 * @return      VOS_OK- 成功，VOS_ERROR - 失败
 */
LONG VOS_config_get_array(ULONG *array, LONG array_len, const CHAR *array_key);


/** 
 * 打开配置文件 
 * @param[in ]   appPath       产品APP路径
 * @param[in ]   cfgPath       模块名，大小为 MODULE_NAME_LEN
 * @return       成功返回 vos config 文件指针，失败 返回 NULL
 */
VOS_CONFIG_FILE *VOS_config_file_open(const CHAR *appPath,const CHAR *cfgPath);

/** 
 * 关闭配置文件 
 * @param[in ]   vos_config     vos config 文件指针
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_config_file_close(VOS_CONFIG_FILE *cfg);


#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __VOS_CONF_H__ */
