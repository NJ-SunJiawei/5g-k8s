#ifndef __VOS_LICENCE_H__
#define __VOS_LICENCE_H__


/** 
 * licence 校验
 * @param[in ]   licpath     licence文件的路径
 * @return       校验成功返回0，失败返回其他值
 */
int vos_licence_check(const char *licpath);


#endif

