/**
 * @file vos_malloc.h
 * @brief vos malloc 头文件
 * @details 此文件用于类 VOS_Malloc 接口与 TCMalloc 的接口适配
 *  
 *
 * @version 1.0
 * @author  rongtao  (rongtao@sylincom.com)
 * @date 2020年12月29日
 * @copyright 
 *    Copyright (c) 2020 Sylincom.
 *    All rights reserved.
 */

#ifndef _VOS_LIB_H_
 #error Don not include this file directly, include "vos_lib.h" instead.
#endif


#ifndef __VOS_MALLOC_H
#define __VOS_MALLOC_H 1

//#include <google/tcmalloc.h>
#include <gperftools/tcmalloc.h>

 #define __malloc(size) tc_malloc(size)
 #define __calloc(count,size) tc_calloc(count,size)
 #define __realloc(ptr,size) tc_realloc(ptr,size)
 #define __free(ptr) tc_free(ptr)

#ifdef VOS_Malloc
#undef VOS_Malloc
#define VOS_Malloc(ulSize,ulModuleId)   __malloc(ulSize)
#endif 

#ifdef VOS_Malloc_Module
#undef VOS_Malloc_Module
#define VOS_Malloc_Module(ulSize,ulModuleId)     __malloc(ulSize)
#endif

#ifdef VOS_Free
#undef VOS_Free
#define VOS_Free(ptr) __free(ptr)
#endif

#ifdef VOS_Free_Module
#undef VOS_Free_Module
#define VOS_Free_Module(ptr,ulModuleId) __free(ptr)
#endif

/**********************************************************************************************************************\
    几点说明 荣涛 2020年12月29日

    在  demo_malloc.c   demo\demo_app   3676    2020/11/11  85 文件中，   使用原始的内存管理接口（移植的Slab机制代码），测得
    内存管理的性能如下，为防止偶然性，这里给出了三次测量结果，分别如下：（实际测量多次，结论与下面结果保持一致）
    
         Malloc>> 97375 MicroSec Total Spend.
        Obstack>> 133876 MicroSec Total Spend.
            VOS>> 5203101 MicroSec Total Spend.
    
         Malloc>> 107135 MicroSec Total Spend.
        Obstack>> 125296 MicroSec Total Spend.
            VOS>> 5169780 MicroSec Total Spend.

         Malloc>> 88759 MicroSec Total Spend.
        Obstack>> 121422 MicroSec Total Spend.
            VOS>> 4711336 MicroSec Total Spend.

    当我们 将 接口替换为 此头文件的内存分配接口时，性能如下：
    
         Malloc>> 96894 MicroSec Total Spend.
        Obstack>> 122478 MicroSec Total Spend.
            VOS>> 94579 MicroSec Total Spend.

         Malloc>> 100295 MicroSec Total Spend.
        Obstack>> 145993 MicroSec Total Spend.
            VOS>> 128667 MicroSec Total Spend.

         Malloc>> 195834 MicroSec Total Spend.
        Obstack>> 154379 MicroSec Total Spend.
            VOS>> 150419 MicroSec Total Spend.



\**********************************************************************************************************************/

#endif /*<__VOS_MALLOC_H>*/
