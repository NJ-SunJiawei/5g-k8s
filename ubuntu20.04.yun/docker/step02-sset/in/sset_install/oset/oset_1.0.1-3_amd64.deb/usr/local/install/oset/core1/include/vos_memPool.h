/**
 * @file vos_que.h
 * @brief vos 消息队列 头文件
 * @details 提供消息队列操作函数
 * @version 1.0
 * @author  wujianming  (wujianming@sylincom.com)
 * @date 2019.01.10
 * @copyright 
 *    Copyright (c) 2018 Sylincom.
 *    All rights reserved.
*/


#ifndef __VOS_MEM_POOL_H__
#define __VOS_MEM_POOL_H__

#ifdef    __cplusplus
extern "C"
{
#endif /* __cplusplus */


#define VOS_MEMPOOL_NAME_MAX 40

/** memPool类型，single Pool  /   multi Pool  类型 */
typedef enum {
    VOS_mempool_single           = 0, ///< single size pool
    VOS_mempool_multi            = 1, ///< multi size pool
}vos_memPool_type_t;



/** memPool基本信息 */
typedef struct vos_memPool_info_s
{
    CHAR name[VOS_MEMPOOL_NAME_MAX];     ///< pool name
    vos_memPool_type_t      type;        ///< single/ multi pool
    LONG                    moduleID;    ///< moduleID
    LONG notAutoLock;                    ///< 为 0 则alloc/free时自动加锁，为 1 则不加锁
}vos_memPool_info_t;



/** 
 * 创建mem pool
 * @param[in]   poolInfo      用于创建pool 的信息
 * @param[in]   allocSize     调用一次alloc 申请的大小，该参数为数组，一个pool 支持多种申请大小
 * @param[in]   allocNum      与allocSize一一对应的大小，可申请次数，也是数组
 * @param[in]   arraySize     数组大小
 * @return      成功返回pool的地址，失败则返回NULL
 */ 
vos_memPool_info_t * vos_mempool_create(vos_memPool_info_t *poolInfo,INT allocSize[],INT allocNum[],INT arraySize);


/** 
 * 删除mem pool
 * @param[in]   poolInfo     pool的地址
 * @return      成功则返回VOS_OK，失败则返回 其他
 */ 
LONG vos_mempool_destroy(vos_memPool_info_t *poolInfo);


/** 
 * 申请内存
 * @param[in]   poolInfo     pool的地址
 * @param[in]   size         申请大小
 * @return      成功返回内存的地址，失败则返回NULL
 */ 
#define vos_mempool_alloc(poolInfo,size)  __vos_mempool_alloc(poolInfo,size,__FILE__,__LINE__)

/** 
 * 释放内存
 * @param[in]   poolInfo     pool的地址
 * @param[in]   addr         要释放的内存地址
 * @return      成功返回VOS_OK，失败则返回其他
 */ 
#define vos_mempool_free(poolInfo,addr)  __vos_mempool_free(poolInfo,addr,__FILE__,__LINE__)



// ######################################################################################################


VOID *__vos_mempool_alloc(vos_memPool_info_t *poolInfo,INT size,CHAR *file,INT line);

LONG __vos_mempool_free(vos_memPool_info_t *poolInfo,VOID *addr,CHAR *file,INT line);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VOS_MEM_POOL_H__ */
