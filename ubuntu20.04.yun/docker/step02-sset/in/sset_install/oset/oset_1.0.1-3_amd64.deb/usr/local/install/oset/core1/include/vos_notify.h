/**
 * @file vos_notify.h
 * @brief vos 通知链 头文件
 * @details 提供向通知链注册回调接口等函数
 * @version 1.0
 * @author: zhangjian (zhangjian@sylincom.com)
 * @date 2019.05.30
 * @copyright 
 *    Copyright (c) 2019 Sylincom.
 *    All rights reserved.
*/

#ifndef __VOS_NOTIFY_H__
#define __VOS_NOTIFY_H__


#ifdef __cplusplus
extern "C"
{
#endif

/******************************   Begin of File Body  **********************/

/** 通知链事件节点信息 */
typedef struct _vos_notify_event_info_s
{
	ULONG 	ulEvent;				///< 事件类型 
	plist 	notify_func_list;		///< 存储该事件对应的回调函数 
}vos_notify_event_info_t;

/** 通知链 模块节点信息 */
typedef struct _vos_notify_module_info_s
{
	CHAR 	module_name[MODULE_NAME_LEN];		///< 模块名称
	plist 	module_list;						///< 存储节点vos_notify_event_info_t
}vos_notify_module_info_t;

/** 通知链消息结构 */
typedef struct _vos_notify_msg_data_s
{
    VOID    *pData;								///< 消息内容
	ULONG 	ulDataLen;							///< 消息内容pData的长度
	CHAR 	module_name[MODULE_NAME_LEN];		///< 模块名称
    ULONG   ulEvent;							///< 事件类型 
}vos_notify_msg_data_t;

typedef enum _vos_notify_msg_code
{
	VOS_NOTIFY_MSG_MIN = 0,
/*Begin: asyn msg*/
	VOS_NOTIFY_EVENT_MSG,
/*end*/

/*Brgin: syn msg*/

/*End*/
    VOS_NOTIFY_MSG_MAX
}vos_notify_msg_code;


/** 
 * 通知链回调函数原型 
 * @param[in ]   pMsg   通知链消息
 * @return       成功返回VOS_OK，失败返回VOS_ERROR
 */ 
typedef LONG( *VOS_NOTIFY_FUNC ) ( vos_notify_msg_data_t *pMsg );

/** 
 * 通知链回调函数注册接口 
 * @param[in ]   module_name   	被关心的模块的模块名称
 * @param[in ]	 ulEvent		被关心的模块的事件类型
 * @param[in ]	 ntfyCallBack	对应这个事件本模块的回调处理函数 
 * @return       成功返回VOS_OK，失败返回VOS_ERROR
 */ 
LONG Vos_NotifyRegister(CHAR *module_name, ULONG ulEvent, VOS_NOTIFY_FUNC ntfyCallBack);

/** 
 * 注销通知链回调函数接口,不要在回调函数中调用注销函数，会造成死锁 
 * @param[in ]   module_name   	被关心的模块的模块名称
 * @param[in ]	 ulEvent		被关心的模块的事件类型
 * @param[in ]	 ntfyCallBack	对应这个事件本模块的回调处理函数 
 * @return       成功返回VOS_OK，失败返回VOS_ERROR
 */ 
LONG Vos_NotifyUnRegister(CHAR *module_name, ULONG ulEvent, VOS_NOTIFY_FUNC ntfyCallBack);


/** 
 * 通知链消息发送接口（被关心的模块发生事件时调用）
 * @param[in ]   module_name   			被关心的模块的模块名称
 * @param[in ]	 ulEvent		 		事件类型
 * @param[in ]	 pData					消息内容（非必须参数）
 * @param[in ]	 ulDataLen				消息内容的长度（有消息内容必须要消息内容长度）
 * @return       成功返回VOS_OK，失败返回VOS_ERROR
 */ 
LONG Vos_SendNotifyMsg(CHAR *module_name, ULONG ulEvent, VOID *pData, ULONG ulDataLen);


/*******************************  End of File Body ***********************/

#ifdef __cplusplus
}
#endif

#endif

