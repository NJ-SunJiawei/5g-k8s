/**
 * @file vos_staticlist.h
 * @brief vos 链表 头文件
 * @details 提供链表操作函数
 * @version 1.0
 * @author  wujianming  (wujianming@sylincom.com)
 * @date 2019.01.10
 * @copyright 
 *    Copyright (c) 2018 Sylincom.
 *    All rights reserved.
*/



#ifndef _VOS_STATICLIST_H
#define _VOS_STATICLIST_H
#include <pthread.h>

#ifdef __cplusplus
extern"C"{
#endif

/** 链表节点 */
typedef struct vos_static_listnode
{
    struct vos_static_listnode *next;
    struct vos_static_listnode *prev;
    unsigned int idx;
    void *data;
}static_listnode,*pstatic_listnode;

/** 链表名长度 */
#define LIST_NAME_LEN (48)

/** 链表节 */
typedef struct vos_static_list_info
{
    char name[LIST_NAME_LEN];
    unsigned long moduleID;
    unsigned int size;                      ///< 链表容量
    int notAutoLock;                        ///< 为 0 则链表增删节点时自动加锁，为 1 则不加锁
    int ( *cmp ) ( void *val1, void *val2 );
    void ( *del ) ( void *val );
}vos_static_list_info_t;

typedef void * vos_static_list;


/** 链表控制块 */
typedef struct vos_static_list_cb_s
{
    vos_static_list_info_t info;

    static_listnode *head;
    static_listnode *tail;

    volatile unsigned int count;

    pthread_mutex_t lock;

    unsigned int *mapArray;
    unsigned int next_idx;

    static_listnode memAddr[0];
}vos_static_list_cb_t;



/** 获得链表头 */
#define vos_static_listhead(X) (((vos_static_list_cb_t *)(X))->head)

/** 获得链表尾 */
#define vos_static_listtail(X) (((vos_static_list_cb_t *)(X))->tail)

/** 获得下个节点 */
#define vos_static_nextnode(X) ((X) = ((static_listnode *)(X))->next)

/** 获得上个节点 */
#define vos_static_prevnode(X) ((X) = ((static_listnode *)(X))->prev)

/** 获得链表中节点数量 */
#define vos_static_listcount(X) (((vos_static_list_cb_t *)(X))->count)

/** 链表为空 */
#define vos_static_list_isempty(X) (((vos_static_list_cb_t *)(X))->head == NULL && ((vos_static_list_cb_t *)(X))->tail == NULL)

/** 获得节点中的数据 */
#define vos_static_getdata(X) (((static_listnode *)(X))->data)

/** 
 * 创建一个linklist
 * @param[in]   info      list相关信息
 * @return      成功时返回新list地址，失败则返回NULL。
 */ 
vos_static_list vos_static_list_new (vos_static_list_info_t *info);



/** 
 * free并删除linklist中的所有节点，然后free该list
 * ！！！注意，如果data也需要free，则需要实现list的del成员
 * @param[in]   plist1      要删除的list
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_list_delete ( vos_static_list plist1 );

/** 
 * 将数据添加到链表尾，直接传入要添加的数据，该API会自动创建节点
 * @param[in]   plist1      待添加的list
 * @param[in]   val         待添加的数据
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_listnode_add ( vos_static_list plist1, void * val );


/** 
 * 将数据添加到链表头，直接传入要添加的数据，该API会自动创建节点
 * @param[in]   plist1      待添加的list
 * @param[in]   val         待添加的数据
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_listnode_add_toHead ( vos_static_list plist1, void * val );

/** 
 * 删除数据等于val的节点,！！！不会free 数据
 * @param[in]   plist1      待删除的list
 * @param[in]   val         待删除的数据
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_listnode_delete ( vos_static_list plist1, void * val );

/** 
 * 根据注册的cmp函数删除节点，cmd 返回值为0 时删除,！！！不会free 数据
 * @param[in]   plist1      待删除的list
 * @param[in]   val         cmp 函数参数
 * @return      成功时返回被删除节点数据地址，用于free数据，失败则返回NULL。
 */
void *vos_static_listnode_cmp_delete ( vos_static_list plist1, void * val );

/** 
 * 在当前节点前插入数据
 * @param[in]   plist1      待插入数据的list
 * @param[in]   currentnode 当前节点
 * @param[in]   val         待插入数据
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_list_add_node_prev ( vos_static_list plist1, pstatic_listnode currentnode, void *val );

/** 
 * 在当前节点后插入数据
 * @param[in]   plist1      待插入数据的list
 * @param[in]   currentnode 当前节点
 * @param[in]   val         待插入数据
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_list_add_node_next ( vos_static_list plist1, pstatic_listnode currentnode, void *val );

/** 
 * 节点查找 API,根据给定val查找
 * ！！！用此API 需要确保 plist->cmp 成员已赋值，否则无法查找
 * ！！！不可修改获得节点的 prev 和 next指针
 * ！！！不可释放获得节点
 * ！！！如果替换获得节点的data数据，如果旧的data需要释放，需自己手动释放data数据
 * @param[in]   plist1      要查找的list
 * @param[in]   data        进行比较的数据
 * @return      找到返回节点指针，未找到返回 NULL。
 */
pstatic_listnode vos_static_listnode_lookup_by_val( vos_static_list plist1, void *data );


/** 
 * 节点查找 API,根据给定val和cmp方法查找
 * ！！！不可修改获得节点的 prev 和 next指针
 * ！！！不可释放获得节点
 * ！！！如果替换获得节点的data数据，如果旧的data需要释放，需自己手动释放data数据
 * @param[in]   plist1      要查找的list
 * @param[in]   cmp         比较函数，当val1 与val2相等时返回0,不相等时返回非0值
 * @param[in]   data        进行比较的数据
 * @return      找到返回节点指针，未找到返回 NULL。
 */
pstatic_listnode vos_static_listnode_lookup_by_func( vos_static_list plist1, int (*cmp)(void *val1, void *val2),void *data);


/** 
 * 查找到的节点，如果想要从链表中删除，必须使用该接口
 * ！！！注意，如果data也需要free，则需要实现list的del成员
 * @param[in]   plist1      list
 * @param[in]   node        要删除的节点
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_list_delete_node ( vos_static_list plist1, pstatic_listnode node );


/** 
 * 删除所有节点
 * ！！！注意，如果data也需要free，则需要实现list的del成员
 * @param[in]   plist1      list
 * @return       成功返回 VOS_OK，失败则返回其他
 */
long vos_static_list_delete_all_node ( vos_static_list plist1 );


#define  __s_list_lock(list)    if(!list->info.notAutoLock) {pthread_mutex_lock(&list->lock);}
#define  __s_list_unlock(list)   if(!list->info.notAutoLock) {pthread_mutex_unlock(&list->lock);}

#define FOR_Static_List_Get_Data()  vos_static_getdata(__m_pNode)

#define FOR_Static_List_Del_cur_node()  vos_static_list_delete_node(__m_list,__m_pNode)


/**
 * 遍历list，中间代码不能有return，因为有加解锁
*/
#define FOR_Static_List_Start(plist1)\
    {   \
        static_listnode *__m_pNode = NULL;\
        static_listnode *__m_pNode_Next = NULL;\
        vos_static_list_cb_t *__m_list = (vos_static_list_cb_t *)plist1;\
        __s_list_lock(__m_list);  \
        for( __m_pNode_Next = vos_static_listhead(__m_list); __m_pNode_Next;)\
        {   \
            __m_pNode = __m_pNode_Next; \
            __m_pNode_Next = ((static_listnode *)(__m_pNode))->next; \

#define FOR_Static_List_End()  \
        }   \
        __s_list_unlock(__m_list);  \
    }

/**
 * 反向遍历list，中间代码不能有return，因为有加解锁
*/
#define FOR_Static_List_Start_Reverse(plist1)\
    {   \
        static_listnode *__m_pNode = NULL;\
        static_listnode *__m_pNode_Prev = NULL;\
        vos_static_list_cb_t *__m_list = (vos_static_list_cb_t *)plist1;\
        __s_list_lock(__m_list);  \
        for( __m_pNode_Prev = vos_static_listtail(__m_list); __m_pNode_Prev;)\
        {   \
            __m_pNode = __m_pNode_Prev; \
            __m_pNode_Prev = ((static_listnode *)(__m_pNode))->prev; \

#define FOR_Static_List_End_Reverse()  \
        }   \
        __s_list_unlock(__m_list);  \
    }



#ifdef __cplusplus
}
#endif

#endif /* _VOS_STATICLIST_H */
