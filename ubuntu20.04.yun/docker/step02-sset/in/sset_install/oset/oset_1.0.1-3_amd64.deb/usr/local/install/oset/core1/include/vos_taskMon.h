/**
 * @file vos_taskMon.h
 * @brief vos taskMon 头文件
 * @details 任务监测模块头文件
 * @version 1.0
 * @author  wujianming  (wujianming@sylincom.com)
 * @date 2019.02.12
 * @copyright 
 *    Copyright (c) 2018 Sylincom.
 *    All rights reserved.
*/

#ifndef __VOS_TASK_MON_H__
#define __VOS_TASK_MON_H__
#include "vos_types.h"

#ifdef    __cplusplus
extern "C"
{
#endif /* __cplusplus */

#define VOS_TASK_STATE_PRV_D     (0x1 << 0 ) // uninterruptible sleep (usually IO)
#define VOS_TASK_STATE_PRV_R     (0x1 << 1 ) // running or runnable (on run queue)
#define VOS_TASK_STATE_PRV_S     (0x1 << 2 ) // interruptible sleep (waiting for an event to complete)
#define VOS_TASK_STATE_PRV_T     (0x1 << 3 ) // stopped by job control signal
#define VOS_TASK_STATE_PRV_t     (0x1 << 4 ) // stopped by debugger during the tracing
#define VOS_TASK_STATE_PRV_W     (0x1 << 5 ) // paging (not valid since the 2.6.xx kernel)
#define VOS_TASK_STATE_PRV_X     (0x1 << 6 ) // dead (should never be seen)
#define VOS_TASK_STATE_PRV_Z     (0x1 << 7 ) // defunct ("zombie") process, terminated but not reaped by its parent
#define VOS_TASK_STATE_PRV_N     (0x1 << 8 ) // low-priority (nice to other users)
#define VOS_TASK_STATE_PRV_L     (0x1 << 9 ) // has pages locked into memory (for real-time and custom IO)
#define VOS_TASK_STATE_PRV_l     (0x1 << 10) // is multi-threaded (using CLONE_THREAD, like NPTL pthreads do)
#define VOS_TASK_STATE_PRV_EXIT  (0x1 << 11) // task not exist
#define VOS_TASK_STATE_PRV_CPU_H (0x1 << 12) // cpu usage high


/** VOS 任务状态枚举值 */
typedef enum taskState_s{
    VOS_TASK_STATE_T           = VOS_TASK_STATE_PRV_T,     ///< stopped by job control signal
    VOS_TASK_STATE_t           = VOS_TASK_STATE_PRV_t,     ///< stopped by debugger during the tracing
    VOS_TASK_STATE_Z           = VOS_TASK_STATE_PRV_Z,     ///< defunct ("zombie") process, terminated but not reaped by its parent
    VOS_TASK_STATE_EXIT        = VOS_TASK_STATE_PRV_EXIT,  ///< task not exist
    VOS_TASK_STATE_CPU_H       = VOS_TASK_STATE_PRV_CPU_H, ///< cpu usage high
}vos_taskState_t;


/** VOS 任务监测信息 */
typedef struct taskMonInfo_s{
    LONG id;                     ///< 任务 ID
    LONG is_process;             ///< 任务 是否为进程
    vos_taskState_t state;       ///< 任务 状态
    LONG cpu_usage;              ///< 任务 CPU 利用率
}vos_taskMonInfo_t;

/** 
 * 任务异常触发的回调函数原型 
 * 第一个参数为   state       当前状态
 * 第二个参数为   pInfo       监测信息
 * 返回值         成功返回 VOS_OK；失败 可自定义。
 */
typedef LONG(*taskMon_state_cb)(LONG ,const vos_taskMonInfo_t *);

/** VOS 任务注册信息 */
typedef struct taskMonRegInfo_s{
    LONG id;                         ///< 任务 ID,linux 环境下进程使用PID，线程使用SPID
    CHAR name[VOS_NAME_MAX_LENGTH];  ///< 任务 名
    LONG is_process;                 ///< 任务 是否为进程
    vos_taskState_t trigger_state;   ///< 触发回调函数的状态
    LONG cpu_usage_high_threshold;   ///< 任务 CPU 利用率过高门限，范围 0-100
    taskMon_state_cb callback;       ///< 任务状态回调函数
}taskMonRegInfo_t;



/** 
 * 添加被监测任务 
 * @param[in ]   reginfo          任务信息
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_taskMonReg(taskMonRegInfo_t *reginfo);

/** 
 * 删除被监测任务 
 * @param[in ]   id                        任务ID
 * @return       VOS_OK - 成功，其他 - 失败
 */
LONG VOS_taskMonUnReg(LONG id);






#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __VOS_TASK_MON_H__ */
