/************************************************************************
 *File name: oset-abort.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_ABORT_H
#define OSET_ABORT_H

#ifdef __cplusplus
extern "C" {
#endif

OSET_GNUC_NORETURN void oset_abort(void);

#ifdef __cplusplus
}
#endif

#endif /* OSET_ABORT_H */
