/************************************************************************
 *File name: oset-conv.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_CONV_H
#define OSET_CONV_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_HEX(I, I_LEN, O) oset_ascii_to_hex((char*)I, I_LEN, O, sizeof(O))
void *oset_ascii_to_hex(char *in, int in_len, void *out, int out_len);
void *oset_hex_to_ascii(void *in, int in_len, void *out, int out_len);
void *oset_uint64_to_buffer(uint64_t num, int size, void *buffer);
uint64_t oset_buffer_to_uint64(void *buffer, int size);
void *oset_bcd_to_buffer(const char *in, void *out, int *out_len);
void *oset_bcd_to_buffer_reverse_order(const char *in, void *out, int *out_len);
void *oset_buffer_to_bcd(uint8_t *in, int in_len, void *out);

char oset_from_hex(char ch);

char *oset_uint24_to_0string(oset_uint24_t x);
char *oset_uint28_to_0string(uint32_t x);
char *oset_uint32_to_0string(uint32_t x);
char *oset_uint36_to_0string(uint64_t x);
char *oset_uint64_to_0string(uint64_t x);
char *oset_uint64_to_string(uint64_t x);

oset_uint24_t oset_uint24_from_string(char *str);
uint64_t oset_uint64_from_string(char *str);

void oset_extract_digit_from_string(char *digit, char *string);

#ifdef __cplusplus
}
#endif

#endif /* OSET_CONV_H */
