/************************************************************************
 *File name: oset-core.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#ifndef OSET_CORE_H
#define OSET_CORE_H

#include "base-config.h"

#define OSET_CORE_INSIDE

#include "oset-compat.h"
#include "oset-macros.h"
#include "oset-list.h"
#include "oset-pool.h"
#include "oset-abort.h"
#include "oset-strings.h"
#include "oset-errno.h"
#include "oset-time.h"
#include "oset-conv.h"
#include "oset-log.h"
#include "oset-pkbuf.h"
#include "oset-memory.h"
#include "oset-rand.h"
#include "oset-uuid.h"
#include "oset-rbtree.h"
#include "oset-timer.h"
#include "oset-thread.h"
#include "oset-threadplus.h"
#include "oset-threadpool.h"
#include "oset-process.h"
#include "oset-signal.h"
#include "oset-sockaddr.h"
#include "oset-socket.h"
#include "oset-sockpair.h"
#include "oset-socknode.h"
#include "oset-udp.h"
#include "oset-tcp.h"
#include "oset-queue.h"
#include "oset-poll.h"
#include "oset-notify.h"
#include "oset-env.h"
#include "oset-hash.h"
#include "oset-misc.h"
#include "oset-getopt.h"
#include "oset-3gpp-types.h"
#include "oset-tlv.h"
#include "oset-tlv-msg.h"
#include "oset-ring.h"
#include "oset-yaml.h"


#undef OSET_CORE_INSIDE

#ifdef __cplusplus
extern "C" {
#endif

extern int __oset_mem_domain;
extern int __oset_sock_domain;
extern int __oset_event_domain;
extern int __oset_thread_domain;
extern int __oset_threadplus_domain;
extern int __oset_threadpool_domain;
extern int __oset_tlv_domain;
extern int __oset_ring_domain;


typedef struct {
    struct {
        int pool;
        int domain_pool;
        oset_log_level_e level;
    } log;

    struct {
        int pool;
        int config_pool;
    } pkbuf;

    struct {
        int pool;
    } tlv;

} oset_core_context_t;

void oset_core_initialize(void);
void oset_core_terminate(void);

oset_core_context_t *oset_core(void);

#ifdef __cplusplus
}
#endif

#endif /* OSET_CORE_H */
