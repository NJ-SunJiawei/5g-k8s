/************************************************************************
 *File name: oset-env.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_ENV_H
#define OSET_ENV_H

#ifdef __cplusplus
extern "C" {
#endif

char *oset_env_get(const char *envvar);
int oset_env_set(const char *envvar, const char *value);
int oset_env_delete(const char *envvar);

#ifdef __cplusplus
}
#endif

#endif /* OSET_ENV_H */
