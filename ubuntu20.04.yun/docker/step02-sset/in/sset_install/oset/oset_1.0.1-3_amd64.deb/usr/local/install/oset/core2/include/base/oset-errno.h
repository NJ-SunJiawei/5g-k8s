/************************************************************************
 *File name: oset-errno.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_ERRNO_H
#define OSET_ERRNO_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)

typedef DWORD oset_err_t;

#define OSET_ENOMEM                  ERROR_NOT_ENOUGH_MEMORY
#define OSET_EACCES                  ERROR_ACCESS_DENIED
#define OSET_EEXIST                  ERROR_ALREADY_EXISTS
#define OSET_EEXIST_FILE             ERROR_FILE_EXISTS
#define OSET_ECONNRESET              WSAECONNRESET
#define OSET_ETIMEDOUT               WSAETIMEDOUT
#define OSET_ECONNREFUSED            WSAECONNREFUSED
#define OSET_EBADF                   WSAEBADF
#define OSET_EAGAIN                  WSAEWOULDBLOCK

#define oset_errno                   GetLastError()
#define oset_set_errno(err)          SetLastError(err)
#define oset_socket_errno            WSAGetLastError()
#define oset_set_socket_errno(err)   WSASetLastError(err)

#else

typedef int oset_err_t;

#define OSET_ENOMEM                  ENOMEM
#define OSET_EACCES                  EACCES
#define OSET_EEXIST                  EEXIST
#define OSET_EEXIST_FILE             EEXIST
#define OSET_ECONNRESET              ECONNRESET
#define OSET_ETIMEDOUT               ETIMEDOUT
#define OSET_ECONNREFUSED            ECONNREFUSED
#define OSET_EBADF                   EBADF
#if (__hpux__)
#define OSET_EAGAIN                  EWOULDBLOCK
#else
#define OSET_EAGAIN                  EAGAIN
#endif

#define oset_errno                   errno
#define oset_socket_errno            errno
#define oset_set_errno(err)          errno = err
#define oset_set_socket_errno(err)   errno = err

#endif

#define OSET_OK       0
#define OSET_ERROR   -1
#define OSET_RETRY   -2
#define OSET_TIMEUP  -3
#define OSET_DONE    -4

char *oset_strerror(oset_err_t err, char *buf, size_t size);

#ifdef __cplusplus
}
#endif

#endif /* OSET_ERRNO_H */
