/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/************************************************************************
 *File name: oset-hash.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_HASH_H
#define OSET_HASH_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_HASH_KEY_STRING     (-1)

typedef struct oset_hash_t oset_hash_t;
typedef struct oset_hash_index_t oset_hash_index_t;
typedef unsigned int (*oset_hashfunc_t)(const char *key, int *klen);
unsigned int oset_hashfunc_default(const char *key, int *klen);

oset_hash_t *oset_hash_make(void);
oset_hash_t *oset_hash_make_custom(oset_hashfunc_t oset_hash_func);
void oset_hash_destroy(oset_hash_t *ht);

#define oset_hash_set(ht, key, klen, val) \
    oset_hash_set_debug(ht, key, klen, val, OSET_FILE_LINE)
void oset_hash_set_debug(oset_hash_t *ht,
        const void *key, int klen, const void *val, const char *file_line);
#define oset_hash_get(ht, key, klen) \
    oset_hash_get_debug(ht, key, klen, OSET_FILE_LINE)
void *oset_hash_get_debug(oset_hash_t *ht,
        const void *key, int klen, const char *file_line);
#define oset_hash_get_or_set(ht, key, klen, val) \
    oset_hash_get_or_set_debug(ht, key, klen, val, OSET_FILE_LINE)
void *oset_hash_get_or_set_debug(oset_hash_t *ht,
        const void *key, int klen, const void *val, const char *file_line);

oset_hash_index_t *oset_hash_first(oset_hash_t *ht);
oset_hash_index_t *oset_hash_next(oset_hash_index_t *hi);
void oset_hash_this(oset_hash_index_t *hi, 
        const void **key, int *klen, void **val);

const void* oset_hash_this_key(oset_hash_index_t *hi);
int oset_hash_this_key_len(oset_hash_index_t *hi);
void* oset_hash_this_val(oset_hash_index_t *hi);
unsigned int oset_hash_count(oset_hash_t *ht);
void oset_hash_clear(oset_hash_t *ht);

typedef int (oset_hash_do_callback_fn_t)(
        void *rec, const void *key, int klen, const void *value);

int oset_hash_do(oset_hash_do_callback_fn_t *comp,
        void *rec, const oset_hash_t *ht);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* OSET_HASH_H */
