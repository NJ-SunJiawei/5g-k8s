/************************************************************************
 *File name: oset-list.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_LIST_H
#define OSET_LIST_H

#ifdef __cplusplus
extern "C" {
#endif

struct oset_list_s {
    struct oset_list_s *prev, *next;
};
typedef struct oset_list_s oset_list_t;
typedef struct oset_list_s oset_lnode_t;;

#define OSET_LIST(name) \
    oset_list_t name = { NULL, NULL }

#define oset_list_init(list) do { \
    (list)->prev = (NULL); \
    (list)->next = (NULL); \
} while (0)

__attribute__((unused)) static oset_inline void *oset_list_first(const oset_list_t *list)
{
    return list->next;
}

__attribute__((unused)) static oset_inline void *oset_list_last(const oset_list_t *list)
{
    return list->prev;
}

__attribute__((unused)) static oset_inline void *oset_list_next(void *lnode)
{
    oset_list_t *node = lnode;
    return node->next;
}

__attribute__((unused)) static oset_inline void *oset_list_prev(void *lnode)
{
    oset_list_t *node = lnode;
    return node->prev;
}

#define oset_list_entry(ptr, type, member) oset_container_of(ptr, type, member)

#define oset_list_for_each(list, node) \
    for (node = oset_list_first(list); (node); \
        node = oset_list_next(node))

#define oset_list_for_each_entry(list, node, member) \
    for (node = oset_list_entry(oset_list_first(list), typeof(*node), member); \
            (&node->member); \
                node = oset_list_entry( \
                        oset_list_next(&node->member), typeof(*node), member))

#define oset_list_for_each_safe(list, n, node) \
    for (node = oset_list_first(list); \
        (node) && (n = oset_list_next(node), 1); \
        node = n)

#define oset_list_for_each_entry_safe(list, n, node, member) \
    for (node = oset_list_entry(oset_list_first(list), typeof(*node), member); \
            (&node->member) && \
                (n = oset_list_entry( \
                    oset_list_next(&node->member), typeof(*node), member), 1); \
            node = n)

__attribute__((unused)) static oset_inline void oset_list_prepend(oset_list_t *list, void *lnode)
{
    oset_list_t *node = lnode;

    node->prev = NULL;
    node->next = list->next;
    if (list->next)
        list->next->prev = node;
    else
        list->prev = node;
    list->next = node;
}

__attribute__((unused)) static oset_inline void oset_list_add(oset_list_t *list, void *lnode)
{
    oset_list_t *node = lnode;

    node->prev = list->prev;
    node->next = NULL;
    if (list->prev)
        list->prev->next = node;
    else
        list->next = node;
    list->prev = node;
}

__attribute__((unused)) static oset_inline void oset_list_remove(oset_list_t *list, void *lnode)
{
    oset_list_t *node = lnode;
    oset_list_t *prev = node->prev;
    oset_list_t *next = node->next;;

    if (prev)
        prev->next = next;
    else
        list->next = next;

    if (next)
        next->prev = prev;
    else
        list->prev = prev;
}

__attribute__((unused)) static oset_inline void oset_list_insert_prev(
        oset_list_t *list, void *lnext, void *lnode)
{
    oset_list_t *node = lnode;
    oset_list_t *next = lnext;

    node->prev = next->prev;
    node->next = next;
    if (next->prev)
        next->prev->next = node;
    else
        list->next = node;
    next->prev = node;
}

__attribute__((unused)) static oset_inline void oset_list_insert_next(
        oset_list_t *list, void *lprev, void *lnode)
{
    oset_list_t *node = lnode;
    oset_list_t *prev = lprev;

    node->prev = prev;
    node->next = prev->next;
    if (prev->next)
        prev->next->prev = node;
    else
        list->prev = node;
    prev->next = node;
}

typedef int (*oset_list_compare_f)(oset_lnode_t *n1, oset_lnode_t *n2);
#define oset_list_insert_sorted(__list, __lnode, __compare) \
    __oset_list_insert_sorted(__list, __lnode, (oset_list_compare_f)__compare);

__attribute__((unused)) static oset_inline void __oset_list_insert_sorted(
    oset_list_t *list, void *lnode, oset_list_compare_f compare)
{
    oset_list_t *node = lnode;
    oset_list_t *iter = NULL;

    oset_list_for_each(list, iter) {
        if ((*compare)(node, iter) < 0) {
            oset_list_insert_prev(list, iter, node);
            break;
        }
    }

    if (iter == NULL)
        oset_list_add(list, node);
}

__attribute__((unused)) static oset_inline bool oset_list_empty(const oset_list_t *list)
{
    return list->next == NULL;
}

__attribute__((unused)) static oset_inline int oset_list_count(const oset_list_t *list)
{
    oset_list_t *node;
    int i = 0;
    oset_list_for_each(list, node)
        i++;
    return i;
}

/*****************************************************************
This code is taken from the APR library.
* <pre>
*	  +->+------+<-+  +->+------+<-+  +->+------+<-+
*	  |  |struct|  |  |  |struct|  |  |  |struct|  |
*	 /	 | elem |	\/	 | elem |	\/	 | elem |  \
* ...	 |		|	/\	 |		|	/\	 |		|	...
*		 +------+  |  |  +------+  |  |  +------+
*	...--|prev	|  |  +--|ring	|  |  +--|prev	|
*		 |	next|--+	 | entry|--+	 |	next|--...
*		 +------+		 +------+		 +------+
*		 | etc. |		 | etc. |		 | etc. |
*		 :		:		 :		:		 :		:
* </pre>

* <pre>
*		 last							 first
*	  +->+------+<-+  +->sentinel<-+  +->+------+<-+
*	  |  |struct|  |  | 		   |  |  |struct|  |
*	 /	 | elem |	\/				\/	 | elem |  \
* ...	 |		|	/\				/\	 |		|	...
*		 +------+  |  |  +------+  |  |  +------+
*	...--|prev	|  |  +--|ring	|  |  +--|prev	|
*		 |	next|--+	 |	head|--+	 |	next|--...
*		 +------+		 +------+		 +------+
*		 | etc. |						 | etc. |
*		 :		:						 :		:
* </pre>
*****************************************************************/

#define OSET_RING_ENTRY(elem)						\
    struct {								\
	struct elem * volatile next;					\
	struct elem * volatile prev;					\
    }

#define OSET_RING_HEAD(head, elem)					\
		struct head {							\
		struct elem * volatile next;					\
		struct elem * volatile prev;					\
		}

#define OSET_RING_FIRST(hp)	(hp)->next
#define OSET_RING_LAST(hp)	(hp)->prev
#define OSET_OFFSETOF(s_type,field) offsetof(s_type,field)

#define OSET_RING_NEXT(ep, link)	(ep)->link.next
#define OSET_RING_PREV(ep, link)	(ep)->link.prev

#define OSET_RING_ELEM_INIT(ep, link) do {				\
	OSET_RING_NEXT((ep), link) = (ep);				\
	OSET_RING_PREV((ep), link) = (ep);				\
    } while (0)


#define OSET_RING_SENTINEL(hp, elem, link)				\
    (struct elem *)((char *)(&(hp)->next) - OSET_OFFSETOF(struct elem, link))

#define OSET_RING_INIT(hp, elem, link) do {				\
			OSET_RING_FIRST((hp)) = OSET_RING_SENTINEL((hp), elem, link); \
			OSET_RING_LAST((hp))  = OSET_RING_SENTINEL((hp), elem, link); \
			} while (0)

#define OSET_RING_EMPTY(hp, elem, link)					\
    (OSET_RING_FIRST((hp)) == OSET_RING_SENTINEL((hp), elem, link))

#define OSET_RING_SPLICE_BEFORE(lep, ep1, epN, link) do {		\
	OSET_RING_NEXT((epN), link) = (lep);				\
	OSET_RING_PREV((ep1), link) = OSET_RING_PREV((lep), link);	\
	OSET_RING_NEXT(OSET_RING_PREV((lep), link), link) = (ep1);	\
	OSET_RING_PREV((lep), link) = (epN);				\
    } while (0)
    
#define OSET_RING_SPLICE_AFTER(lep, ep1, epN, link) do {			\
		OSET_RING_PREV((ep1), link) = (lep); 			\
		OSET_RING_NEXT((epN), link) = OSET_RING_NEXT((lep), link);	\
		OSET_RING_PREV(OSET_RING_NEXT((lep), link), link) = (epN);	\
		OSET_RING_NEXT((lep), link) = (ep1); 			\
		} while (0)

#define OSET_RING_SPLICE_HEAD(hp, ep1, epN, elem, link)			\
	    OSET_RING_SPLICE_AFTER(OSET_RING_SENTINEL((hp), elem, link),	\
			     (ep1), (epN), link)
			     
#define OSET_RING_INSERT_HEAD(hp, nep, elem, link)			\
		OSET_RING_SPLICE_HEAD((hp), (nep), (nep), elem, link)
			
#define OSET_RING_SPLICE_TAIL(hp, ep1, epN, elem, link)			\
		OSET_RING_SPLICE_BEFORE(OSET_RING_SENTINEL((hp), elem, link), \
					 (ep1), (epN), link)

#define OSET_RING_INSERT_TAIL(hp, nep, elem, link)			\
	    OSET_RING_SPLICE_TAIL((hp), (nep), (nep), elem, link)

#define OSET_RING_INSERT_BEFORE(lep, nep, link)				\
	    OSET_RING_SPLICE_BEFORE((lep), (nep), (nep), link)
	
#define OSET_RING_INSERT_AFTER(lep, nep, link)				\
		OSET_RING_SPLICE_AFTER((lep), (nep), (nep), link)

#define OSET_RING_UNSPLICE(ep1, epN, link) do {				\
	OSET_RING_NEXT(OSET_RING_PREV((ep1), link), link) =		\
		     OSET_RING_NEXT((epN), link);			\
	OSET_RING_PREV(OSET_RING_NEXT((epN), link), link) =		\
		     OSET_RING_PREV((ep1), link);			\
    } while (0)

#define OSET_RING_REMOVE(ep, link)					\
        OSET_RING_UNSPLICE((ep), (ep), link)


#ifdef __cplusplus
}
#endif

#endif /* OSET_LIST_H */
