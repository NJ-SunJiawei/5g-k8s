/************************************************************************
 *File name: oset-log.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_LOG_H
#define OSET_LOG_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef OSET_LOG_DOMAIN
#define OSET_LOG_DOMAIN      1
#endif

#define oset_fatal(...) oset_log_message(OSET_LOG_FATAL, 0, __VA_ARGS__)
#define oset_error(...) oset_log_message(OSET_LOG_ERROR, 0, __VA_ARGS__)
#define oset_warn(...) oset_log_message(OSET_LOG_WARN, 0, __VA_ARGS__)
#define oset_info(...) oset_log_message(OSET_LOG_INFO, 0, __VA_ARGS__)
#define oset_debug(...) oset_log_message(OSET_LOG_DEBUG, 0, __VA_ARGS__)
#define oset_trace(...) oset_log_message(OSET_LOG_TRACE, 0, __VA_ARGS__)

#define oset_log_message(level, err, ...) \
    oset_log_printf(level, OSET_LOG_DOMAIN, \
    err, __FILE__, __LINE__, OSET_FUNC,  \
    0, __VA_ARGS__) 

#define oset_log_print(level, ...) \
    oset_log_printf(level, OSET_LOG_DOMAIN, \
    0, NULL, 0, NULL,  \
    1, __VA_ARGS__) 

#define oset_log_hexdump(level, _d, _l) \
    oset_log_hexdump_func(level, OSET_LOG_DOMAIN, _d, _l)

typedef enum {
    OSET_LOG_NONE,
    OSET_LOG_FATAL,
    OSET_LOG_ERROR,
    OSET_LOG_WARN,
    OSET_LOG_INFO,
    OSET_LOG_DEBUG,
    OSET_LOG_TRACE,
    OSET_LOG_DEFAULT = OSET_LOG_INFO,
    OSET_LOG_FULL = OSET_LOG_TRACE,
} oset_log_level_e;

typedef struct oset_log_s oset_log_t;
typedef struct oset_log_domain_s oset_log_domain_t;

void oset_log_init(void);
void oset_log_final(void);
void oset_log_cycle(void);

oset_log_t *oset_log_add_stderr(void);
oset_log_t *oset_log_add_file(const char *name);
void oset_log_remove(oset_log_t *log);

oset_log_domain_t *oset_log_add_domain(const char *name, oset_log_level_e level);
oset_log_domain_t *oset_log_find_domain(const char *name);
void oset_log_remove_domain(oset_log_domain_t *domain);

void oset_log_set_domain_level(int id, oset_log_level_e level);
oset_log_level_e oset_log_get_domain_level(int id);

const char *oset_log_get_domain_name(int id);
int oset_log_get_domain_id(const char *name);

void oset_log_install_domain(int *domain_id,
        const char *name, oset_log_level_e level);
int oset_log_config_domain(const char *domain, const char *level);

void oset_log_set_mask_level(const char *mask, oset_log_level_e level);

void oset_log_vprintf(oset_log_level_e level, int id,
    oset_err_t err, const char *file, int line, const char *func,
    int content_only, const char *format, va_list ap);
void oset_log_printf(oset_log_level_e level, int domain_id,
    oset_err_t err, char *file, int line, const char *func,
    int content_only, const char *format, ...)
    OSET_GNUC_PRINTF(8, 9);

void oset_log_hexdump_func(oset_log_level_e level, int domain_id,
    const unsigned char *data, size_t len);

#define oset_assert(expr) \
    do { \
        if (oset_likely(expr)) ; \
        else { \
            oset_fatal("%s: Assertion `%s' failed.", OSET_FUNC, #expr); \
            oset_abort(); \
        } \
    } while(0)

#define oset_assert_if_reached() \
    do { \
        oset_warn("%s: should not be reached.", OSET_FUNC); \
        oset_abort(); \
    } while(0)

#define oset_expect(expr) \
    do { \
        if (oset_likely(expr)) ; \
        else { \
            oset_error("%s: Expectation `%s' failed.", OSET_FUNC, #expr); \
        } \
    } while (0)

#define oset_expect_or_return(expr) \
    do { \
        if (oset_likely(expr)) ; \
        else { \
            oset_error("%s: Expectation `%s' failed.", OSET_FUNC, #expr); \
            return; \
        } \
    } while (0)

#define oset_expect_or_return_val(expr, val) \
    do { \
        if (oset_likely(expr)) ; \
        else { \
            oset_error("%s: Expectation `%s' failed.", OSET_FUNC, #expr); \
            return (val); \
        } \
    } while (0)

#ifdef __cplusplus
}
#endif

#endif /* OSET_LOG_H */
