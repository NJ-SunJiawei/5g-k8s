/************************************************************************
 *File name: oset-macros.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_MACROS_H
#define OSET_MACROS_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __GNUC__
#define OSET_GNUC_CHECK_VERSION(major, minor) \
    ((__GNUC__ > (major)) || \
     ((__GNUC__ == (major)) && (__GNUC_MINOR__ >= (minor))))
#else
#define OSET_GNUC_CHECK_VERSION(major, minor) 0
#endif

#if defined(_MSC_VER)
#define oset_inline __inline
#else
#define oset_inline __inline__
#endif

#if defined(_WIN32)
#define OSET_FUNC __FUNCTION__
#elif defined(__STDC_VERSION__) && __STDC_VERSION__ < 199901L
#define OSET_FUNC __FUNCTION__
#else
#define OSET_FUNC __func__
#endif

#if defined(__GNUC__)
#define oset_likely(x) __builtin_expect (!!(x), 1)
#define oset_unlikely(x) __builtin_expect (!!(x), 0)
#else
#define oset_likely(v) v
#define oset_unlikely(v) v
#endif

#if __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ > 4)
#if !defined (__clang__) && OSET_GNUC_CHECK_VERSION (4, 4)
#define OSET_GNUC_PRINTF(f, v) __attribute__ ((format (gnu_printf, f, v)))
#else
#define OSET_GNUC_PRINTF(f, v) __attribute__ ((format (__printf__, f, v)))
#endif
#define OSET_GNUC_NORETURN __attribute__((__noreturn__))
#else
#define OSET_GNUC_PRINTF(f, v) 
#define OSET_GNUC_NORETURN
#endif

#if __GNUC__ > 6
#define OSET_GNUC_FALLTHROUGH __attribute__ ((fallthrough))
#else
#define OSET_GNUC_FALLTHROUGH
#endif

#if defined(_WIN32)
#define htole16(x) (x)
#define htole32(x) (x)
#define htole64(x) (x)
#define le16toh(x) (x)
#define le32toh(x) (x)
#define le64toh(x) (x)

#define htobe16(x) htons((x))
#define htobe32(x) htonl((x))
#define htobe64(x) htonll((x))
#define be16toh(x) ntohs((x))
#define be32toh(x) ntohl((x))
#define be64toh(x) ntohll((x))

#elif defined(__APPLE__)
#include <libkern/OSByteOrder.h>
#define htole16(x) OSSwapHostToLittleInt16((x))
#define htole32(x) OSSwapHostToLittleInt32((x))
#define htole64(x) OSSwapHostToLittleInt64((x))
#define le16toh(x) OSSwapLittleToHostInt16((x))
#define le32toh(x) OSSwapLittleToHostInt32((x))
#define le64toh(x) OSSwapLittleToHostInt64((x))

#define htobe16(x) OSSwapHostToBigInt16((x))
#define htobe32(x) OSSwapHostToBigInt32((x))
#define htobe64(x) OSSwapHostToBigInt64((x))
#define be16toh(x) OSSwapBigToHostInt16((x))
#define be32toh(x) OSSwapBigToHostInt32((x))
#define be64toh(x) OSSwapBigToHostInt64((x))

#elif defined(__FreeBSD__)
#include <sys/endian.h>

#elif defined(__linux__)
#include <endian.h>

#endif

#ifndef WORDS_BIGENDIAN
#if OSET_BYTE_ORDER == OSET_BIG_ENDIAN
#define WORDS_BIGENDIAN 1
#endif
#endif

typedef struct oset_uint24_s {
    uint32_t v:24;
}  __attribute__ ((packed)) oset_uint24_t;

__attribute__((unused)) static oset_inline oset_uint24_t oset_be24toh(oset_uint24_t x)
{
    uint32_t tmp = x.v;
    tmp = be32toh(tmp);
    x.v = tmp >> 8;
    return x;
}

__attribute__((unused)) static oset_inline oset_uint24_t oset_htobe24(oset_uint24_t x)
{
    uint32_t tmp = x.v;
    tmp = htobe32(tmp);
    x.v = tmp >> 8;
    return x;
}

#if OSET_BYTE_ORDER == OSET_BIG_ENDIAN
#define ED2(x1, x2) x1 x2
#define ED3(x1, x2, x3) x1 x2 x3
#define ED4(x1, x2, x3, x4) x1 x2 x3 x4
#define ED5(x1, x2, x3, x4, x5) x1 x2 x3 x4 x5
#define ED6(x1, x2, x3, x4, x5, x6) x1 x2 x3 x4 x5 x6
#define ED7(x1, x2, x3, x4, x5, x6, x7) x1 x2 x3 x4 x5 x6 x7
#define ED8(x1, x2, x3, x4, x5, x6, x7, x8) x1 x2 x3 x4 x5 x6 x7 x8
#else
#define ED2(x1, x2) x2 x1
#define ED3(x1, x2, x3) x3 x2 x1
#define ED4(x1, x2, x3, x4) x4 x3 x2 x1
#define ED5(x1, x2, x3, x4, x5) x5 x4 x3 x2 x1
#define ED6(x1, x2, x3, x4, x5, x6) x6 x5 x4 x3 x2 x1
#define ED7(x1, x2, x3, x4, x5, x6, x7) x7 x6 x5 x4 x3 x2 x1
#define ED8(x1, x2, x3, x4, x5, x6, x7, x8) x8 x7 x6 x5 x4 x3 x2 x1
#endif

#define OSET_STATIC_ASSERT(expr) \
    typedef char dummy_for_oset_static_assert##__LINE__[(expr) ? 1 : -1]

#define OSET_ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

#define OSET_STRINGIFY(n)            OSET_STRINGIFY_HELPER(n)
#define OSET_STRINGIFY_HELPER(n)     #n

#define OSET_PASTE(n1, n2)           OSET_PASTE_HELPER(n1, n2)
#define OSET_PASTE_HELPER(n1, n2)    n1##n2

#define OSET_INET_NTOP(src, dst) \
    inet_ntop(AF_INET, (void *)(uintptr_t)(src), (dst), INET_ADDRSTRLEN)
#define OSET_INET6_NTOP(src, dst) \
    inet_ntop(AF_INET6, (void *)(src), (dst), INET6_ADDRSTRLEN)

#define oset_max(x , y)  (((x) > (y)) ? (x) : (y))
#define oset_min(x , y)  (((x) < (y)) ? (x) : (y))

#if defined(_WIN32)
#define OSET_IS_DIR_SEPARATOR(c) ((c) == OSET_DIR_SEPARATOR || (c) == '/')
#else
#define OSET_IS_DIR_SEPARATOR(c) ((c) == OSET_DIR_SEPARATOR)
#endif

#define oset_container_of(ptr, type, member) \
    (type *)((unsigned char *)ptr - offsetof(type, member))

#ifndef SWITCH_CASE_INIT
#define SWITCH_CASE_INIT
    #define SWITCH(X)    {char *__switch_p__,  __switch_next__; \
                          for (__switch_p__ = \
                                  X ? (char *)X : (char *)"OSET_SWITCH_NULL", \
                                  __switch_next__ = 1; \
                              __switch_p__; \
                              __switch_p__ = 0, __switch_next__ = 1) { {
    #define CASE(X)            } if (!__switch_next__ || \
                                     !(__switch_next__ = \
                                         strcmp(__switch_p__, X))) {
    #define DEFAULT            } {
    #define END          }}}
#endif

#define OSET_ARG_MAX                     256
#define OSET_MAX_FILEPATH_LEN            256
#define OSET_MAX_IFNAME_LEN              32

#define OSET_FILE_LINE __FILE__ ":" OSET_STRINGIFY(__LINE__)

#define oset_uint64_to_uint32(x) ((x >= 0xffffffffUL) ? 0xffffffffU : x)

#ifdef __cplusplus
}
#endif

#endif /* OSET_MACROS_H */
