/************************************************************************
 *File name: oset-memory.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_MEMORY_H
#define OSET_MEMORY_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_MEM_CLEAR(__dATA) \
    do { \
        if ((__dATA)) { \
            oset_free((__dATA)); \
            (__dATA) = NULL; \
        } \
    } while(0)
#define OSET_MEM_STORE(__dST, __sRC) \
    do { \
        oset_assert((__sRC)); \
        OSET_MEM_CLEAR(__dST); \
        (__dST) = oset_calloc(sizeof(*(__sRC)), sizeof(uint8_t)); \
        oset_assert((__dST)); \
        memcpy((__dST), (__sRC), sizeof(*(__sRC))*sizeof(uint8_t)); \
    } while(0)

#define oset_malloc(size) oset_malloc_debug(size, OSET_FILE_LINE, false)
#define oset_malloc_or_assert(size) \
    oset_malloc_debug(size, OSET_FILE_LINE, true)
void *oset_malloc_debug(size_t size, const char *file_line, bool abort);
void oset_free(void *ptr);
#define oset_calloc(nmemb, size) \
    oset_calloc_debug(nmemb, size, OSET_FILE_LINE, false)
#define oset_calloc_or_assert(nmemb, size) \
    oset_calloc_debug(nmemb, size, OSET_FILE_LINE, true)
void *oset_calloc_debug(
        size_t nmemb, size_t size, const char *file_line, bool abort);
#define oset_realloc(ptr, size) \
    oset_realloc_debug(ptr, size, OSET_FILE_LINE, false)
#define oset_realloc_or_assert(ptr, size) \
    oset_realloc_debug(ptr, size, OSET_FILE_LINE, true)
void *oset_realloc_debug(
        void *ptr, size_t size, const char *file_line, bool abort);

#ifdef __cplusplus
}
#endif

#endif /* OSET_MEMORY_H */
