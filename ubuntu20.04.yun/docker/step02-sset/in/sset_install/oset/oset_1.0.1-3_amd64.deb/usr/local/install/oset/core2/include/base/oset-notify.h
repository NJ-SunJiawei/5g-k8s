/************************************************************************
 *File name: oset-notify.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_NOTIFY_H
#define OSET_NOTIFY_H

#ifdef __cplusplus
extern "C" {
#endif

void oset_notify_init(oset_pollset_t *pollset);
void oset_notify_final(oset_pollset_t *pollset);
int oset_notify_pollset(oset_pollset_t *pollset);

#ifdef __cplusplus
}
#endif

#endif /* OSET_NOTIFY_H */
