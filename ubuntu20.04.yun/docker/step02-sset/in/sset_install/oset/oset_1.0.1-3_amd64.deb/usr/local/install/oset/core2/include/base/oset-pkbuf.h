/************************************************************************
 *File name: oset-pkbuf.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_PKBUF_H
#define OSET_PKBUF_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_cluster_s {
    unsigned char *buffer;
    unsigned int size;

    unsigned int ref;
} oset_cluster_t;

typedef struct oset_pkbuf_pool_s oset_pkbuf_pool_t;
typedef struct oset_pkbuf_s {
    oset_lnode_t lnode;

    /* Currently it is used in SCTP stream number and PPID. */
    uint64_t param[2];

    oset_cluster_t *cluster;

    unsigned int len;

    unsigned char *head;
    unsigned char *tail;
    unsigned char *data;
    unsigned char *end;

    const char *file_line;
    
    oset_pkbuf_pool_t *pool;
} oset_pkbuf_t;

typedef struct oset_pkbuf_config_s {
    int cluster_128_pool;
    int cluster_256_pool;
    int cluster_512_pool;
    int cluster_1024_pool;
    int cluster_2048_pool;
    int cluster_8192_pool;
    int cluster_big_pool;
} oset_pkbuf_config_t;

void oset_pkbuf_init(void);
void oset_pkbuf_final(void);

void oset_pkbuf_default_init(oset_pkbuf_config_t *config);
void oset_pkbuf_default_create(oset_pkbuf_config_t *config);
void oset_pkbuf_default_destroy(void);

oset_pkbuf_pool_t *oset_pkbuf_pool_create(oset_pkbuf_config_t *config);
void oset_pkbuf_pool_destroy(oset_pkbuf_pool_t *pool);

#define oset_pkbuf_alloc(pool, size) \
    oset_pkbuf_alloc_debug(pool, size, OSET_FILE_LINE)
oset_pkbuf_t *oset_pkbuf_alloc_debug(
        oset_pkbuf_pool_t *pool, unsigned int size, const char *file_line);
void oset_pkbuf_free(oset_pkbuf_t *pkbuf);

void *oset_pkbuf_put_data(
        oset_pkbuf_t *pkbuf, const void *data, unsigned int len);
#define oset_pkbuf_copy(pkbuf) \
    oset_pkbuf_copy_debug(pkbuf, OSET_FILE_LINE)
oset_pkbuf_t *oset_pkbuf_copy_debug(oset_pkbuf_t *pkbuf, const char *file_line);
void oset_default_pkbuf_static(void);

__attribute__((unused)) static oset_inline int oset_pkbuf_tailroom(const oset_pkbuf_t *pkbuf)
{
    return pkbuf->end - pkbuf->tail;
}

__attribute__((unused)) static oset_inline int oset_pkbuf_headroom(const oset_pkbuf_t *pkbuf)
{
    return pkbuf->data - pkbuf->head;
}

__attribute__((unused)) static oset_inline void oset_pkbuf_reserve(oset_pkbuf_t *pkbuf, int len)
{
    pkbuf->data += len;
    pkbuf->tail += len;
}

__attribute__((unused)) static oset_inline void *oset_pkbuf_put(oset_pkbuf_t *pkbuf, unsigned int len)
{
    void *tmp = pkbuf->tail;

    pkbuf->tail += len;
    pkbuf->len += len;

    if (oset_unlikely(pkbuf->tail > pkbuf->end))
        oset_assert_if_reached();

    return tmp;
}

__attribute__((unused)) static oset_inline void oset_pkbuf_put_u8(oset_pkbuf_t *pkbuf, uint8_t val)
{
    *(uint8_t *)oset_pkbuf_put(pkbuf, 1) = val;
}

__attribute__((unused)) static oset_inline void oset_pkbuf_put_u16(oset_pkbuf_t *pkbuf, uint16_t val)
{
    uint8_t *p = oset_pkbuf_put(pkbuf, 2);
    uint16_t tmp = htobe16(val);
    memcpy(p, &tmp, 2);
}

__attribute__((unused)) static oset_inline void oset_pkbuf_put_u32(oset_pkbuf_t *pkbuf, uint32_t val)
{
    uint8_t *p = oset_pkbuf_put(pkbuf, 4);
    uint32_t tmp = htobe32(val);
    memcpy(p, &tmp, 4);
}

__attribute__((unused)) static oset_inline void *oset_pkbuf_push(oset_pkbuf_t *pkbuf, unsigned int len)
{
    pkbuf->data -= len;
    pkbuf->len += len;

    if (oset_unlikely(pkbuf->data < pkbuf->head))
        oset_assert_if_reached();

    return pkbuf->data;
}

__attribute__((unused)) static oset_inline void *oset_pkbuf_pull_inline(
        oset_pkbuf_t *pkbuf, unsigned int len)
{
    pkbuf->len -= len;
    return pkbuf->data += len;
}

__attribute__((unused)) static oset_inline void *oset_pkbuf_pull(oset_pkbuf_t *pkbuf, unsigned int len)
{
    return oset_unlikely(len > pkbuf->len) ?
        NULL : oset_pkbuf_pull_inline(pkbuf, len);
}

__attribute__((unused)) static oset_inline void oset_pkbuf_trim(oset_pkbuf_t *pkbuf, unsigned int len)
{
    if (pkbuf->len > len) {
        pkbuf->tail = pkbuf->data + len;
        pkbuf->len = len;
    }
}

#ifdef __cplusplus
}
#endif

#endif /* OSET_PKBUF_H */
