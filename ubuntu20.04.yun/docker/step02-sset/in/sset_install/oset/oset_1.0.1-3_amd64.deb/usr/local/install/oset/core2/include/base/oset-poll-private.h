/************************************************************************
 *File name: oset-poll-private.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#ifndef OSET_POLL_PRIVATE_H
#define OSET_POLL_PRIVATE_H

#if !defined(OSET_CORE_COMPILATION)
#error "This private header cannot be included directly."
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_poll_s {
    oset_lnode_t node;
    int index;

    short when;
    oset_socket_t fd;
    oset_poll_handler_f handler;
    void *data;

    oset_pollset_t *pollset;
} oset_poll_t;

typedef struct oset_pollset_s {
    void *context;
    OSET_POOL(pool, oset_poll_t);

    struct {
        oset_socket_t fd[2];
        oset_poll_t *poll;
    } notify;

    unsigned int capacity;
} oset_pollset_t;

#ifdef __cplusplus
}
#endif

#endif /* OSET_POLL_PRIVATE_H */
