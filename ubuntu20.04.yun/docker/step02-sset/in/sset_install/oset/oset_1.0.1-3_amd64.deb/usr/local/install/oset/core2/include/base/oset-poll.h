/************************************************************************
 *File name: oset-poll.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_POLL_H
#define OSET_POLL_H

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*oset_poll_handler_f)(short when, oset_socket_t fd, void *data);

oset_pollset_t *oset_pollset_create(unsigned int capacity);
void oset_pollset_destroy(oset_pollset_t *pollset);

#define OSET_POLLIN      0x01
#define OSET_POLLOUT     0x02

oset_poll_t *oset_pollset_add(oset_pollset_t *pollset, short when,
        oset_socket_t fd, oset_poll_handler_f handler, void *data);
void oset_pollset_remove(oset_poll_t *poll);

void *oset_pollset_self_handler_data(void);

typedef struct oset_pollset_actions_s {
    void (*init)(oset_pollset_t *pollset);
    void (*cleanup)(oset_pollset_t *pollset);

    int (*add)(oset_poll_t *poll);
    int (*remove)(oset_poll_t *poll);

    int (*poll)(oset_pollset_t *pollset, oset_time_t timeout);
    int (*notify)(oset_pollset_t *pollset);
} oset_pollset_actions_t;

extern oset_pollset_actions_t oset_pollset_actions;

#define oset_pollset_poll oset_pollset_actions.poll
#define oset_pollset_notify oset_pollset_actions.notify

#ifdef __cplusplus
}
#endif

#endif /* OSET_POLL_H */
