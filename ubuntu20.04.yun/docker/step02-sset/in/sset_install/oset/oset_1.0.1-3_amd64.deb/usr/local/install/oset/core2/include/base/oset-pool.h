/************************************************************************
 *File name: oset-pool.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_POOL_H
#define OSET_POOL_H

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int oset_index_t;

#define OSET_POOL(pool, type) \
    struct { \
        const char *name; \
        int head, tail; \
        int size, avail; \
        type **free, *array, **index; \
    } pool

#define oset_pool_init(pool, _size) do { \
    int i; \
    (pool)->name = #pool; \
    (pool)->free = malloc(sizeof(*(pool)->free) * _size); \
    oset_assert((pool)->free); \
    (pool)->array = malloc(sizeof(*(pool)->array) * _size); \
    oset_assert((pool)->array); \
    (pool)->index = malloc(sizeof(*(pool)->index) * _size); \
    oset_assert((pool)->index); \
    (pool)->size = (pool)->avail = _size; \
    (pool)->head = (pool)->tail = 0; \
    for (i = 0; i < _size; i++) { \
        (pool)->free[i] = &((pool)->array[i]); \
        (pool)->index[i] = NULL; \
    } \
} while (0)

#define oset_pool_final(pool) do { \
    if (((pool)->size != (pool)->avail)) \
        oset_error("%d in '%s[%d]' were not released.", \
                (pool)->size - (pool)->avail, (pool)->name, (pool)->size); \
    free((pool)->free); \
    free((pool)->array); \
    free((pool)->index); \
} while (0)

#define oset_pool_index(pool, node) (((node) - (pool)->array)+1)
#define oset_pool_find(pool, _index) \
    (_index > 0 && _index <= (pool)->size) ? (pool)->index[_index-1] : NULL
#define oset_pool_cycle(pool, node) \
    oset_pool_find((pool), oset_pool_index((pool), (node)))

#define oset_pool_alloc(pool, node) do { \
    *(node) = NULL; \
    if ((pool)->avail > 0) { \
        (pool)->avail--; \
        *(node) = (void*)(pool)->free[(pool)->head]; \
        (pool)->free[(pool)->head] = NULL; \
        (pool)->head = ((pool)->head + 1) % ((pool)->size); \
        (pool)->index[oset_pool_index(pool, *(node))-1] = *(node); \
    } \
} while (0)

#define oset_pool_free(pool, node) do { \
    if ((pool)->avail < (pool)->size) { \
        (pool)->avail++; \
        (pool)->free[(pool)->tail] = (void*)(node); \
        (pool)->tail = ((pool)->tail + 1) % ((pool)->size); \
        (pool)->index[oset_pool_index(pool, node)-1] = NULL; \
    } \
} while (0)

#define oset_pool_size(pool) ((pool)->size)
#define oset_pool_avail(pool) ((pool)->avail)

#define oset_index_init(pool, _size) do { \
    int i; \
    (pool)->name = #pool; \
    (pool)->free = oset_malloc(sizeof(*(pool)->free) * _size); \
    oset_assert((pool)->free); \
    (pool)->array = oset_malloc(sizeof(*(pool)->array) * _size); \
    oset_assert((pool)->array); \
    (pool)->index = oset_malloc(sizeof(*(pool)->index) * _size); \
    oset_assert((pool)->index); \
    (pool)->size = (pool)->avail = _size; \
    (pool)->head = (pool)->tail = 0; \
    for (i = 0; i < _size; i++) { \
        (pool)->free[i] = &((pool)->array[i]); \
        (pool)->index[i] = NULL; \
    } \
} while (0)

#define oset_index_final(pool) do { \
    if (((pool)->size != (pool)->avail)) \
        oset_error("%d in '%s[%d]' were not released.", \
                (pool)->size - (pool)->avail, (pool)->name, (pool)->size); \
    oset_free((pool)->free); \
    oset_free((pool)->array); \
    oset_free((pool)->index); \
} while (0)

#ifdef __cplusplus
}
#endif

#endif /* OSET_POOL_H */
