/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/************************************************************************
 *File name: oset-queue.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_QUEUE_H
#define OSET_QUEUE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_queue_s oset_queue_t;

oset_queue_t *oset_queue_create(unsigned int capacity);
void oset_queue_destroy(oset_queue_t *queue);

int oset_queue_push(oset_queue_t *queue, void *data);
int oset_queue_pop(oset_queue_t *queue, void **data);

int oset_queue_trypush(oset_queue_t *queue, void *data);
int oset_queue_trypop(oset_queue_t *queue, void **data);

int oset_queue_timedpush(oset_queue_t *queue, void *data, oset_time_t timeout);
int oset_queue_timedpop(oset_queue_t *queue, void **data, oset_time_t timeout);

unsigned int oset_queue_size(oset_queue_t *queue);

int oset_queue_interrupt_all(oset_queue_t *queue);
int oset_queue_term(oset_queue_t *queue);


#ifdef __cplusplus
}
#endif

#endif /* OSET_QUEUE_H */
