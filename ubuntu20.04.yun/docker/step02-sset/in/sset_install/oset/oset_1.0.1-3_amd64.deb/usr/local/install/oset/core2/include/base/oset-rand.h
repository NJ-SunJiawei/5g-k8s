/************************************************************************
 *File name: oset-rand.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_RAND_H
#define OSET_RAND_H

#ifdef __cplusplus
extern "C" {
#endif

void oset_random(void *buf, size_t buflen);
uint32_t oset_random32(void);

#ifdef __cplusplus
}
#endif

#endif /* OSET_RAND_H */
