/************************************************************************
 *File name: oset-rbtree.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_RBTREE_H
#define OSET_RBTREE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    OSET_RBTREE_BLACK = 0,
    OSET_RBTREE_RED = 1,
} oset_rbtree_color_e;

typedef struct oset_rbnode_s {
    struct oset_rbnode_s *parent;
    struct oset_rbnode_s *left;
    struct oset_rbnode_s *right;

    oset_rbtree_color_e color;
} oset_rbnode_t;

typedef struct oset_rbtree_s {
    oset_rbnode_t *root;
} oset_rbtree_t;

#define OSET_RBTREE(name) oset_rbtree_t name = { NULL }

#define oset_rb_entry(ptr, type, member) oset_container_of(ptr, type, member)

__attribute__((unused)) static oset_inline void oset_rbtree_link_node(
        void *rb_node, oset_rbnode_t *parent, oset_rbnode_t **rb_link)
{
    oset_rbnode_t *node = rb_node;
    node->parent = parent;
    node->left = node->right = NULL;
    node->color = OSET_RBTREE_RED;

    *rb_link = node;
}

void oset_rbtree_insert_color(oset_rbtree_t *tree, void *rb_node);
void oset_rbtree_delete(oset_rbtree_t *tree, void *rb_node);

__attribute__((unused)) static oset_inline void *oset_rbtree_min(const oset_rbnode_t *rb_node)
{
    const oset_rbnode_t *node = rb_node;
    oset_assert(node);

    while (node->left)
        node = node->left;

    return (void *)node;
}

__attribute__((unused)) static oset_inline void *oset_rbtree_max(const void *rb_node)
{
    const oset_rbnode_t *node = rb_node;
    oset_assert(node);

    while (node->right)
        node = node->right;

    return (void *)node;
}

void *oset_rbtree_first(const oset_rbtree_t *tree);
void *oset_rbtree_next(const void *node);
void *oset_rbtree_last(const oset_rbtree_t *tree);
void *oset_rbtree_prev(const void *node);

#define oset_rbtree_for_each(tree, node) \
    for (node = oset_rbtree_first(tree); \
        (node); node = oset_rbtree_next(node))

#define oset_rbtree_reverse_for_each(tree, node) \
    for (node = oset_rbtree_last(tree); \
        (node); node = oset_rbtree_prev(node))

__attribute__((unused)) static oset_inline bool oset_rbtree_empty(const oset_rbtree_t *tree)
{
    return tree->root == NULL;
}

__attribute__((unused)) static oset_inline int oset_rbtree_count(const oset_rbtree_t *tree)
{
    oset_rbnode_t *node;
    int i = 0;
    oset_rbtree_for_each(tree, node)
        i++;
    return i;
}

#ifdef __cplusplus
}
#endif

#endif /* OSET_RBTREE_H */
