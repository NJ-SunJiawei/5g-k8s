/************************************************************************
 *File name: oset-ring.h
 *Description:
 *
 *Current Version:
 *Author: create by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_RING_H
#define OSET_RING_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_ring_queue_s oset_ring_queue_t;

oset_ring_queue_t *oset_ring_queue_create(unsigned int size);
int oset_ring_queue_try_put(oset_ring_queue_t *rque, unsigned char *data, unsigned int size);
int oset_ring_queue_put(oset_ring_queue_t *rque, unsigned char *data, unsigned int size);
int oset_ring_queue_time_put(oset_ring_queue_t *rque, unsigned char *data, unsigned int size, oset_time_t timeout);
int ring_queue_put(oset_ring_queue_t *rque, unsigned char *data, unsigned int size, oset_time_t timeout);

int oset_ring_queue_try_get(oset_ring_queue_t *rque, unsigned char **ptr, unsigned int *size);
int oset_ring_queue_time_get(oset_ring_queue_t *rque, unsigned char **ptr, unsigned int *size, oset_time_t timeout);
int oset_ring_queue_get(oset_ring_queue_t *rque, unsigned char **ptr, unsigned int *size);
int ring_queue_get(oset_ring_queue_t *rque, unsigned char **ptr, unsigned int *size, oset_time_t timeout);
int oset_ring_queue_destroy(oset_ring_queue_t *rque);
int oset_ring_queue_term(oset_ring_queue_t *rque);

typedef struct oset_ring_buf_s oset_ring_buf_t;

oset_ring_buf_t *oset_ring_buf_create(unsigned int count, unsigned int size);
unsigned char *oset_ring_buf_get(oset_ring_buf_t *rbuf);
unsigned int oset_ring_buf_ret(unsigned char *blk);
int oset_ring_buf_destroy(oset_ring_buf_t *rbuf);
void oset_ring_buf_show(oset_ring_buf_t *rbuf);
void oset_ring_queue_show(oset_ring_queue_t *rque);


#ifdef __cplusplus
}
#endif

#endif /* OSET_QUEUE_H */
