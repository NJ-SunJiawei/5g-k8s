/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/************************************************************************
 *File name: oset-sockaddr.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SOCKADDR_H
#define OSET_SOCKADDR_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_sockaddr_s oset_sockaddr_t;
struct oset_sockaddr_s {
    /* Reserved Area
     *   - Should not add any atrribute in this area.
     *
     *   e.g) 
     *   struct sockaddr addr;
     *   ...
     *   sockaddr_len((oset_sockaddr_t *)&addr);
     */
#define oset_sa_family sa.sa_family
#define oset_sin_port sin.sin_port
    union {
        struct sockaddr_storage ss;
        struct sockaddr_in sin;
        struct sockaddr_in6 sin6;
        struct sockaddr sa;
    };

    /* User Area
     *   - Could add your attribute.
     */
    char *hostname;

    oset_sockaddr_t *next;
};

typedef struct oset_ipsubnet_s {
    int family;

    uint32_t sub[4]; /* big enough for IPv4 and IPv6 addresses */
    uint32_t mask[4];
} oset_ipsubnet_t;

int oset_getaddrinfo(oset_sockaddr_t **sa_list, 
        int family, const char *hostname, uint16_t port, int flags);
int oset_freeaddrinfo(oset_sockaddr_t *sa_list);

int oset_addaddrinfo(oset_sockaddr_t **sa_list, 
        int family, const char *hostname, uint16_t port, int flags);
int oset_copyaddrinfo(
        oset_sockaddr_t **dst, const oset_sockaddr_t *src);
int oset_filteraddrinfo(oset_sockaddr_t **sa_list, int family);
int oset_sortaddrinfo(oset_sockaddr_t **sa_list, int family);

oset_sockaddr_t *oset_link_local_addr_by_dev(const char *dev);
int oset_filter_ip_version(oset_sockaddr_t **addr, 
        int no_ipv4, int no_ipv6, int prefer_ipv4);

#define OSET_ADDRSTRLEN INET6_ADDRSTRLEN
#define OSET_ADDR(__aDDR, __bUF) \
    oset_inet_ntop(__aDDR, __bUF, OSET_ADDRSTRLEN)
#define OSET_PORT(__aDDR) \
    be16toh((__aDDR)->oset_sin_port)
const char *oset_inet_ntop(void *addr, char *buf, int buflen);
int oset_inet_pton(int family, const char *src, void *addr);

socklen_t oset_sockaddr_len(const void *addr);
bool oset_sockaddr_is_equal(void *p, void *q);

int oset_ipsubnet(oset_ipsubnet_t *ipsub,
        const char *ipstr, const char *mask_or_numbits);

char *oset_gethostname(oset_sockaddr_t *addr);
char *oset_ipstrdup(oset_sockaddr_t *addr);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SOCKADDR_H */
