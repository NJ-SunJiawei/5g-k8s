/************************************************************************
 *File name: oset-socket.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SOCKET_H
#define OSET_SOCKET_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32
typedef SOCKET oset_socket_t;
#else
typedef int oset_socket_t;
#endif

#if !defined(_WIN32) && !defined(INVALID_SOCKET)
#define INVALID_SOCKET -1
#endif

typedef struct oset_sock_s {
    int family;
    oset_socket_t fd;

    oset_sockaddr_t local_addr;
    oset_sockaddr_t remote_addr;
} oset_sock_t;

void oset_socket_init(void);
void oset_socket_final(void);

oset_sock_t *oset_sock_create(void);
void oset_sock_destroy(oset_sock_t *sock);

oset_sock_t *oset_sock_socket(int family, int type, int protocol);
int oset_sock_bind(oset_sock_t *sock, oset_sockaddr_t *addr);
int oset_sock_connect(oset_sock_t *sock, oset_sockaddr_t *addr);

int oset_sock_listen(oset_sock_t *sock);
oset_sock_t *oset_sock_accept(oset_sock_t *sock);

ssize_t oset_write(oset_socket_t fd, const void *buf, size_t len);
ssize_t oset_read(oset_socket_t fd, void *buf, size_t len);

ssize_t oset_send(oset_socket_t fd, const void *buf, size_t len, int flags);
ssize_t oset_sendto(oset_socket_t fd,
        const void *buf, size_t len, int flags, const oset_sockaddr_t *to);
ssize_t oset_recv(oset_socket_t fd, void *buf, size_t len, int flags);
ssize_t oset_recvfrom(oset_socket_t fd,
        void *buf, size_t len, int flags, oset_sockaddr_t *from);

int oset_closesocket(oset_socket_t fd);

int oset_nonblocking(oset_socket_t fd);
int oset_closeonexec(oset_socket_t fd);
int oset_listen_reusable(oset_socket_t fd);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SOCKET_H */
