/************************************************************************
 *File name: oset-socknode.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SOCKNODE_H
#define OSET_SOCKNODE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_pollset_s oset_pollset_t;
typedef struct oset_poll_s oset_poll_t;

typedef struct oset_socknode_s {
    oset_lnode_t node;

    oset_sockaddr_t *addr;

    oset_sock_t *sock;
    void (*cleanup)(oset_sock_t *sock);
    oset_poll_t *poll;
} oset_socknode_t;

oset_socknode_t *oset_socknode_new(oset_sockaddr_t *addr);
void oset_socknode_free(oset_socknode_t *node);

oset_socknode_t *oset_socknode_add(
        oset_list_t *list, int family, oset_sockaddr_t *sa_list);
void oset_socknode_remove(oset_list_t *list, oset_socknode_t *node);
void oset_socknode_remove_all(oset_list_t *list);

int oset_socknode_probe(
        oset_list_t *list, oset_list_t *list6, const char *dev, uint16_t port);
int oset_socknode_fill_scope_id_in_local(oset_sockaddr_t *sa_list);

void oset_socknode_set_cleanup(
        oset_socknode_t *node, void (*cleanup)(oset_sock_t *));

oset_sock_t *oset_socknode_sock_first(oset_list_t *list);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SOCKNODE_H */
