/************************************************************************
 *File name: oset-sockpair.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SOCKPAIR_H
#define OSET_SOCKPAIR_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32
#define AF_SOCKPAIR     AF_INET
#else
#define AF_SOCKPAIR     AF_UNIX
#endif

int oset_socketpair(int family, int type, int protocol, oset_socket_t fd[2]);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SOCKPAIR_H */
