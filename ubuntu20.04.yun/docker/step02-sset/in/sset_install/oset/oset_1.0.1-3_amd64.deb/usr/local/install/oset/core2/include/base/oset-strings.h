/**
 *
 * Orcania library
 *
 * Different functions for different purposes but that can be shared between
 * other projects
 *
 * orcania.c: main functions definitions
 *
 * Copyright 2015-2020 Nicolas Mora <mail@babelouest.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation;
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU GENERAL PUBLIC LICENSE for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
/************************************************************************
 *File name: oset-srings.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_STRINGS_H
#define OSET_STRINGS_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_HUGE_LEN        8192

#if defined(_WIN32)
#define oset_strtok_r strtok_s
#define oset_strcasecmp _stricmp
#define oset_strncasecmp _strnicmp
#else
#define oset_strtok_r strtok_r
#define oset_strcasecmp strcasecmp
#define oset_strncasecmp strncasecmp
#endif

int oset_vsnprintf(char *str, size_t size, const char *format, va_list ap)
    OSET_GNUC_PRINTF (3, 0);
int oset_snprintf(char *str, size_t size, const char *format, ...)
    OSET_GNUC_PRINTF(3, 4);
char *oset_vslprintf(char *str, char *last, const char *format, va_list ap)
    OSET_GNUC_PRINTF (3, 0);
char *oset_slprintf(char *str, char *last, const char *format, ...)
    OSET_GNUC_PRINTF(3, 4);

#define oset_strdup(s) oset_strdup_debug(s, OSET_FILE_LINE, false)
#define oset_strdup_or_assert(s) oset_strdup_debug(s, OSET_FILE_LINE, true)
char *oset_strdup_debug(const char *s, const char *file_line, bool abort);
#define oset_strndup(s, n) oset_strndup_debug(s, n, OSET_FILE_LINE, false)
#define oset_strndup_or_assert(s, n) oset_strndup_debug(s, n, OSET_FILE_LINE, true)
char *oset_strndup_debug
    (const char *s, size_t n, const char *file_line, bool abort);
#define oset_memdup(m, n) oset_memdup_debug(m, n, OSET_FILE_LINE, false)
#define oset_memdup_or_assert(m, n) oset_memdup_debug(m, n, OSET_FILE_LINE, true)
void *oset_memdup_debug
    (const void *m, size_t n, const char *file_line, bool abort);

char *oset_cpystrn(char *dst, const char *src, size_t dst_size);

/*
 * char *oset_msprintf(const char *message, ...)
 * char *mstrcatf(char *source, const char *message, ...)
 *
 * Orcania library
 * Copyright 2015-2018 Nicolas Mora <mail@babelouest.org>
 * License: LGPL-2.1
 *
 * https://github.com/babelouest/orcania.git
 */
#define oset_msprintf(...) oset_msprintf_debug(OSET_FILE_LINE, false, __VA_ARGS__)
#define oset_msprintf_or_assert(...) \
    oset_msprintf_debug(OSET_FILE_LINE, true, __VA_ARGS__)
char *oset_msprintf_debug
    (const char *file_line, bool abort, const char *message, ...)
    OSET_GNUC_PRINTF(3, 4);
#define oset_mstrcatf(source, ...) \
    oset_mstrcatf_debug(source, OSET_FILE_LINE, false, __VA_ARGS__)
#define oset_mstrcatf_or_assert(source, ...) \
    oset_mstrcatf_debug(source,  OSET_FILE_LINE, true, __VA_ARGS__)
char *oset_mstrcatf_debug(
        char *source, const char *file_line, bool abort,
        const char *message, ...)
    OSET_GNUC_PRINTF(4, 5);

char *oset_trimwhitespace(char *str);

char *oset_left_trimcharacter(char *str, char to_remove);
char *oset_right_trimcharacter(char *str, char to_remove);
char *oset_trimcharacter(char *str, char to_remove);

#ifdef __cplusplus
}
#endif

#endif /* OSET_STRINGS_H */
