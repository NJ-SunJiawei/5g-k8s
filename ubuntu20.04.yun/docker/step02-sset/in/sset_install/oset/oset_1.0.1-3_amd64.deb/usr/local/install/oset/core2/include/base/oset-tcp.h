/************************************************************************
 *File name: oset-tcp.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_TCP_H
#define OSET_TCP_H

#ifdef __cplusplus
extern "C" {
#endif

oset_sock_t *oset_tcp_server(oset_socknode_t *node);
oset_sock_t *oset_tcp_client(oset_socknode_t *node);

#ifdef __cplusplus
}
#endif

#endif /* OSET_TCP_H */
