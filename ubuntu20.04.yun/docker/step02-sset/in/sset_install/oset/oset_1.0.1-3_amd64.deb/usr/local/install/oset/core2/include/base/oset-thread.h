/************************************************************************
 *File name: oset-thread.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_THREAD_H
#define OSET_THREAD_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * The following code is stolen from mongodb-c-driver
 * https://github.com/mongodb/mongo-c-driver/blob/master/src/libmongoc/src/mongoc/mongoc-thread-private.h
 */
#if !defined(_WIN32)
#define oset_thread_mutex_t pthread_mutex_t
#define oset_thread_mutex_init(_n) (void)pthread_mutex_init((_n), NULL)
#define oset_thread_mutex_lock (void)pthread_mutex_lock
#define oset_thread_mutex_unlock (void)pthread_mutex_unlock
#define oset_thread_mutex_destroy (void)pthread_mutex_destroy
#define oset_thread_cond_t pthread_cond_t
#define oset_thread_cond_init(_n) (void)pthread_cond_init((_n), NULL)
#define oset_thread_cond_wait pthread_cond_wait
__attribute__((unused)) static oset_inline int oset_thread_cond_timedwait(
        pthread_cond_t *cond, pthread_mutex_t *mutex, oset_time_t timeout)
{
    int r;
    struct timespec to;
    struct timeval tv;
    oset_time_t usec;

    oset_gettimeofday(&tv);

    usec = oset_time_from_sec(tv.tv_sec) + tv.tv_usec + timeout;

    to.tv_sec = oset_time_sec(usec);
    to.tv_nsec = oset_time_usec(usec) * 1000;

    r = pthread_cond_timedwait(cond, mutex, &to);
    if (r == 0)
        return OSET_OK; 
    else if (r == OSET_ETIMEDOUT)
        return OSET_TIMEUP;
    else 
        return OSET_ERROR;
}
#define oset_thread_cond_signal (void)pthread_cond_signal
#define oset_thread_cond_broadcast pthread_cond_broadcast
#define oset_thread_cond_destroy (void)pthread_cond_destroy
#define oset_thread_id_t pthread_t
#define oset_thread_join(_n) pthread_join((_n), NULL)
#else
#define oset_thread_mutex_t CRITICAL_SECTION
#define oset_thread_mutex_init InitializeCriticalSection
#define oset_thread_mutex_lock EnterCriticalSection
#define oset_thread_mutex_unlock LeaveCriticalSection
#define oset_thread_mutex_destroy DeleteCriticalSection
#define oset_thread_cond_t CONDITION_VARIABLE
#define oset_thread_cond_init InitializeConditionVariable
#define oset_thread_cond_wait(_c, _m) \
    oset_thread_cond_timedwait ((_c), (_m), INFINITE)
static oset_inline int oset_thread_cond_timedwait(
    oset_thread_cond_t *cond, oset_thread_mutex_t *mutex, oset_time_t timeout)
{
    int r;

    if (SleepConditionVariableCS(cond, mutex,
                (DWORD)oset_time_to_msec(timeout))) {
        return OSET_OK;
    } else {
        r = GetLastError();

        if (r == WAIT_TIMEOUT || r == ERROR_TIMEOUT) {
            return OSET_TIMEUP;
        } else {
            return OSET_ERROR;
        }
    }
}
#define oset_thread_cond_signal WakeConditionVariable
#define oset_thread_cond_broadcast WakeAllConditionVariable
static oset_inline int oset_thread_cond_destroy(oset_thread_cond_t *_ignored)
{
   return 0;
}
#endif

typedef struct oset_thread_s oset_thread_t;

oset_thread_t *oset_thread_create(void (*func)(void *), void *data);
void oset_thread_destroy(oset_thread_t *thread);

#ifdef __cplusplus
}
#endif

#endif /* OSET_THREAD_H */
