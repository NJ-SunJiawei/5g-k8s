/************************************************************************
 *File name: oset-threadplus.h
 *Description:
 *
 *Current Version:
 *Author: created by sunjiawei
 *Date: 2021.12
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_THREADPLUS_H
#define OSET_THREADPLUS_H

#ifdef __cplusplus
extern "C" {
#endif

#define SCHEDPOLICY_OTHER SCHED_OTHER
#define SCHEDPOLICY_RR    SCHED_RR
#define SCHEDPOLICY_FIFO  SCHED_FIFO

#define EXIT_VAL_ERROR  001
#define EXIT_VAL_DETACH 002
#define EXIT_VAL_OK     003

typedef struct oset_threadattr_s oset_threadattr_t;
typedef struct oset_threadplus_s oset_threadplus_t;
typedef void *(*oset_threadplus_start_t)(oset_threadplus_t*, void*);

typedef struct oset_threadplus_s {
    oset_thread_id_t id;

    oset_thread_mutex_t mutex;
    oset_thread_cond_t cond;

    bool running;

	oset_threadattr_t *attr;
    oset_threadplus_start_t func;
    void *data;
	int  exitval;
} oset_threadplus_t;


int oset_threadattr_create(oset_threadattr_t **new);

int oset_threadattr_detach_set(oset_threadattr_t *attr, bool on);
char* oset_threadattr_detach_get(oset_threadattr_t *attr);

int oset_threadattr_stacksize_set(oset_threadattr_t *attr, size_t stacksize);
int oset_threadattr_guardsize_set(oset_threadattr_t *attr, size_t guardsize);

int oset_threadattr_schedpolicy_set(oset_threadattr_t *attr, int policy_type);
char* oset_threadattr_schedpolicy_get(oset_threadattr_t *attr);

int oset_threadattr_schedparam_set(oset_threadattr_t *attr, int priority_num);
int oset_threadattr_schedparam_get(oset_threadattr_t *attr);

int oset_threadattr_inheritsched_set(oset_threadattr_t *attr, bool on);
char* oset_threadattr_inheritsched_get(oset_threadattr_t *attr);

oset_threadplus_t *oset_threadplus_create(oset_threadattr_t *attr, oset_threadplus_start_t func, void *data);

void oset_threadpool_destroy(oset_threadplus_t *thread);
void oset_threadplus_destroy(oset_threadplus_t *thread);
oset_thread_id_t oset_thread_current_id(void);
int oset_thread_equal(oset_thread_id_t tid1, oset_thread_id_t tid2);

int oset_threadpool_exit(oset_threadplus_t *thread, int retval);
int oset_threadplus_exit(oset_threadplus_t *thread, int retval);
int oset_threadplus_join(int *retval, oset_threadplus_t *thread);
int oset_threadplus_detach(oset_threadplus_t *thread);

#ifdef __cplusplus
}
#endif

#endif /* OSET_THREAD_H */
