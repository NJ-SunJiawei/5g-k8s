/************************************************************************
 *File name: oset-threadpool.h
 *Description:
 *
 *Current Version:
 *Author: created by sunjiawei
 *Date: 2021.12
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_THREADPOOL_H
#define OSET_THREADPOOL_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_thread_pool oset_thread_pool_t;


void oset_threadpool_init(void);
void oset_threadpool_final(void);
int oset_os_thread_get(oset_thread_id_t *tid, oset_threadplus_t *thread);
int oset_os_thread_put(oset_threadplus_t **thread, oset_thread_id_t tid);


int oset_threadpool_tasks_cancel(oset_thread_pool_t *me, void *owner);
int oset_threadpool_destory(void *me);
int oset_threadpool_create(oset_thread_pool_t **me, size_t init_threads, size_t max_threads);
int oset_threadpool_push(oset_thread_pool_t *me,
                                               oset_threadplus_start_t func,
                                               void *param,
                                               int priority,
                                               void *owner);
int oset_threadpool_top(oset_thread_pool_t *me,
											  oset_threadplus_start_t func,
											  void *param,
											  int priority,
											  void *owner);
int oset_threadpool_schedule(oset_thread_pool_t *me,
													 oset_threadplus_start_t func,
													 void *param,
													 oset_time_t time,
													 void *owner);


size_t oset_threadpool_tasks_count(oset_thread_pool_t *me);
size_t oset_threadpool_scheduled_tasks_count(oset_thread_pool_t *me);
size_t oset_threadpool_threads_count(oset_thread_pool_t *me);
size_t oset_threadpool_busy_count(oset_thread_pool_t *me);
size_t oset_threadpool_idle_count(oset_thread_pool_t *me);
size_t oset_threadpool_tasks_run_count(oset_thread_pool_t * me);
size_t oset_threadpool_tasks_high_count(oset_thread_pool_t * me);
size_t oset_threadpool_threads_high_count(oset_thread_pool_t * me);
size_t oset_threadpool_threads_idle_timeout_count(oset_thread_pool_t * me);
size_t oset_threadpool_idle_max_get(oset_thread_pool_t *me);
size_t oset_threadpool_thread_max_get(oset_thread_pool_t *me);
oset_time_t oset_threadpool_idle_wait_get(oset_thread_pool_t * me);
size_t oset_threadpool_threshold_get(oset_thread_pool_t *me);
int oset_threadpool_task_owner_get(void **owner);


size_t oset_threadpool_idle_max_set(oset_thread_pool_t *me, size_t cnt);
oset_time_t oset_threadpool_idle_wait_set(oset_thread_pool_t * me, oset_time_t timeout);
size_t oset_threadpool_thread_max_set(oset_thread_pool_t *me, size_t cnt);
size_t oset_threadpool_threshold_set(oset_thread_pool_t *me, size_t val);

#ifdef __cplusplus
}
#endif

#endif /* OSET_THREAD_H */
