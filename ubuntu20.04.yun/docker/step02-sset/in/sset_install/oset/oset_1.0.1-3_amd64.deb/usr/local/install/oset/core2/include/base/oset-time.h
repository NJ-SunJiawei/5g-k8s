/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Copyright 2013 MongoDB, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/************************************************************************
 *File name: oset-time.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_TIME_H
#define OSET_TIME_H

#ifdef __cplusplus
extern "C" {
#endif

typedef int64_t oset_time_t;

#define OSET_INFINITE_TIME (-1)
#define OSET_NO_WAIT_TIME (0)

/** number of microseconds per second */
#define OSET_USEC_PER_SEC (1000000LL)

/** @return oset_time_t as a second */
#define oset_time_sec(time) ((time) / OSET_USEC_PER_SEC)

/** @return oset_time_t as a usec */
#define oset_time_usec(time) ((time) % OSET_USEC_PER_SEC)

/** @return oset_time_t as a msec */
#define oset_time_msec(time) (((time) / 1000) % 1000)

/** @return oset_time_t as a msec */
#define oset_time_to_msec(time) ((time) ? (1 + ((time) - 1) / 1000) : 0)

/** @return milliseconds as an oset_time_t */
#define oset_time_from_msec(msec) ((oset_time_t)(msec) * 1000)

/** @return seconds as an oset_time_t */
#define oset_time_from_sec(sec) ((oset_time_t)(sec) * OSET_USEC_PER_SEC)

int oset_gettimeofday(struct timeval *tv);

oset_time_t oset_time_now(void); /* This returns GMT */
int oset_time_from_lt(oset_time_t *t, struct tm *tm, int tm_usec);
int oset_time_from_gmt(oset_time_t *t, struct tm *tm, int tm_usec);

/** @return number of microseconds since an arbitrary point */
oset_time_t oset_get_monotonic_time(void);
/** @return the GMT offset in seconds */
int oset_timezone(void);

void oset_localtime(time_t s, struct tm *tm);
void oset_gmtime(time_t s, struct tm *tm);

void oset_msleep(time_t msec);
void oset_usleep(time_t usec);

#define oset_mktime mktime
#define oset_strptime strptime
#define oset_strftime strftime

#ifdef __cplusplus
}
#endif

#endif /* OSET_TIME_H */
