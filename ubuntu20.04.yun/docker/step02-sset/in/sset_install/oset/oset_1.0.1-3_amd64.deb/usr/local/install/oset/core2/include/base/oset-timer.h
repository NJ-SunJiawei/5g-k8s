/************************************************************************
 *File name: oset-timer.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_TIMER_H
#define OSET_TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct oset_timer_mgr_s oset_timer_mgr_t;
typedef struct oset_timer_s {
    oset_rbnode_t rbnode;
    oset_lnode_t lnode;

    void (*cb)(void*);
    void *data;

    oset_timer_mgr_t *manager;
    bool running;
    oset_time_t timeout;
} oset_timer_t;

oset_timer_mgr_t *oset_timer_mgr_create(unsigned int capacity);
void oset_timer_mgr_destroy(oset_timer_mgr_t *manager);

oset_timer_t *oset_timer_add(
        oset_timer_mgr_t *manager, void (*cb)(void *data), void *data);
void oset_timer_delete(oset_timer_t *timer);

void oset_timer_start(oset_timer_t *timer, oset_time_t duration);
void oset_timer_stop(oset_timer_t *timer);

oset_time_t oset_timer_mgr_next(oset_timer_mgr_t *manager);
void oset_timer_mgr_expire(oset_timer_mgr_t *manager);

#ifdef __cplusplus
}
#endif

#endif /* OSET_TIMER_H */
