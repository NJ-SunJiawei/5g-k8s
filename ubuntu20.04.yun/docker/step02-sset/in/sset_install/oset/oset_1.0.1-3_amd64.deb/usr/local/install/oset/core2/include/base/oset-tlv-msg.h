/************************************************************************
 *File name: oset-tlv-msg.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/
#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_TLV_MSG_H
#define OSET_TLV_MSG_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_TLV_MAX_HEADROOM 16
#define OSET_TLV_VARIABLE_LEN 0
#define OSET_TLV_MAX_MORE 8
#define OSET_TLV_1_OR_MORE(__v) __v[OSET_TLV_MAX_MORE]

#define OSET_TLV_MAX_CHILD_DESC 128

typedef enum {
    OSET_TLV_UINT8,
    OSET_TLV_UINT16,
    OSET_TLV_UINT24,
    OSET_TLV_UINT32,
    OSET_TLV_INT8,
    OSET_TLV_INT16,
    OSET_TLV_INT24,
    OSET_TLV_INT32,
    OSET_TLV_FIXED_STR,
    OSET_TLV_VAR_STR,
    OSET_TLV_NULL,
    OSET_TLV_MORE,
    OSET_TLV_COMPOUND,
    OSET_TLV_MESSAGE,
} oset_tlv_type_e;

typedef struct oset_tlv_desc_s {
    oset_tlv_type_e ctype;
    const char *name;
    uint16_t type;
    uint16_t length;
    uint8_t  instance;
    uint16_t vsize;
    void *child_descs[OSET_TLV_MAX_CHILD_DESC];
} oset_tlv_desc_t;

extern oset_tlv_desc_t oset_tlv_desc_more1;
extern oset_tlv_desc_t oset_tlv_desc_more2;
extern oset_tlv_desc_t oset_tlv_desc_more3;
extern oset_tlv_desc_t oset_tlv_desc_more4;
extern oset_tlv_desc_t oset_tlv_desc_more5;
extern oset_tlv_desc_t oset_tlv_desc_more6;
extern oset_tlv_desc_t oset_tlv_desc_more7;
extern oset_tlv_desc_t oset_tlv_desc_more8;

typedef uint64_t oset_tlv_presence_t;

/* 8-bit Unsigned integer */
typedef struct oset_tlv_uint8_s {
    oset_tlv_presence_t presence;
    uint8_t u8;
} oset_tlv_uint8_t;

/* 16-bit Unsigned integer */
typedef struct oset_tlv_uint16_s {
    oset_tlv_presence_t presence;
    uint16_t u16;
} oset_tlv_uint16_t;

/* 24-bit Unsigned integer */
typedef struct oset_tlv_uint24_s {
    oset_tlv_presence_t presence;
    uint32_t u24; /* Only 3 bytes valid */
} oset_tlv_uint24_t;

/* 32-bit Unsigned integer */
typedef struct oset_tlv_uint32_s {
    oset_tlv_presence_t presence;
    uint32_t u32;
} oset_tlv_uint32_t;

/* 8-bit Signed integer */
typedef struct oset_tlv_int8_s {
    oset_tlv_presence_t presence;
    int8_t i8;
} oset_tlv_int8_t;

/* 16-bit Signed integer */
typedef struct oset_tlv_int16_s {
    oset_tlv_presence_t presence;
    int16_t i16;
} oset_tlv_int16_t;

/* 24-bit Signed integer */
typedef struct tlv_int24_s {
    oset_tlv_presence_t presence;
    int32_t i24; /* Only 3 bytes valid */
} tlv_int24_t;

/* 32-bit Signed integer */
typedef struct oset_tlv_int32_s {
    oset_tlv_presence_t presence;
    int32_t i32;
} oset_tlv_int32_t;

/* Octets */
#define OSET_TLV_CLEAR_DATA(__dATA) \
    do { \
        oset_assert((__dATA)); \
        if ((__dATA)->data) { \
            oset_free((__dATA)->data); \
            (__dATA)->data = NULL; \
            (__dATA)->len = 0; \
            (__dATA)->presence = 0; \
        } \
    } while(0)
#define OSET_TLV_STORE_DATA(__dST, __sRC) \
    do { \
        oset_assert((__sRC)); \
        oset_assert((__sRC)->data); \
        oset_assert((__dST)); \
        OSET_TLV_CLEAR_DATA(__dST); \
        (__dST)->presence = (__sRC)->presence; \
        (__dST)->len = (__sRC)->len; \
        (__dST)->data = oset_calloc((__dST)->len, sizeof(uint8_t)); \
        oset_assert((__dST)->data); \
        memcpy((__dST)->data, (__sRC)->data, (__dST)->len); \
    } while(0)
typedef struct oset_tlv_octet_s {
    oset_tlv_presence_t presence;
    void *data;
    uint32_t len;
} oset_tlv_octet_t;

/* No value */
typedef struct oset_tlv_null_s {
    oset_tlv_presence_t presence;
} oset_tlv_null_t;

oset_pkbuf_t *oset_tlv_build_msg(oset_tlv_desc_t *desc, void *msg, int mode);
int oset_tlv_parse_msg(
        void *msg, oset_tlv_desc_t *desc, oset_pkbuf_t *pkbuf, int mode);

#ifdef __cplusplus
}
#endif

#endif /* OSET_GTP_TLV_H */
