/************************************************************************
 *File name: oset-tlv.h
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_TLV_H
#define OSET_TLV_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_TLV_MODE_T1_L1              1
#define OSET_TLV_MODE_T1_L2              2
#define OSET_TLV_MODE_T1_L2_I1           3
#define OSET_TLV_MODE_T2_L2              4

/* oset_tlv_t struncture */

typedef struct oset_tlv_s
{
    /* for tlv management */
    struct oset_tlv_s *head;
    struct oset_tlv_s *tail;  /* this is used only for head oset_tlv_t */
    struct oset_tlv_s *next;

    struct oset_tlv_s *parent;
    struct oset_tlv_s *embedded;

    /* tlv basic element */
    uint32_t type;
    uint32_t length;
    uint8_t instance;
    void *value;

    /* can be needed in encoding oset_tlv_t*/
    bool buff_allocated;
    uint32_t buff_len;
    unsigned char *buff_ptr;
    unsigned char *buff;
} oset_tlv_t;

#define oset_tlv_type(pTlv) pTlv->type
#define oset_tlv_length(pTlv) pTlv->length
#define oset_tlv_instance(pTlv) pTlv->instance
#define oset_tlv_value(pTlv) pTlv->value

/* oset_tlv_t pool related functions */
oset_tlv_t *oset_tlv_get(void);
void oset_tlv_free(oset_tlv_t *tlv);
void oset_tlv_free_all(oset_tlv_t *root);

void oset_tlv_init(void);
void oset_tlv_final(void);

uint32_t oset_tlv_pool_avail(void);

/* oset_tlv_t encoding functions */
oset_tlv_t *oset_tlv_add(oset_tlv_t *head, 
    uint32_t type, uint32_t length, uint8_t instance, void *value);
oset_tlv_t *oset_tlv_copy(void *buff, uint32_t buff_len,
    uint32_t type, uint32_t length, uint8_t instance, void *value);
oset_tlv_t *oset_tlv_embed(oset_tlv_t *parent, 
    uint32_t type, uint32_t length, uint8_t instance, void *value);

uint32_t oset_tlv_render(
        oset_tlv_t *root, void *data, uint32_t length, uint8_t mode);

/* oset_tlv_t parsing functions */
oset_tlv_t *oset_tlv_parse_block(uint32_t length, void *data, uint8_t mode);
oset_tlv_t *oset_tlv_parse_embedded_block(oset_tlv_t *tlv, uint8_t mode);

/* tlv operation-related function */
oset_tlv_t *oset_tlv_find(oset_tlv_t *root, uint32_t type);
oset_tlv_t *oset_tlv_find_root(oset_tlv_t *tlv);
uint32_t oset_tlv_calc_length(oset_tlv_t *tlv, uint8_t mode);
uint32_t oset_tlv_calc_count(oset_tlv_t *tlv);
uint8_t oset_tlv_value_8(oset_tlv_t *tlv);
uint16_t oset_tlv_value_16(oset_tlv_t *tlv);
uint32_t oset_tlv_value_32(oset_tlv_t *tlv);

#ifdef __cplusplus
}
#endif

#endif /* OSET_OSET_TLV_H */
