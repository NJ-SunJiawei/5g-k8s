/************************************************************************
 *File name: oset-yaml.c
 *Description:
 *
 *Current Version:
 *Author: moditify by sunjiawei
 *Date: 2021.11
************************************************************************/

#if !defined(OSET_CORE_INSIDE) && !defined(OSET_CORE_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_YAML_H
#define OSET_YAML_H

#include <yaml.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    yaml_document_t *document;
    yaml_node_t *node;
    yaml_node_pair_t *pair;
    yaml_node_item_t *item;
} oset_yaml_iter_t;

void oset_yaml_iter_init(oset_yaml_iter_t *iter, yaml_document_t *document);
int oset_yaml_iter_next(oset_yaml_iter_t *iter);
void oset_yaml_iter_recurse(oset_yaml_iter_t *parent, oset_yaml_iter_t *iter);

int oset_yaml_iter_type(oset_yaml_iter_t *iter);
const char *oset_yaml_iter_key(oset_yaml_iter_t *iter);
const char *oset_yaml_iter_value(oset_yaml_iter_t *iter);
int oset_yaml_iter_bool(oset_yaml_iter_t *iter);

#ifdef __cplusplus
}
#endif

#endif /* OSET_YAML_H */
