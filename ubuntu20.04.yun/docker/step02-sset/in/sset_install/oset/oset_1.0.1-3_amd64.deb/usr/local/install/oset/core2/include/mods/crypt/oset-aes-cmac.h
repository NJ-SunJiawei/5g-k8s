/*
 * Copyright 2002-2020 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#if !defined(OSET_CRYPT_INSIDE) && !defined(OSET_CRYPT_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_AES_CMAC_H
#define OSET_AES_CMAC_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Caculate CMAC value
 *
 * @param cmac
 * @param key
 * @param msg
 * @param len
 *
 * @return OSET_OK
 *         OSET_ERROR
 */
int oset_aes_cmac_calculate(uint8_t *cmac, const uint8_t *key,
        const uint8_t *msg, const uint32_t len);

/**
 * Verify CMAC value
 *
 * @param cmac
 * @param key
 * @param msg
 * @param len
 *
 * @return OSET_OK
 *         OSET_ERROR
 *         OSET_ERR_INVALID_CMAC
 */
#define OSET_ERR_INVALID_CMAC -2
int oset_aes_cmac_verify(uint8_t *cmac, const uint8_t *key,
        const uint8_t *msg, const uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* OSET_AES_CMAC_H */
