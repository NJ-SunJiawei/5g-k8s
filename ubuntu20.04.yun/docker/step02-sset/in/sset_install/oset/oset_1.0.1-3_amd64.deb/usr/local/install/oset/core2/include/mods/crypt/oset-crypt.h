#ifndef OSET_CRYPT_H
#define OSET_CRYPT_H

#include "oset-core.h"

#define OSET_CRYPT_INSIDE

#include "crypt/oset-sha1.h"
#include "crypt/oset-sha1-hmac.h"
#include "crypt/oset-sha2.h"
#include "crypt/oset-sha2-hmac.h"
#include "crypt/oset-aes.h"
#include "crypt/oset-aes-cmac.h"

#include "crypt/milenage.h"
#include "crypt/snow-3g.h"
#include "crypt/zuc.h"
#include "crypt/kasumi.h"

#include "crypt/oset-kdf.h"
#include "crypt/oset-base64.h"

#undef OSET_CRYPT_INSIDE

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_KEY_LEN                     16
#define OSET_AMF_LEN                     2
#define OSET_RAND_LEN                    16
#define OSET_AUTN_LEN                    16
#define OSET_AUTS_LEN                    14
#define OSET_MAX_RES_LEN                 16
#define OSET_MAC_S_LEN                   8

#define OSET_SQN_XOR_AK_LEN              6
#define OSET_AK_LEN                      6
#define OSET_SQN_LEN                     6
#define OSET_MAX_SQN                     0xffffffffffff

#define OSET_HASH_MME_LEN                8

#define OSET_KEYSTRLEN(x)                ((x*2)+1)

#ifdef __cplusplus
}
#endif

#endif /* OSET_CRYPT_H */
