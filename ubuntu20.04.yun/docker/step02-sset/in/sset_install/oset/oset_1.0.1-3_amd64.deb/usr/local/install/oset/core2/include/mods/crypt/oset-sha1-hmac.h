/*
 * Copyright 2002-2020 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#if !defined(OSET_CRYPT_INSIDE) && !defined(OSET_CRYPT_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SHA1_HMAC_H
#define OSET_SHA1_HMAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    oset_sha1_ctx ctx_inside;
    oset_sha1_ctx ctx_outside;

    /* for hmac_reinit */
    oset_sha1_ctx ctx_inside_reinit;
    oset_sha1_ctx ctx_outside_reinit;

    uint8_t block_ipad[OSET_SHA1_BLOCK_SIZE];
    uint8_t block_opad[OSET_SHA1_BLOCK_SIZE];
} oset_hmac_sha1_ctx;

void oset_hmac_sha1_init(oset_hmac_sha1_ctx *ctx, const uint8_t *key,
                      uint32_t key_size);
void oset_hmac_sha1_reinit(oset_hmac_sha1_ctx *ctx);
void oset_hmac_sha1_update(oset_hmac_sha1_ctx *ctx, const uint8_t *message,
                        uint32_t message_len);
void oset_hmac_sha1_final(oset_hmac_sha1_ctx *ctx, uint8_t *mac,
                       uint32_t mac_size);
void oset_hmac_sha1(const uint8_t *key, uint32_t key_size,
                 const uint8_t *message, uint32_t message_len,
                 uint8_t *mac, uint32_t mac_size);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SHA1_HMAC_H */
