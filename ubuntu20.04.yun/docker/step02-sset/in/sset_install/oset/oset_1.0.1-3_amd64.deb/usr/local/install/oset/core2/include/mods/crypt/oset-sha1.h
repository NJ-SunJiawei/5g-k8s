/*
 * Copyright 2002-2020 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#if !defined(OSET_CRYPT_INSIDE) && !defined(OSET_CRYPT_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SHA1_H
#define OSET_SHA1_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_SHA1_DIGEST_SIZE (160 / 8)
#define OSET_SHA1_BLOCK_SIZE  (512 / 8)

typedef struct oset_sha1_ctx
{
    unsigned Message_Digest[5]; /* Message Digest (output)          */

    unsigned Length_Low;        /* Message length in bits           */
    unsigned Length_High;       /* Message length in bits           */

    unsigned char Message_Block[64]; /* 512-bit message blocks      */
    int Message_Block_Index;    /* Index into message block array   */

    int Computed;               /* Is the digest computed?          */
    int Corrupted;              /* Is the message digest corruped?  */
} oset_sha1_ctx;

void oset_sha1_init(oset_sha1_ctx *ctx);
void oset_sha1_update(oset_sha1_ctx *ctx, const uint8_t *message, uint32_t len);
void oset_sha1_final(oset_sha1_ctx *ctx, uint8_t *digest);
void oset_sha1(const uint8_t *message, uint32_t len, uint8_t *digest);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SHA1_H */
