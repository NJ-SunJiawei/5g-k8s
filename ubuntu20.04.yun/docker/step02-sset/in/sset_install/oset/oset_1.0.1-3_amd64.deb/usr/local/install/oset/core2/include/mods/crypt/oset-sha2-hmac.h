/*
 * Copyright 2002-2020 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */


#if !defined(OSET_CRYPT_INSIDE) && !defined(OSET_CRYPT_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SHA2_HMAC_H
#define OSET_SHA2_HMAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    oset_sha224_ctx ctx_inside;
    oset_sha224_ctx ctx_outside;

    /* for hmac_reinit */
    oset_sha224_ctx ctx_inside_reinit;
    oset_sha224_ctx ctx_outside_reinit;

    uint8_t block_ipad[OSET_SHA224_BLOCK_SIZE];
    uint8_t block_opad[OSET_SHA224_BLOCK_SIZE];
} oset_hmac_sha224_ctx;

typedef struct {
    oset_sha256_ctx ctx_inside;
    oset_sha256_ctx ctx_outside;

    /* for hmac_reinit */
    oset_sha256_ctx ctx_inside_reinit;
    oset_sha256_ctx ctx_outside_reinit;

    uint8_t block_ipad[OSET_SHA256_BLOCK_SIZE];
    uint8_t block_opad[OSET_SHA256_BLOCK_SIZE];
} oset_hmac_sha256_ctx;

typedef struct {
    oset_sha384_ctx ctx_inside;
    oset_sha384_ctx ctx_outside;

    /* for hmac_reinit */
    oset_sha384_ctx ctx_inside_reinit;
    oset_sha384_ctx ctx_outside_reinit;

    uint8_t block_ipad[OSET_SHA384_BLOCK_SIZE];
    uint8_t block_opad[OSET_SHA384_BLOCK_SIZE];
} oset_hmac_sha384_ctx;

typedef struct {
    oset_sha512_ctx ctx_inside;
    oset_sha512_ctx ctx_outside;

    /* for hmac_reinit */
    oset_sha512_ctx ctx_inside_reinit;
    oset_sha512_ctx ctx_outside_reinit;

    uint8_t block_ipad[OSET_SHA512_BLOCK_SIZE];
    uint8_t block_opad[OSET_SHA512_BLOCK_SIZE];
} oset_hmac_sha512_ctx;

void oset_hmac_sha224_init(oset_hmac_sha224_ctx *ctx, const uint8_t *key,
                      uint32_t key_size);
void oset_hmac_sha224_reinit(oset_hmac_sha224_ctx *ctx);
void oset_hmac_sha224_update(oset_hmac_sha224_ctx *ctx, const uint8_t *message,
                        uint32_t message_len);
void oset_hmac_sha224_final(oset_hmac_sha224_ctx *ctx, uint8_t *mac,
                       uint32_t mac_size);
void oset_hmac_sha224(const uint8_t *key, uint32_t key_size,
                 const uint8_t *message, uint32_t message_len,
                 uint8_t *mac, uint32_t mac_size);

void oset_hmac_sha256_init(oset_hmac_sha256_ctx *ctx, const uint8_t *key,
                      uint32_t key_size);
void oset_hmac_sha256_reinit(oset_hmac_sha256_ctx *ctx);
void oset_hmac_sha256_update(oset_hmac_sha256_ctx *ctx, const uint8_t *message,
                        uint32_t message_len);
void oset_hmac_sha256_final(oset_hmac_sha256_ctx *ctx, uint8_t *mac,
                       uint32_t mac_size);
void oset_hmac_sha256(const uint8_t *key, uint32_t key_size,
                 const uint8_t *message, uint32_t message_len,
                 uint8_t *mac, uint32_t mac_size);

void oset_hmac_sha384_init(oset_hmac_sha384_ctx *ctx, const uint8_t *key,
                      uint32_t key_size);
void oset_hmac_sha384_reinit(oset_hmac_sha384_ctx *ctx);
void oset_hmac_sha384_update(oset_hmac_sha384_ctx *ctx, const uint8_t *message,
                        uint32_t message_len);
void oset_hmac_sha384_final(oset_hmac_sha384_ctx *ctx, uint8_t *mac,
                       uint32_t mac_size);
void oset_hmac_sha384(const uint8_t *key, uint32_t key_size,
                 const uint8_t *message, uint32_t message_len,
                 uint8_t *mac, uint32_t mac_size);

void oset_hmac_sha512_init(oset_hmac_sha512_ctx *ctx, const uint8_t *key,
                      uint32_t key_size);
void oset_hmac_sha512_reinit(oset_hmac_sha512_ctx *ctx);
void oset_hmac_sha512_update(oset_hmac_sha512_ctx *ctx, const uint8_t *message,
                        uint32_t message_len);
void oset_hmac_sha512_final(oset_hmac_sha512_ctx *ctx, uint8_t *mac,
                       uint32_t mac_size);
void oset_hmac_sha512(const uint8_t *key, uint32_t key_size,
                 const uint8_t *message, uint32_t message_len,
                 uint8_t *mac, uint32_t mac_size);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SHA2_HMAC_H */
