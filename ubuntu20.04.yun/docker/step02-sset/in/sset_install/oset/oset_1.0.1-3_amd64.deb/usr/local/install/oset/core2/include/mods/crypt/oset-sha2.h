/*
 * Copyright 2002-2020 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#if !defined(OSET_CRYPT_INSIDE) && !defined(OSET_CRYPT_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_SHA2_H
#define OSET_SHA2_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSET_SHA224_DIGEST_SIZE ( 224 / 8)
#define OSET_SHA256_DIGEST_SIZE ( 256 / 8)
#define OSET_SHA384_DIGEST_SIZE ( 384 / 8)
#define OSET_SHA512_DIGEST_SIZE ( 512 / 8)

#define OSET_SHA256_BLOCK_SIZE  ( 512 / 8)
#define OSET_SHA512_BLOCK_SIZE  (1024 / 8)
#define OSET_SHA384_BLOCK_SIZE  OSET_SHA512_BLOCK_SIZE
#define OSET_SHA224_BLOCK_SIZE  OSET_SHA256_BLOCK_SIZE

typedef struct {
    uint32_t tot_len;
    uint32_t len;
    uint8_t block[2 * OSET_SHA256_BLOCK_SIZE];
    uint32_t h[8];
} oset_sha256_ctx;

typedef struct {
    uint32_t tot_len;
    uint32_t len;
    uint8_t block[2 * OSET_SHA512_BLOCK_SIZE];
    uint64_t h[8];
} oset_sha512_ctx;

typedef oset_sha512_ctx oset_sha384_ctx;
typedef oset_sha256_ctx oset_sha224_ctx;

void oset_sha224_init(oset_sha224_ctx *ctx);
void oset_sha224_update(oset_sha224_ctx *ctx, const uint8_t *message,
        uint32_t len);
void oset_sha224_final(oset_sha224_ctx *ctx, uint8_t *digest);
void oset_sha224(const uint8_t *message, uint32_t len, uint8_t *digest);

void oset_sha256_init(oset_sha256_ctx * ctx);
void oset_sha256_update(oset_sha256_ctx *ctx, const uint8_t *message,
                   uint32_t len);
void oset_sha256_final(oset_sha256_ctx *ctx, uint8_t *digest);
void oset_sha256(const uint8_t *message, uint32_t len, uint8_t *digest);

void oset_sha384_init(oset_sha384_ctx *ctx);
void oset_sha384_update(oset_sha384_ctx *ctx, const uint8_t *message,
                   uint32_t len);
void oset_sha384_final(oset_sha384_ctx *ctx, uint8_t *digest);
void oset_sha384(const uint8_t *message, uint32_t len, uint8_t *digest);

void oset_sha512_init(oset_sha512_ctx *ctx);
void oset_sha512_update(oset_sha512_ctx *ctx, const uint8_t *message,
                   uint32_t len);
void oset_sha512_final(oset_sha512_ctx *ctx, uint8_t *digest);
void oset_sha512(const uint8_t *message, uint32_t len, uint8_t *digest);

#ifdef __cplusplus
}
#endif

#endif /* OSET_SHA2_H */
