/************************************************************************
 *File name: nacosApi2c.h
 *Description: 
 *
 *Current Version:
 *Author: create by sunjiawei
 *Date: 2021.11
************************************************************************/

#ifndef _NACOSAPI2C_H
#define _NACOSAPI2C_H
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


typedef struct CNacosReport  CNacosReport;
CNacosReport *createNacosRegister(const char* nacosServerName, const char* clusterName, const char* groupName, const char* serviceName, const char* instanceId, const char* ip, int port);
size_t getConfigFromNacos(const char* nacosServerName, char* dataID, char p[]);



int registerApi2c_test(char* nacosServerName, char* clusterName, char* groupName, char* serviceName, char* instanceId, char* ip, int port);


#ifdef __cplusplus
}
#endif

#endif
