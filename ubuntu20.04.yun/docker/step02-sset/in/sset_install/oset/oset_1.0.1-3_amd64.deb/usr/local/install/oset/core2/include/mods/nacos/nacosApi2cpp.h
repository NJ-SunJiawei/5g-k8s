/************************************************************************
 *File name: nacosApi2cpp.h
 *Description:
 *
 *Current Version:
 *Author: create by sunjiawei
 *Date: 2021.11
************************************************************************/


#ifndef _NACOSAPI_H
#define _NACOSAPI_H
#include "nacos/NacosString.h"
#include <pthread.h>

struct NACOS_ARG{
	NacosString nacosServerName; 
	NacosString clusterName; 
	NacosString groupName;
	NacosString serviceName; 
	NacosString instanceId; 
	NacosString ip; 
	int port;	
};

class nacosRegister
{
  private:
    pthread_t m_threadId;

  public:
    nacosRegister(NacosString nacosServerName, NacosString clusterName, NacosString groupName, NacosString serviceName, NacosString instanceId, NacosString ip, int port);
    ~nacosRegister();

};

NacosString getConfig(NacosString nacosServerName, NacosString dataID);

int registerApi_test(NacosString nacosServerName, NacosString clusterName, NacosString groupName, NacosString serviceName, NacosString instanceId, NacosString ip, int port);


#endif
