#if !defined(OSET_NAS_INSIDE) && !defined(OSET_NAS_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_NAS_5GS_CONV_H
#define OSET_NAS_5GS_CONV_H

#include "oset-nas-common.h"

#ifdef __cplusplus
extern "C" {
#endif

void oset_nas_5gs_imsi_to_bcd(
    oset_nas_5gs_mobile_identity_t *mobile_identity, char *bcd);

char *oset_nas_5gs_suci_from_mobile_identity(
        oset_nas_5gs_mobile_identity_t *mobile_identity);

void oset_nas_5gs_mobile_identity_guti_to_nas_guti(
        oset_nas_5gs_mobile_identity_guti_t *mobile_identity_guti,
        oset_nas_5gs_guti_t *nas_guti);
void oset_nas_5gs_nas_guti_to_mobility_identity_guti(
        oset_nas_5gs_guti_t *nas_guti,
        oset_nas_5gs_mobile_identity_guti_t *mobile_identity_guti);

#ifdef __cplusplus
}
#endif

#endif /* OSET_NAS_5GS_CONV_H */

