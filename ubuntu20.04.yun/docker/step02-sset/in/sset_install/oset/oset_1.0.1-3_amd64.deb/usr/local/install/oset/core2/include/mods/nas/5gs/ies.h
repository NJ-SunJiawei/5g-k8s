/*
 * The MIT License
 *
 * Copyright (C) 2019,2020 by Sukchan Lee <acetcom@gmail.com>
 *
 * This file is part of Open5GS.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*******************************************************************************
 * This file had been created by nas-message.py script v0.2.0
 * Please do not modify this file but regenerate it via script.
 * Created on: 2021-10-01 22:38:42.715187 by acetcom
 * from 24501-g41.docx
 ******************************************************************************/

#if !defined(OSET_NAS_INSIDE) && !defined(OSET_NAS_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_NAS_5GS_IES_H
#define OSET_NAS_5GS_IES_H

#ifdef __cplusplus
extern "C" {
#endif

int oset_nas_5gs_encode_optional_type(oset_pkbuf_t *pkbuf, uint8_t type);

int oset_nas_5gs_decode_additional_information(oset_nas_additional_information_t *additional_information, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_access_type(oset_nas_access_type_t *access_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_dnn(oset_nas_dnn_t *dnn, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_eap_message(oset_nas_eap_message_t *eap_message, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_gprs_timer(oset_nas_gprs_timer_t *gprs_timer, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_gprs_timer_2(oset_nas_gprs_timer_2_t *gprs_timer_2, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_gprs_timer_3(oset_nas_gprs_timer_3_t *gprs_timer_3, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_s_nssai(oset_nas_s_nssai_t *s_nssai, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gmm_capability(oset_nas_5gmm_capability_t *gmm_capability, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_abba(oset_nas_abba_t *abba, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_additional_5g_security_information(oset_nas_additional_5g_security_information_t *additional_security_information, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_additional_information_requested(oset_nas_additional_information_requested_t *additional_information_requested, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_allowed_pdu_session_status(oset_nas_allowed_pdu_session_status_t *allowed_pdu_session_status, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_authentication_failure_parameter(oset_nas_authentication_failure_parameter_t *authentication_failure_parameter, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_authentication_parameter_autn(oset_nas_authentication_parameter_autn_t *authentication_parameter_autn, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_authentication_parameter_rand(oset_nas_authentication_parameter_rand_t *authentication_parameter_rand, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_authentication_response_parameter(oset_nas_authentication_response_parameter_t *authentication_response_parameter, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_configuration_update_indication(oset_nas_configuration_update_indication_t *configuration_update_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_cag_information_list(oset_nas_cag_information_list_t *cag_information_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ciphering_key_data(oset_nas_ciphering_key_data_t *ciphering_key_data, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_daylight_saving_time(oset_nas_daylight_saving_time_t *daylight_saving_time, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gmm_cause(oset_nas_5gmm_cause_t *gmm_cause, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_de_registration_type(oset_nas_de_registration_type_t *de_registration_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_emergency_number_list(oset_nas_emergency_number_list_t *emergency_number_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_eps_bearer_context_status(oset_nas_eps_bearer_context_status_t *eps_bearer_context_status, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_eps_nas_message_container(oset_nas_eps_nas_message_container_t *eps_nas_message_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_eps_nas_security_algorithms(oset_nas_eps_nas_security_algorithms_t *eps_nas_security_algorithms, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_extended_emergency_number_list(oset_nas_extended_emergency_number_list_t *extended_emergency_number_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_extended_drx_parameters(oset_nas_extended_drx_parameters_t *extended_drx_parameters, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_imeisv_request(oset_nas_imeisv_request_t *imeisv_request, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ladn_indication(oset_nas_ladn_indication_t *ladn_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_drx_parameters(oset_nas_5gs_drx_parameters_t *drx_parameters, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_identity_type(oset_nas_5gs_identity_type_t *identity_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ladn_information(oset_nas_ladn_information_t *ladn_information, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_mico_indication(oset_nas_mico_indication_t *mico_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ma_pdu_session_information(oset_nas_ma_pdu_session_information_t *ma_pdu_session_information, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_mapped_nssai(oset_nas_mapped_nssai_t *mapped_nssai, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_mobile_station_classmark_2(oset_nas_mobile_station_classmark_2_t *mobile_station_classmark_2, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_key_set_identifier(oset_nas_key_set_identifier_t *key_set_identifier, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_message_container(oset_nas_message_container_t *message_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_security_algorithms(oset_nas_security_algorithms_t *security_algorithms, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_network_name(oset_nas_network_name_t *network_name, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_network_slicing_indication(oset_nas_network_slicing_indication_t *network_slicing_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_non_3gpp_nw_provided_policies(oset_nas_non_3gpp_nw_provided_policies_t *non_3gpp_nw_provided_policies, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_nssai(oset_nas_nssai_t *nssai, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_nssai_inclusion_mode(oset_nas_nssai_inclusion_mode_t *nssai_inclusion_mode, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_operator_defined_access_category_definitions(oset_nas_operator_defined_access_category_definitions_t *operator_defined_access_category_definitions, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_payload_container(oset_nas_payload_container_t *payload_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_mobile_identity(oset_nas_5gs_mobile_identity_t *mobile_identity, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_payload_container_type(oset_nas_payload_container_type_t *payload_container_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_session_identity_2(oset_nas_pdu_session_identity_2_t *pdu_session_identity_2, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_session_reactivation_result(oset_nas_pdu_session_reactivation_result_t *pdu_session_reactivation_result, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_session_reactivation_result_error_cause(oset_nas_pdu_session_reactivation_result_error_cause_t *pdu_session_reactivation_result_error_cause, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_session_status(oset_nas_pdu_session_status_t *pdu_session_status, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_plmn_list(oset_nas_plmn_list_t *plmn_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_rejected_nssai(oset_nas_rejected_nssai_t *rejected_nssai, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_release_assistance_indication(oset_nas_release_assistance_indication_t *release_assistance_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_request_type(oset_nas_request_type_t *request_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_s1_ue_network_capability(oset_nas_s1_ue_network_capability_t *s1_ue_network_capability, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_s1_ue_security_capability(oset_nas_s1_ue_security_capability_t *s1_ue_security_capability, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_service_area_list(oset_nas_service_area_list_t *service_area_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_network_feature_support(oset_nas_5gs_network_feature_support_t *network_feature_support, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_sms_indication(oset_nas_sms_indication_t *sms_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_sor_transparent_container(oset_nas_sor_transparent_container_t *sor_transparent_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_supported_codec_list(oset_nas_supported_codec_list_t *supported_codec_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_time_zone(oset_nas_time_zone_t *time_zone, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_time_zone_and_time(oset_nas_time_zone_and_time_t *time_zone_and_time, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_security_capability(oset_nas_ue_security_capability_t *ue_security_capability, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_usage_setting(oset_nas_ue_usage_setting_t *ue_usage_setting, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_status(oset_nas_ue_status_t *ue_status, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_uplink_data_status(oset_nas_uplink_data_status_t *uplink_data_status, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_registration_result(oset_nas_5gs_registration_result_t *registration_result, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_radio_capability_id(oset_nas_ue_radio_capability_id_t *ue_radio_capability_id, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_radio_capability_id_deletion_indication(oset_nas_ue_radio_capability_id_deletion_indication_t *ue_radio_capability_id_deletion_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_registration_type(oset_nas_5gs_registration_type_t *registration_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_truncated_5g_s_tmsi_configuration(oset_nas_truncated_5g_s_tmsi_configuration_t *truncated_s_tmsi_configuration, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_wus_assistance_information(oset_nas_wus_assistance_information_t *wus_assistance_information, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_n5gc_indication(oset_nas_n5gc_indication_t *n5gc_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_tracking_area_identity(oset_nas_5gs_tracking_area_identity_t *tracking_area_identity, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_tracking_area_identity_list(oset_nas_5gs_tracking_area_identity_list_t *tracking_area_identity_list, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gs_update_type(oset_nas_5gs_update_type_t *update_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gsm_capability(oset_nas_5gsm_capability_t *gsm_capability, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_address(oset_nas_pdu_address_t *pdu_address, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_pdu_session_type(oset_nas_pdu_session_type_t *pdu_session_type, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_qos_flow_descriptions(oset_nas_qos_flow_descriptions_t *qos_flow_descriptions, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_qos_rules(oset_nas_qos_rules_t *qos_rules, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_session_ambr(oset_nas_session_ambr_t *session_ambr, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_sm_pdu_dn_request_container(oset_nas_sm_pdu_dn_request_container_t *sm_pdu_dn_request_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ssc_mode(oset_nas_ssc_mode_t *ssc_mode, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_re_attempt_indicator(oset_nas_re_attempt_indicator_t *re_attempt_indicator, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gsm_network_feature_support(oset_nas_5gsm_network_feature_support_t *gsm_network_feature_support, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gsm_cause(oset_nas_5gsm_cause_t *gsm_cause, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_serving_plmn_rate_control(oset_nas_serving_plmn_rate_control_t *serving_plmn_rate_control, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_5gsm_congestion_re_attempt_indicator(oset_nas_5gsm_congestion_re_attempt_indicator_t *gsm_congestion_re_attempt_indicator, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_atsss_container(oset_nas_atsss_container_t *atsss_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_control_plane_only_indication(oset_nas_control_plane_only_indication_t *control_plane_only_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_header_compression_configuration(oset_nas_header_compression_configuration_t *header_compression_configuration, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ds_tt_ethernet_port_mac_address(oset_nas_ds_tt_ethernet_port_mac_address_t *ds_tt_ethernet_port_mac_address, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_ue_ds_tt_residence_time(oset_nas_ue_ds_tt_residence_time_t *ue_ds_tt_residence_time, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_port_management_information_container(oset_nas_port_management_information_container_t *port_management_information_container, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_always_on_pdu_session_indication(oset_nas_always_on_pdu_session_indication_t *always_on_pdu_session_indication, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_always_on_pdu_session_requested(oset_nas_always_on_pdu_session_requested_t *always_on_pdu_session_requested, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_allowed_ssc_mode(oset_nas_allowed_ssc_mode_t *allowed_ssc_mode, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_extended_protocol_configuration_options(oset_nas_extended_protocol_configuration_options_t *extended_protocol_configuration_options, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_integrity_protection_maximum_data_rate(oset_nas_integrity_protection_maximum_data_rate_t *integrity_protection_maximum_data_rate, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_mapped_eps_bearer_contexts(oset_nas_mapped_eps_bearer_contexts_t *mapped_eps_bearer_contexts, oset_pkbuf_t *pkbuf);
int oset_nas_5gs_decode_maximum_number_of_supported_packet_filters(oset_nas_maximum_number_of_supported_packet_filters_t *maximum_number_of_supported_packet_filters, oset_pkbuf_t *pkbuf);

int oset_nas_5gs_encode_additional_information(oset_pkbuf_t *pkbuf, oset_nas_additional_information_t *additional_information);
int oset_nas_5gs_encode_access_type(oset_pkbuf_t *pkbuf, oset_nas_access_type_t *access_type);
int oset_nas_5gs_encode_dnn(oset_pkbuf_t *pkbuf, oset_nas_dnn_t *dnn);
int oset_nas_5gs_encode_eap_message(oset_pkbuf_t *pkbuf, oset_nas_eap_message_t *eap_message);
int oset_nas_5gs_encode_gprs_timer(oset_pkbuf_t *pkbuf, oset_nas_gprs_timer_t *gprs_timer);
int oset_nas_5gs_encode_gprs_timer_2(oset_pkbuf_t *pkbuf, oset_nas_gprs_timer_2_t *gprs_timer_2);
int oset_nas_5gs_encode_gprs_timer_3(oset_pkbuf_t *pkbuf, oset_nas_gprs_timer_3_t *gprs_timer_3);
int oset_nas_5gs_encode_s_nssai(oset_pkbuf_t *pkbuf, oset_nas_s_nssai_t *s_nssai);
int oset_nas_5gs_encode_5gmm_capability(oset_pkbuf_t *pkbuf, oset_nas_5gmm_capability_t *gmm_capability);
int oset_nas_5gs_encode_abba(oset_pkbuf_t *pkbuf, oset_nas_abba_t *abba);
int oset_nas_5gs_encode_additional_5g_security_information(oset_pkbuf_t *pkbuf, oset_nas_additional_5g_security_information_t *additional_security_information);
int oset_nas_5gs_encode_additional_information_requested(oset_pkbuf_t *pkbuf, oset_nas_additional_information_requested_t *additional_information_requested);
int oset_nas_5gs_encode_allowed_pdu_session_status(oset_pkbuf_t *pkbuf, oset_nas_allowed_pdu_session_status_t *allowed_pdu_session_status);
int oset_nas_5gs_encode_authentication_failure_parameter(oset_pkbuf_t *pkbuf, oset_nas_authentication_failure_parameter_t *authentication_failure_parameter);
int oset_nas_5gs_encode_authentication_parameter_autn(oset_pkbuf_t *pkbuf, oset_nas_authentication_parameter_autn_t *authentication_parameter_autn);
int oset_nas_5gs_encode_authentication_parameter_rand(oset_pkbuf_t *pkbuf, oset_nas_authentication_parameter_rand_t *authentication_parameter_rand);
int oset_nas_5gs_encode_authentication_response_parameter(oset_pkbuf_t *pkbuf, oset_nas_authentication_response_parameter_t *authentication_response_parameter);
int oset_nas_5gs_encode_configuration_update_indication(oset_pkbuf_t *pkbuf, oset_nas_configuration_update_indication_t *configuration_update_indication);
int oset_nas_5gs_encode_cag_information_list(oset_pkbuf_t *pkbuf, oset_nas_cag_information_list_t *cag_information_list);
int oset_nas_5gs_encode_ciphering_key_data(oset_pkbuf_t *pkbuf, oset_nas_ciphering_key_data_t *ciphering_key_data);
int oset_nas_5gs_encode_daylight_saving_time(oset_pkbuf_t *pkbuf, oset_nas_daylight_saving_time_t *daylight_saving_time);
int oset_nas_5gs_encode_5gmm_cause(oset_pkbuf_t *pkbuf, oset_nas_5gmm_cause_t *gmm_cause);
int oset_nas_5gs_encode_de_registration_type(oset_pkbuf_t *pkbuf, oset_nas_de_registration_type_t *de_registration_type);
int oset_nas_5gs_encode_emergency_number_list(oset_pkbuf_t *pkbuf, oset_nas_emergency_number_list_t *emergency_number_list);
int oset_nas_5gs_encode_eps_bearer_context_status(oset_pkbuf_t *pkbuf, oset_nas_eps_bearer_context_status_t *eps_bearer_context_status);
int oset_nas_5gs_encode_eps_nas_message_container(oset_pkbuf_t *pkbuf, oset_nas_eps_nas_message_container_t *eps_nas_message_container);
int oset_nas_5gs_encode_eps_nas_security_algorithms(oset_pkbuf_t *pkbuf, oset_nas_eps_nas_security_algorithms_t *eps_nas_security_algorithms);
int oset_nas_5gs_encode_extended_emergency_number_list(oset_pkbuf_t *pkbuf, oset_nas_extended_emergency_number_list_t *extended_emergency_number_list);
int oset_nas_5gs_encode_extended_drx_parameters(oset_pkbuf_t *pkbuf, oset_nas_extended_drx_parameters_t *extended_drx_parameters);
int oset_nas_5gs_encode_imeisv_request(oset_pkbuf_t *pkbuf, oset_nas_imeisv_request_t *imeisv_request);
int oset_nas_5gs_encode_ladn_indication(oset_pkbuf_t *pkbuf, oset_nas_ladn_indication_t *ladn_indication);
int oset_nas_5gs_encode_5gs_drx_parameters(oset_pkbuf_t *pkbuf, oset_nas_5gs_drx_parameters_t *drx_parameters);
int oset_nas_5gs_encode_5gs_identity_type(oset_pkbuf_t *pkbuf, oset_nas_5gs_identity_type_t *identity_type);
int oset_nas_5gs_encode_ladn_information(oset_pkbuf_t *pkbuf, oset_nas_ladn_information_t *ladn_information);
int oset_nas_5gs_encode_mico_indication(oset_pkbuf_t *pkbuf, oset_nas_mico_indication_t *mico_indication);
int oset_nas_5gs_encode_ma_pdu_session_information(oset_pkbuf_t *pkbuf, oset_nas_ma_pdu_session_information_t *ma_pdu_session_information);
int oset_nas_5gs_encode_mapped_nssai(oset_pkbuf_t *pkbuf, oset_nas_mapped_nssai_t *mapped_nssai);
int oset_nas_5gs_encode_mobile_station_classmark_2(oset_pkbuf_t *pkbuf, oset_nas_mobile_station_classmark_2_t *mobile_station_classmark_2);
int oset_nas_5gs_encode_key_set_identifier(oset_pkbuf_t *pkbuf, oset_nas_key_set_identifier_t *key_set_identifier);
int oset_nas_5gs_encode_message_container(oset_pkbuf_t *pkbuf, oset_nas_message_container_t *message_container);
int oset_nas_5gs_encode_security_algorithms(oset_pkbuf_t *pkbuf, oset_nas_security_algorithms_t *security_algorithms);
int oset_nas_5gs_encode_network_name(oset_pkbuf_t *pkbuf, oset_nas_network_name_t *network_name);
int oset_nas_5gs_encode_network_slicing_indication(oset_pkbuf_t *pkbuf, oset_nas_network_slicing_indication_t *network_slicing_indication);
int oset_nas_5gs_encode_non_3gpp_nw_provided_policies(oset_pkbuf_t *pkbuf, oset_nas_non_3gpp_nw_provided_policies_t *non_3gpp_nw_provided_policies);
int oset_nas_5gs_encode_nssai(oset_pkbuf_t *pkbuf, oset_nas_nssai_t *nssai);
int oset_nas_5gs_encode_nssai_inclusion_mode(oset_pkbuf_t *pkbuf, oset_nas_nssai_inclusion_mode_t *nssai_inclusion_mode);
int oset_nas_5gs_encode_operator_defined_access_category_definitions(oset_pkbuf_t *pkbuf, oset_nas_operator_defined_access_category_definitions_t *operator_defined_access_category_definitions);
int oset_nas_5gs_encode_payload_container(oset_pkbuf_t *pkbuf, oset_nas_payload_container_t *payload_container);
int oset_nas_5gs_encode_5gs_mobile_identity(oset_pkbuf_t *pkbuf, oset_nas_5gs_mobile_identity_t *mobile_identity);
int oset_nas_5gs_encode_payload_container_type(oset_pkbuf_t *pkbuf, oset_nas_payload_container_type_t *payload_container_type);
int oset_nas_5gs_encode_pdu_session_identity_2(oset_pkbuf_t *pkbuf, oset_nas_pdu_session_identity_2_t *pdu_session_identity_2);
int oset_nas_5gs_encode_pdu_session_reactivation_result(oset_pkbuf_t *pkbuf, oset_nas_pdu_session_reactivation_result_t *pdu_session_reactivation_result);
int oset_nas_5gs_encode_pdu_session_reactivation_result_error_cause(oset_pkbuf_t *pkbuf, oset_nas_pdu_session_reactivation_result_error_cause_t *pdu_session_reactivation_result_error_cause);
int oset_nas_5gs_encode_pdu_session_status(oset_pkbuf_t *pkbuf, oset_nas_pdu_session_status_t *pdu_session_status);
int oset_nas_5gs_encode_plmn_list(oset_pkbuf_t *pkbuf, oset_nas_plmn_list_t *plmn_list);
int oset_nas_5gs_encode_rejected_nssai(oset_pkbuf_t *pkbuf, oset_nas_rejected_nssai_t *rejected_nssai);
int oset_nas_5gs_encode_release_assistance_indication(oset_pkbuf_t *pkbuf, oset_nas_release_assistance_indication_t *release_assistance_indication);
int oset_nas_5gs_encode_request_type(oset_pkbuf_t *pkbuf, oset_nas_request_type_t *request_type);
int oset_nas_5gs_encode_s1_ue_network_capability(oset_pkbuf_t *pkbuf, oset_nas_s1_ue_network_capability_t *s1_ue_network_capability);
int oset_nas_5gs_encode_s1_ue_security_capability(oset_pkbuf_t *pkbuf, oset_nas_s1_ue_security_capability_t *s1_ue_security_capability);
int oset_nas_5gs_encode_service_area_list(oset_pkbuf_t *pkbuf, oset_nas_service_area_list_t *service_area_list);
int oset_nas_5gs_encode_5gs_network_feature_support(oset_pkbuf_t *pkbuf, oset_nas_5gs_network_feature_support_t *network_feature_support);
int oset_nas_5gs_encode_sms_indication(oset_pkbuf_t *pkbuf, oset_nas_sms_indication_t *sms_indication);
int oset_nas_5gs_encode_sor_transparent_container(oset_pkbuf_t *pkbuf, oset_nas_sor_transparent_container_t *sor_transparent_container);
int oset_nas_5gs_encode_supported_codec_list(oset_pkbuf_t *pkbuf, oset_nas_supported_codec_list_t *supported_codec_list);
int oset_nas_5gs_encode_time_zone(oset_pkbuf_t *pkbuf, oset_nas_time_zone_t *time_zone);
int oset_nas_5gs_encode_time_zone_and_time(oset_pkbuf_t *pkbuf, oset_nas_time_zone_and_time_t *time_zone_and_time);
int oset_nas_5gs_encode_ue_security_capability(oset_pkbuf_t *pkbuf, oset_nas_ue_security_capability_t *ue_security_capability);
int oset_nas_5gs_encode_ue_usage_setting(oset_pkbuf_t *pkbuf, oset_nas_ue_usage_setting_t *ue_usage_setting);
int oset_nas_5gs_encode_ue_status(oset_pkbuf_t *pkbuf, oset_nas_ue_status_t *ue_status);
int oset_nas_5gs_encode_uplink_data_status(oset_pkbuf_t *pkbuf, oset_nas_uplink_data_status_t *uplink_data_status);
int oset_nas_5gs_encode_5gs_registration_result(oset_pkbuf_t *pkbuf, oset_nas_5gs_registration_result_t *registration_result);
int oset_nas_5gs_encode_ue_radio_capability_id(oset_pkbuf_t *pkbuf, oset_nas_ue_radio_capability_id_t *ue_radio_capability_id);
int oset_nas_5gs_encode_ue_radio_capability_id_deletion_indication(oset_pkbuf_t *pkbuf, oset_nas_ue_radio_capability_id_deletion_indication_t *ue_radio_capability_id_deletion_indication);
int oset_nas_5gs_encode_5gs_registration_type(oset_pkbuf_t *pkbuf, oset_nas_5gs_registration_type_t *registration_type);
int oset_nas_5gs_encode_truncated_5g_s_tmsi_configuration(oset_pkbuf_t *pkbuf, oset_nas_truncated_5g_s_tmsi_configuration_t *truncated_s_tmsi_configuration);
int oset_nas_5gs_encode_wus_assistance_information(oset_pkbuf_t *pkbuf, oset_nas_wus_assistance_information_t *wus_assistance_information);
int oset_nas_5gs_encode_n5gc_indication(oset_pkbuf_t *pkbuf, oset_nas_n5gc_indication_t *n5gc_indication);
int oset_nas_5gs_encode_5gs_tracking_area_identity(oset_pkbuf_t *pkbuf, oset_nas_5gs_tracking_area_identity_t *tracking_area_identity);
int oset_nas_5gs_encode_5gs_tracking_area_identity_list(oset_pkbuf_t *pkbuf, oset_nas_5gs_tracking_area_identity_list_t *tracking_area_identity_list);
int oset_nas_5gs_encode_5gs_update_type(oset_pkbuf_t *pkbuf, oset_nas_5gs_update_type_t *update_type);
int oset_nas_5gs_encode_5gsm_capability(oset_pkbuf_t *pkbuf, oset_nas_5gsm_capability_t *gsm_capability);
int oset_nas_5gs_encode_pdu_address(oset_pkbuf_t *pkbuf, oset_nas_pdu_address_t *pdu_address);
int oset_nas_5gs_encode_pdu_session_type(oset_pkbuf_t *pkbuf, oset_nas_pdu_session_type_t *pdu_session_type);
int oset_nas_5gs_encode_qos_flow_descriptions(oset_pkbuf_t *pkbuf, oset_nas_qos_flow_descriptions_t *qos_flow_descriptions);
int oset_nas_5gs_encode_qos_rules(oset_pkbuf_t *pkbuf, oset_nas_qos_rules_t *qos_rules);
int oset_nas_5gs_encode_session_ambr(oset_pkbuf_t *pkbuf, oset_nas_session_ambr_t *session_ambr);
int oset_nas_5gs_encode_sm_pdu_dn_request_container(oset_pkbuf_t *pkbuf, oset_nas_sm_pdu_dn_request_container_t *sm_pdu_dn_request_container);
int oset_nas_5gs_encode_ssc_mode(oset_pkbuf_t *pkbuf, oset_nas_ssc_mode_t *ssc_mode);
int oset_nas_5gs_encode_re_attempt_indicator(oset_pkbuf_t *pkbuf, oset_nas_re_attempt_indicator_t *re_attempt_indicator);
int oset_nas_5gs_encode_5gsm_network_feature_support(oset_pkbuf_t *pkbuf, oset_nas_5gsm_network_feature_support_t *gsm_network_feature_support);
int oset_nas_5gs_encode_5gsm_cause(oset_pkbuf_t *pkbuf, oset_nas_5gsm_cause_t *gsm_cause);
int oset_nas_5gs_encode_serving_plmn_rate_control(oset_pkbuf_t *pkbuf, oset_nas_serving_plmn_rate_control_t *serving_plmn_rate_control);
int oset_nas_5gs_encode_5gsm_congestion_re_attempt_indicator(oset_pkbuf_t *pkbuf, oset_nas_5gsm_congestion_re_attempt_indicator_t *gsm_congestion_re_attempt_indicator);
int oset_nas_5gs_encode_atsss_container(oset_pkbuf_t *pkbuf, oset_nas_atsss_container_t *atsss_container);
int oset_nas_5gs_encode_control_plane_only_indication(oset_pkbuf_t *pkbuf, oset_nas_control_plane_only_indication_t *control_plane_only_indication);
int oset_nas_5gs_encode_header_compression_configuration(oset_pkbuf_t *pkbuf, oset_nas_header_compression_configuration_t *header_compression_configuration);
int oset_nas_5gs_encode_ds_tt_ethernet_port_mac_address(oset_pkbuf_t *pkbuf, oset_nas_ds_tt_ethernet_port_mac_address_t *ds_tt_ethernet_port_mac_address);
int oset_nas_5gs_encode_ue_ds_tt_residence_time(oset_pkbuf_t *pkbuf, oset_nas_ue_ds_tt_residence_time_t *ue_ds_tt_residence_time);
int oset_nas_5gs_encode_port_management_information_container(oset_pkbuf_t *pkbuf, oset_nas_port_management_information_container_t *port_management_information_container);
int oset_nas_5gs_encode_always_on_pdu_session_indication(oset_pkbuf_t *pkbuf, oset_nas_always_on_pdu_session_indication_t *always_on_pdu_session_indication);
int oset_nas_5gs_encode_always_on_pdu_session_requested(oset_pkbuf_t *pkbuf, oset_nas_always_on_pdu_session_requested_t *always_on_pdu_session_requested);
int oset_nas_5gs_encode_allowed_ssc_mode(oset_pkbuf_t *pkbuf, oset_nas_allowed_ssc_mode_t *allowed_ssc_mode);
int oset_nas_5gs_encode_extended_protocol_configuration_options(oset_pkbuf_t *pkbuf, oset_nas_extended_protocol_configuration_options_t *extended_protocol_configuration_options);
int oset_nas_5gs_encode_integrity_protection_maximum_data_rate(oset_pkbuf_t *pkbuf, oset_nas_integrity_protection_maximum_data_rate_t *integrity_protection_maximum_data_rate);
int oset_nas_5gs_encode_mapped_eps_bearer_contexts(oset_pkbuf_t *pkbuf, oset_nas_mapped_eps_bearer_contexts_t *mapped_eps_bearer_contexts);
int oset_nas_5gs_encode_maximum_number_of_supported_packet_filters(oset_pkbuf_t *pkbuf, oset_nas_maximum_number_of_supported_packet_filters_t *maximum_number_of_supported_packet_filters);

#ifdef __cplusplus
}
#endif

#endif /* OSET_NAS_5GS_IES_H */

