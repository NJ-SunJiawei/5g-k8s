#ifndef OSET_NAS_5GS_H
#define OSET_NAS_5GS_H

#include "oset-nas-common.h"
#include "ipfw/oset-ipfw.h"

#define OSET_NAS_INSIDE

#include "nas/5gs/types.h"
#include "nas/5gs/conv.h"
#include "nas/5gs/ies.h"
#include "nas/5gs/message.h"

#undef OSET_NAS_INSIDE

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* OSET_NAS_5GS_H */
