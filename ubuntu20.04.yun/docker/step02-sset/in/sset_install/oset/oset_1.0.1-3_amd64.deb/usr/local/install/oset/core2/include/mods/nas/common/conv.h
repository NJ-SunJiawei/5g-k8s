#if !defined(OSET_NAS_INSIDE) && !defined(OSET_NAS_COMPILATION)
#error "This header cannot be included directly."
#endif

#ifndef OSET_NAS_COMMON_CONV_H
#define OSET_NAS_COMMON_CONV_H

#include "oset-nas-common.h"

#ifdef __cplusplus
extern "C" {
#endif

void oset_nas_imeisv_to_bcd(
    oset_nas_mobile_identity_imeisv_t *imeisv, uint8_t imeisv_len, char *bcd);
void *oset_nas_imeisv_bcd_to_buffer(const char *in, uint8_t *out, int *out_len);

#ifdef __cplusplus
}
#endif

#endif /* OSET_NAS_COMMON_CONV_H */

