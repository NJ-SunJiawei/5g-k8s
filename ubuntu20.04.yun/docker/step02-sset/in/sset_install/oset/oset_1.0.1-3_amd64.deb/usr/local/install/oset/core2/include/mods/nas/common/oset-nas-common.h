#ifndef OSET_NAS_COMMON_H
#define OSET_NAS_COMMON_H

#include "oset-core.h"
#include "oset-crypt.h"

#define OSET_NAS_INSIDE

#include "nas/common/types.h"
#include "nas/common/conv.h"
#include "nas/common/security.h"

#undef OSET_NAS_INSIDE

#ifdef __cplusplus
extern "C" {
#endif

extern int __oset_nas_domain;

#undef OSET_LOG_DOMAIN
#define OSET_LOG_DOMAIN __oset_nas_domain

#ifdef __cplusplus
}
#endif

#endif /* OSET_NAS_COMMON_H */
