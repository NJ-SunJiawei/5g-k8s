/************************************************************************
 *File name: asyncProducer.h
 *Description: 
 *
 *Current Version:
 *Author: create by sunjiawei
 *Date: 2021.11
************************************************************************/

#ifndef ASYNCPRODUCER_H
#define ASYNCPRODUCER_H

#include <stdio.h>
#include "rocketmq/CProducer.h"
#include "rocketmq/CCommon.h"
#include "rocketmq/CMessage.h"
#include "rocketmq/CSendResult.h"
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#include <memory.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void stopAndDestroyProducer(CProducer *producer);
CProducer *createAndStartProducer(const char *groupId, const char *addr, int timeFg);
void sendProbeMessage(CProducer *producer, const char *topic, const char *tags, const char *keys, char *content);
void SendExceptionCallback(CMQException e);
void SendSuccessCallback(CSendResult result);
void thread_sleep(unsigned milliseconds);

#ifdef __cplusplus
}
#endif

#endif /* ASYNCPRODUCER_H */
